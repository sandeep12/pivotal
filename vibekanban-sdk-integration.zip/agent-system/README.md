# Agent System

Portable, editor-agnostic agent workflow scaffolding.

## Default Runtime Flow

Canonical flow matches `rules/project-context.md`:

1. **Orchestrator:** `goal-template.md` (§0 **discovery** vs **delivery**) → `docs/plan.md` (include acceptance checks + verification commands) → request **`approve plan`**
2. **`approve plan`** (only mandatory manual gate)
3. **Orchestrator** guides **parallel:**
   - **Coder:** implement + fix review-gate feedback (delivery: no unapproved scope change)
   - **Review-gate:** **verifier-first** (plan + commands), then tests/typecheck/lint, then **scoped** code review
4. Repeat step 3 until acceptance + quality gate pass; resolve **[high]/[medium]** per plan—in **delivery** mode, **[low]** is usually non-blocking unless the plan requires otherwise

Only three subagent prompts: `orchestrator`, `coder`, `review-gate`.

## Three-Step Optimized Mode

For faster execution with strong quality controls, run:

1. Granular planning input via `state/goal-template.md`
2. Parallel lanes after approval (coder + review-gate, orchestrator coordinates)
3. Hard quality gate (`typecheck` + tests + lint + no unresolved high/medium findings)

Pilot record: `state/pilot-report.md`.

## Layout

- `AGENTS.md` core workflow contract
- `skills/` reusable behavior modules
- `subagents/` role prompts
- `state/` shared handoff contract
- `agent-install.sh` sync helper

## Trust and Verification

Use `agent-system/state/phase-gate-status.json` as the persistent proof file for phase-gated runs.

Minimum fields to trust a completed run:

- `planApproved=true`
- `lastCoderRun` and `lastReviewGateRun` populated
- `qualityGate.typecheck=pass`
- `qualityGate.tests=pass`
- `qualityGate.lint=pass`
- `qualityGate.openHigh=0`
- `qualityGate.openMed=0`
- `readyToComplete=true`

## Install

```bash
bash agent-system/agent-install.sh --all
```

Or generate for one editor:

```bash
bash agent-system/agent-install.sh --editor cursor
bash agent-system/agent-install.sh --editor claude
bash agent-system/agent-install.sh --editor codex
bash agent-system/agent-install.sh --editor windsurf
```

Using package scripts:

```bash
pnpm agent:install:all
pnpm agent:install:cursor
pnpm agent:install:claude
pnpm agent:install:codex
pnpm agent:install:windsurf
```

This generates compatibility files/folders and **per-file adapter stubs** (short header + `Adapter notice: source-of-truth…` pointing at `agent-system/`) for:

- `.agents/` (editor-agnostic; same stub shape as below — not symlinks to whole trees)
- `.claude/`
- `.cursor/`
- `.codex/`
- `.windsurf/`

Older installs may have used symlinks under `.agents/`; re-run `agent-install.sh` to replace them with stubs.
