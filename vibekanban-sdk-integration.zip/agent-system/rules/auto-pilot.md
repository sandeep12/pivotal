---
description: Nexus monorepo - Complete project context and conventions
alwaysApply: true
---

# Nexus Monorepo

TypeScript monorepo template. Fork to build apps; add packages as needed.

## Workflow Canonical Source

- `AGENTS.md` is the canonical workflow contract for agent execution.
- Tool adapters in `.claude/` and `.codex/` must not conflict with `AGENTS.md`.
- `agent-system/rules/phase-gated-autopilot.mdc` defines the enforced execution flow.
- If any workflow instruction in this file conflicts with `AGENTS.md` or `phase-gated-autopilot.mdc`, follow those files.

## Tech Stack

| Tool        | Version   | Purpose                       |
| ----------- | --------- | ----------------------------- |
| Node.js     | >= 22.0.0 | Runtime (LTS)                 |
| pnpm        | 9.15.0    | Package manager               |
| TypeScript  | 5.x       | Language                      |
| Turborepo   | 2.x       | Build orchestration & caching |
| Jest        | 30.x      | Testing framework             |
| Supertest   | 7.x       | HTTP testing                  |
| ESLint      | 10.x      | Linting (flat config)         |
| Prettier    | 3.x       | Formatting                    |
| Husky       | 9.x       | Git hooks                     |
| lint-staged | 16.x      | Pre-commit checks             |

## Project Structure

```
nexus/
├── agent-system/
│   ├── rules/                 # project rules
│   ├── skills/                # reusable skills
│   └── subagents/             # role prompts
├── app/                       # App stub (add your app when forking)
├── docs/                      # Project docs (README, plan go in packages/app)
├── packages/                  # Add packages as packages/util-<n>/
├── package.json
├── pnpm-workspace.yaml
├── turbo.json
├── tsconfig.base.json
├── tsconfig.json
├── jest.config.cjs
├── eslint.config.js
├── .prettierrc
├── Dockerfile
└── .nvmrc
```

**Skills to follow** (skills take priority over this rule on conflict):

| Skill                     | When to load                                             |
| ------------------------- | -------------------------------------------------------- |
| **js-code-style**         | Any file generation or refactor                          |
| **js-testing**            | Any test file                                            |
| **js-package-scaffold**   | Creating a new util-\* package                           |
| **js-package-checklist**  | Validating or reviewing a package                        |
| **decision-and-planning** | Before any new package, feature, or architectural change |
| **docker-guide**          | Dockerfile, .dockerignore, or Docker Compose changes     |
| **code-review**           | After any code or doc changes (post-implementation flow) |

**Skill-first workflow (MANDATORY):**

1. **Before** code or doc changes: Read the relevant skill(s) for the task and follow their required outputs (plan structure, test plan, API shape, etc.).
2. **After** changes: Update README, plan, and package SKILL together. Add use cases, how-to examples, and API updates to README; record missed items or design changes in `docs/plan.md` Decision Log; update package `SKILL.md` if usage or vendoring guidance changes.
3. **Never** leave README, plan, or SKILL stale. Flag anything discovered as "missed" as an explicit plan item.

**Nexus override:** Use **Jest** for tests. Package test scripts use `jest --config ../../jest.config.cjs`.

## Chores

- **Dependencies** — `pnpm add <pkg>` or `pnpm add <pkg>@latest`; avoid pinning unless compatibility/peer-dep requires it. After adding: `pnpm install` and `pnpm build` or `pnpm test`.
- **Rules & docs sync** — When changing structure, packages, tsconfig, scripts, build/test/Docker: update relevant `agent-system/rules/*`, `README.md`, `docs/plan.md`, `docs/future-roadmap.md`. New/removed package → project-context + tsconfig. File naming: `interfaces.ts` = public abstract provider/port contracts only; `types.ts` = config/aliases and internal implementation/supporting shapes.
- **Decisions & plans** — Before any new package or feature: follow **decision-and-planning** (problem definition → requirements → architecture → phases → test plan). Capture all decisions and reasoning in `docs/plan.md`.
- **Packages & Git** — Package layout, validation: **js-package-checklist** / **js-package-scaffold**. Template-driven add/remove/sparse checkout: **[scripts/template/README.md](../../scripts/template/README.md)**. Commit hygiene: **commit-policy**.

## Rules vs Skills

| Location    | Purpose                                                         | Examples                                                      |
| ----------- | --------------------------------------------------------------- | ------------------------------------------------------------- |
| **rules/**  | Project-specific: structure, conventions, workflows             | project-context                                               |
| **skills/** | Portable, reusable: code style, naming, testing, build patterns | js-code-style, js-testing, js-package-checklist, docker-guide |

Rules define _what this project does_; skills define _how to write code_ (reusable across projects).

## Env From App

Packages do **not** load environment variables (no dotenv in packages). The app loads env at bootstrap and passes config values into packages (e.g. `Logger.create({ transports: [{ type: "mongodb", uri: process.env.MONGODB_URI }] })`). Test env is loaded by the test runner or app test setup, then passed into the package. This keeps packages pure and testable without env side effects.

## Root package.json Scripts

```json
{
  "build": "turbo build",
  "start": "pnpm --filter app start",
  "dev": "pnpm build && pnpm --filter app dev",
  "test": "turbo test",
  "lint": "turbo lint",
  "lint:fix": "eslint . --fix",
  "format": "prettier --write .",
  "format:check": "prettier --check .",
  "typecheck": "turbo typecheck",
  "clean": "turbo clean && rm -rf node_modules",
  "prepare": "husky"
}
```

## Turborepo Pipeline (turbo.json)

| Task      | Depends On | Cached | Outputs                 |
| --------- | ---------- | ------ | ----------------------- |
| build     | ^build     | Yes    | dist/\*_, _.tsbuildinfo |
| test      | build      | Yes    | coverage/\*\*           |
| lint      | -          | Yes    | -                       |
| typecheck | -          | Yes    | -                       |
| clean     | -          | No     | -                       |

## TypeScript Configuration

**tsconfig.base.json** (shared):

- `target: ES2022`
- `module: NodeNext`, `moduleResolution: NodeNext` (required for .js imports)
- `strict: true`
- `declaration: true`, `sourceMap: true`
- `skipLibCheck: true`, `esModuleInterop: true`

**Package tsconfig.json pattern:**

```json
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "rootDir": "src",
    "outDir": "dist",
    "composite": true
  },
  "include": ["src/**/*.ts"],
  "exclude": ["**/*.test.ts"]
}
```

## Available Packages

Each package under `packages/` has a `SKILL.md` at its root. **Before writing any new code, check if an existing package covers the need.** Read the relevant `SKILL.md` to understand what the package does and how to use it.

```
packages/
  util-logger/SKILL.md           # logging
  util-api-server/SKILL.md       # Express HTTP API server
  util-mongodb/SKILL.md          # MongoDB CRUD + Zod validation
  util-error-normalizer/SKILL.md # error modeling and normalization
  util-secret-manager-aws/SKILL.md # AWS Secrets Manager
```

### Agent decision guide

1. **Exact match** — read the package `SKILL.md` and use it.
2. **Similar but not exact** — suggest using the package + extending it. Present the option and ask the user.
3. **No match** — suggest either using a raw library, or building a new `util-*` package if the pattern will be reused. Ask the user which they prefer.

Create new packages in `packages/util-<n>/`. Each needs README.md, docs/plan.md, and docs/future-roadmap.md (see js-package-checklist).

## Commands Quick Reference

```bash
# Run the app
pnpm dev                # Build + start with watch mode
pnpm start              # Start (after build)

# Development
pnpm build              # Build all packages
pnpm test               # Run all tests
pnpm lint               # Check linting
pnpm format             # Format all files

# Per-package (from package dir)
pnpm build              # Build this package
pnpm test               # Test this package

# Docker
docker build -t nexus-app --build-arg APP_NAME=app .
docker run -p 3000:3000 nexus-app
```

## Adding New Package

**When adding dependencies:** Use latest version — `pnpm add <pkg>@latest`. Avoid pinning unless compatibility requires it.

Follow **js-package-scaffold** and **js-package-checklist** for the full procedure. Key steps:

1. Create `packages/util-[name]/` with canonical structure (see js-package-scaffold)
2. Update `package.json`, add deps
3. Add to root `tsconfig.json` references
4. Run `pnpm install`
5. Implement, add tests, `README.md`, `docs/plan.md`, `docs/future-roadmap.md`, `SKILL.md`

## Adding New App

1. Create `app/` (or new app dir at root)
2. Add `package.json` with `@util/*` dependencies
3. Add `tsconfig.json` extending base
4. Add to root `tsconfig.json` references
5. Run `pnpm install`

## Versioning Strategy (App + Packages)

### Deployment vs package versions

| Layer               | Where                      | Use                                                  |
| ------------------- | -------------------------- | ---------------------------------------------------- |
| **Project/release** | Root or app `package.json` | Deployment: Docker tags, CI artifacts, release notes |
| **App**             | `app/package.json`         | Per-app deployment version (e.g. `app@1.2.3`)        |
| **Package**         | `packages/*/package.json`  | npm publish, changelog, API compatibility            |

**Project version for deployment:**

- Use root `version` for a single "monorepo release" (e.g. `nexus@1.0.0` → Docker tag `nexus-api:1.0.0`).
- Or use each app's `version` for app-specific releases.

**Package version (for publishing):**

- Each package has its own semver; bump when publishing to npm or for internal tracking.
- Apps use `workspace:*` — they always consume the built packages in the repo, not published versions.

### Rules

- Root: anchor only (often `0.0.0`, private).
- Apps: semver for deployments; bump for each release.
- Packages: semver — major=breaking, minor=feature, patch=fix.
- API routes: versioned by URL prefix (e.g. `/api/v1`).

## Git Workflow

Pre-commit hook runs:

1. ESLint on staged `.ts/.tsx/.js/.jsx` files
2. Prettier on all staged files

For **package management** (sparse checkout, add/remove package flow, branching, PRs), use **[scripts/template/README.md](../../scripts/template/README.md)** and **js-package-checklist**.

## File Naming

For naming conventions, follow **js-code-style** skill. Project-specific: use `interfaces.ts` for core provider/port contracts; `types.ts` for config and aliases.

## Enforcement Rules (MANDATORY)

**Before** any of the following, read the relevant skill(s) and follow their outputs:

- new package
- dependency change
- tsconfig change
- feature implementation
- doc changes (use cases, how-to, API)

**After** any of the above, you MUST:

1. Update (sync rule):
   - root tsconfig.json references (if applicable)
   - docs/plan.md — record missed items, design changes in Decision Log
   - relevant README.md — use cases, how-to, API table
   - package SKILL.md — if usage or vendoring guidance changed

2. Validate:
   - pnpm install
   - pnpm build
   - pnpm test
   - pnpm lint

STOP if any fails.

## Post-implementation review (AUTOMATED — MANDATORY)

After planning is approved, the AI MUST run the subagent pipeline and follow the review/fix loop:

1. **Gate alignment** — Planning is the only required manual gate. Do not implement before explicit plan approval (`approve plan`). Record **discovery vs delivery** in `goal-template.md` §0 and `docs/plan.md`.
2. **Pipeline** — Execute `orchestrator (plan + approve plan) -> parallel(coder: implement/fix, review-gate: verifier-first + scoped review)`.
3. **Loop until clear** — Repeat coder/review-gate loop (orchestrator coordinates) until **approved** acceptance checks and verification commands pass, objective quality gate passes, and no **[high]/[medium]** items the plan requires remain. Avoid unbounded generic review; in **delivery** mode, **[low]** is usually non-blocking unless the plan says otherwise.
4. **State updates** — Update `agent-system/state/agent-state.json` at each stage transition.
5. **No shortcuts** — Do not skip. Do not ask users to run this manually when automation is available.
