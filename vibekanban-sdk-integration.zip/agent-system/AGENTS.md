# Agent workflow contract (canonical)

This file is the **editor-agnostic source of truth** for how agents work in this repo. Editor- or IDE-specific copies (for example `.agents/AGENTS.md`, `.cursor/` shims) are **adapters**; they should only point here, not duplicate or replace this document.

## Roles

Three subagent prompts under `agent-system/subagents/`:

| Role         | File              | Responsibility                                                                                                                                                                                 |
| ------------ | ----------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Orchestrator | `orchestrator.md` | Planning: `goal-template` → `decision-and-planning` → `docs/plan.md` → request **`approve plan`**. After approval: coordinate **coder** and **review-gate** in parallel; update handoff state. |
| Coder        | `coder.md`        | Implement and fix per **approved** plan only; no planning gate.                                                                                                                                |
| Review-gate  | `review-gate.md`  | Review, tests, and quality gate (typecheck / lint / validation).                                                                                                                               |

See `agent-system/subagents/README.md` for the role table and usage rules.

## Philosophy (goal-first, verifier review-gate)

Work is **goal-first**: outcomes, constraints, and **observable acceptance checks** live in `goal-template.md` and `docs/plan.md` before implementation. **Review-gate** behaves as a **verifier**: it proves the approved plan (commands, deliverables, definition of done) **before** treating secondary review items as blocking. **`code-review`** remains important but is **scoped**—especially in **delivery** mode—so agents do not spin on open-ended style audits. **Discovery** vs **delivery** engagement modes are defined in `agent-system/state/goal-template.md` §0.

## Standard pipeline

1. **Orchestrator** completes planning (including engagement mode and verification commands in `docs/plan.md`) and requests **`approve plan`**.
2. User: **`approve plan`** (mandatory manual gate).
3. **Orchestrator** runs **parallel:**
   - **Coder:** implement and address review-gate feedback (delivery: no unapproved scope change).
   - **Review-gate:** **verifier-first** (plan acceptance + commands), then objective checks (typecheck/tests/lint), then scoped `code-review`.
4. Repeat step 3 until hard quality gate and plan acceptance criteria pass; resolve **[high]/[med]** per `phase-gated-autopilot` and the approved plan—not arbitrary review depth.

Rules and phase-gated behavior: `agent-system/rules/phase-gated-autopilot.mdc` and `agent-system/rules/project-context.md`.

## Skills and project context

Behavior modules live in `agent-system/skills/`. Monorepo conventions and stack context: `agent-system/rules/project-context.md`.

## State and verification

- Shared handoff: `agent-system/state/` (e.g. `goal-template.md`).
- Persistent proof of phase-gated runs: `agent-system/state/phase-gate-status.json` (see `agent-system/README.md` — Trust and Verification).

## Layout reference

Full layout and install notes: `agent-system/README.md`.
