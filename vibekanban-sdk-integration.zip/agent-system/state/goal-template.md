# Goal Template (Granular Planning Input)

Use this before planning starts. Keep it short and concrete.

## 0) Engagement mode

Pick one and record it in `docs/plan.md` (Planning Discussion or Decision Log) so orchestrator, coder, and review-gate behave consistently.

- **Discovery (technical / “white”):** Exploring APIs, spikes, tooling, or architecture. The plan may allow experimentation, but **`approve plan` still gates implementation**. Objective verification (commands + acceptance checks) is still mandatory; review-gate may use **broader** `code-review` scope when the plan says so.
- **Delivery (business / design-locked):** BRD, UX, or external commitments fix the shape of the work. The plan locks **acceptance checks and deliverables**; coder **does not** redesign or expand scope; review-gate verifies **those checks first**, then uses `code-review` in a **narrow**, plan-linked way (security, invariants, regressions)—not an open-ended style audit.

If unclear, default to **delivery** for user-facing or contractual work; use **discovery** only when the user explicitly wants exploration or a technical spike.

## 1) Outcome

- **Business goal:** <one sentence>
- **In scope:** <bullet list>
- **Out of scope:** <bullet list>

## 2) Constraints

- **Tech constraints:** <runtime, language, package boundaries>
- **Policy constraints:** <security/compliance/risk>
- **Time constraint:** <deadline or "none">

## 3) Acceptance Checks

- **Definition of done:** <observable user/business result>
- **Verification commands:** <typecheck/test/lint commands>
- **Review gate:** No unresolved high/medium findings.

## 4) Decomposition Seed

- **Task slices (initial):**
  - T1: <small executable task>
  - T2: <small executable task>
  - T3: <small executable task>
- **Dependencies/vendors allowed:** <explicit list>
- **Unknowns to resolve early:** <list>

## 5) Handoff Contract

- **Execution mode:** 3-step (plan → code + review-gate in parallel → hard quality gate)
- **Engagement mode:** <discovery | delivery> (see §0)
- **Artifacts to update:** <docs/plan.md, review notes, decision log, etc.>
