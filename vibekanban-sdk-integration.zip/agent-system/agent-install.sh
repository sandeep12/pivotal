#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
AGENT_SYSTEM_DIR="$ROOT_DIR/agent-system"

usage() {
  echo "Usage:"
  echo "  bash agent-system/agent-install.sh --all"
  echo "  bash agent-system/agent-install.sh --editor <cursor|claude|codex|windsurf>"
}

# Writes a small stub (title + relative path to source). Same pattern for `.cursor/`, `.claude/`, `.agents/`, etc.
# Not a symlink and not a bare absolute path — git may have shown symlinks as a single-line target in older installs.
write_adapter_file() {
  local target_file="$1"
  local source_file="$2"
  local header="$3"
  local source_rel="${source_file#"$ROOT_DIR"/}"

  mkdir -p "$(dirname "$target_file")"
  cat >"$target_file" <<EOF
$header

Adapter notice: source-of-truth for this file is in \`$source_rel\`.
EOF
}

mirror_as_adapters() {
  local source_root="$1"
  local target_root="$2"
  local header="$3"

  if [[ ! -d "$source_root" ]]; then
    return
  fi

  while IFS= read -r source_file; do
    local rel="${source_file#"$source_root"/}"
    local target_file="$target_root/$rel"
    write_adapter_file "$target_file" "$source_file" "$header"
  done < <(/usr/bin/find "$source_root" -type f)
}

mirror_cursor_skills_as_adapters() {
  local source_root="$1"
  local target_root="$2"
  local skill_header="$3"
  local helper_header="$4"

  if [[ ! -d "$source_root" ]]; then
    return
  fi

  while IFS= read -r source_file; do
    local rel="${source_file#"$source_root"/}"
    local target_file="$target_root/$rel"
    local file_name
    file_name="$(basename "$source_file")"

    if [[ "$file_name" == "SKILL.md" ]]; then
      write_adapter_file "$target_file" "$source_file" "$skill_header"
    else
      write_adapter_file "$target_file" "$source_file" "$helper_header"
    fi
  done < <(/usr/bin/find "$source_root" -type f)
}

mirror_rules_as_adapters() {
  local source_root="$1"
  local target_root="$2"
  local header="$3"
  local target_ext="$4"

  if [[ ! -d "$source_root" ]]; then
    return
  fi

  while IFS= read -r source_file; do
    local rel="${source_file#"$source_root"/}"
    local base="${rel%.*}"
    local target_file="$target_root/$base.$target_ext"
    write_adapter_file "$target_file" "$source_file" "$header"
  done < <(/usr/bin/find "$source_root" -type f)
}

install_cursor() {
  echo "Installing Cursor adapters..."
  mkdir -p "$ROOT_DIR/.cursor"
  rm -rf "$ROOT_DIR/.cursor/rules" "$ROOT_DIR/.cursor/skills" "$ROOT_DIR/.cursor/agents"
  write_adapter_file "$ROOT_DIR/.cursor/ADAPTER.md" "$AGENT_SYSTEM_DIR/AGENTS.md" "# Cursor Adapter"
  mirror_rules_as_adapters "$AGENT_SYSTEM_DIR/rules" "$ROOT_DIR/.cursor/rules" "---"$'\n'"description: Cursor rule adapter"$'\n'"alwaysApply: true"$'\n'"---" "mdc"
  mirror_cursor_skills_as_adapters "$AGENT_SYSTEM_DIR/skills" "$ROOT_DIR/.cursor/skills" "---"$'\n'"name: skill-adapter"$'\n'"description: Cursor skill adapter"$'\n'"---" "# Cursor skill adapter"
  mirror_as_adapters "$AGENT_SYSTEM_DIR/subagents" "$ROOT_DIR/.cursor/agents" "# Cursor Agent Adapter"
}

install_claude() {
  echo "Installing Claude adapters..."
  mkdir -p "$ROOT_DIR/.claude"
  rm -rf "$ROOT_DIR/.claude/rules" "$ROOT_DIR/.claude/skills" "$ROOT_DIR/.claude/agents"
  write_adapter_file "$ROOT_DIR/.claude/CLAUDE.md" "$AGENT_SYSTEM_DIR/AGENTS.md" "# Claude Adapter"
  mirror_rules_as_adapters "$AGENT_SYSTEM_DIR/rules" "$ROOT_DIR/.claude/rules" "# Claude Rule Adapter" "md"
  mirror_as_adapters "$AGENT_SYSTEM_DIR/skills" "$ROOT_DIR/.claude/skills" "# Claude Skill Adapter"
  mirror_as_adapters "$AGENT_SYSTEM_DIR/subagents" "$ROOT_DIR/.claude/agents" "# Claude Agent Adapter"
}

install_codex() {
  echo "Installing Codex adapters..."
  mkdir -p "$ROOT_DIR/.codex"
  rm -rf "$ROOT_DIR/.codex/rules" "$ROOT_DIR/.codex/skills" "$ROOT_DIR/.codex/agents"
  write_adapter_file "$ROOT_DIR/.codex/CODEX.md" "$AGENT_SYSTEM_DIR/AGENTS.md" "# Codex Adapter"
  mirror_rules_as_adapters "$AGENT_SYSTEM_DIR/rules" "$ROOT_DIR/.codex/rules" "# Codex Rule Adapter" "md"
  mirror_as_adapters "$AGENT_SYSTEM_DIR/skills" "$ROOT_DIR/.codex/skills" "# Codex Skill Adapter"
  mirror_as_adapters "$AGENT_SYSTEM_DIR/subagents" "$ROOT_DIR/.codex/agents" "# Codex Agent Adapter"
}

install_windsurf() {
  echo "Installing Windsurf adapters..."
  mkdir -p "$ROOT_DIR/.windsurf"
  rm -rf "$ROOT_DIR/.windsurf/rules" "$ROOT_DIR/.windsurf/skills" "$ROOT_DIR/.windsurf/agents"
  write_adapter_file "$ROOT_DIR/.windsurf/WINDSURF.md" "$AGENT_SYSTEM_DIR/AGENTS.md" "# Windsurf Adapter"
  mirror_rules_as_adapters "$AGENT_SYSTEM_DIR/rules" "$ROOT_DIR/.windsurf/rules" "# Windsurf Rule Adapter" "md"
  mirror_as_adapters "$AGENT_SYSTEM_DIR/skills" "$ROOT_DIR/.windsurf/skills" "# Windsurf Skill Adapter"
  mirror_as_adapters "$AGENT_SYSTEM_DIR/subagents" "$ROOT_DIR/.windsurf/agents" "# Windsurf Agent Adapter"
}

# Per-file adapter stubs only (no directory symlinks). Matches the multi-editor adapter layout under `.cursor/`, `.claude/`, etc.
install_common() {
  echo "Installing shared .agents/ adapters (source-of-truth: agent-system/)..."
  mkdir -p "$ROOT_DIR/.agents"
  rm -f "$ROOT_DIR/.agents/AGENTS.md"
  rm -rf "$ROOT_DIR/.agents/skills" "$ROOT_DIR/.agents/subagents"
  cat >"$ROOT_DIR/.agents/AGENTS.md" <<'EOF'
# Agent workflow (adapter)

This path is an **editor/shim** entry point. Canonical contract: `agent-system/AGENTS.md`.
EOF
  mirror_as_adapters "$AGENT_SYSTEM_DIR/skills" "$ROOT_DIR/.agents/skills" "# Agent system skill adapter"
  mirror_as_adapters "$AGENT_SYSTEM_DIR/subagents" "$ROOT_DIR/.agents/subagents" "# Agent system subagent adapter"
}

if [[ "${1:-}" == "--all" ]]; then
  TARGET="all"
elif [[ "${1:-}" == "--editor" && -n "${2:-}" ]]; then
  TARGET="$2"
else
  usage
  exit 1
fi

case "$TARGET" in
all)
  install_common
  install_cursor
  install_claude
  install_codex
  install_windsurf
  ;;
cursor)
  install_common
  install_cursor
  ;;
claude)
  install_common
  install_claude
  ;;
codex)
  install_common
  install_codex
  ;;
windsurf)
  install_common
  install_windsurf
  ;;
*)
  usage
  exit 1
  ;;
esac

echo "Done."
