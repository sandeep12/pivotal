# Subagents guide

Three role prompts: **orchestrator**, **coder**, **review-gate**.

| File              | Role                                                                                                                                                                                                                                 |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `orchestrator.md` | **Planning:** `goal-template.md` (incl. §0 discovery vs delivery) → `decision-and-planning` → `docs/plan.md` (copy acceptance + commands) → **`approve plan`**. **After approval:** guide **coder** and **review-gate** in parallel. |
| `coder.md`        | **Only** implement and fix per approved plan; **delivery:** no scope creep; no planning gate.                                                                                                                                        |
| `review-gate.md`  | **Verifier-first** (plan acceptance + commands), then typecheck/tests/lint, then **scoped** `code-review`.                                                                                                                           |

## Standard pipeline

1. **Orchestrator:** complete planning and request **`approve plan`**.
2. User: **`approve plan`**.
3. **Orchestrator** runs **parallel:**
   - **Coder:** implement + fix review-gate feedback.
   - **Review-gate:** review + tests + gate checks.
4. Repeat step 3 until acceptance + objective quality gate pass and required **[high]/[medium]** items are resolved per the approved plan (avoid unbounded generic review).

## Usage rule

- Load the role file that matches the current phase (planning vs build vs gate).
- Coder must not start implementation until orchestrator has approval.
