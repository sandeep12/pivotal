---
name: domain-driven-design
description: Apply Domain-Driven Design when creating or changing modules and features, and prefer existing workspace packages before introducing new code. Use for feature implementation, module design, service boundaries, and architecture refactors.
---

# Domain-Driven Design

Use this skill whenever building or changing any module, service, or feature.

## Goals

- Keep domain logic in domain layers, not transport or infrastructure code.
- Preserve clear boundaries between domain, application, and infrastructure.
- Reuse existing `packages/*` capabilities before adding new dependencies or modules.

## Mandatory workflow

1. Define or confirm the domain language (entities, value objects, invariants).
2. Check `packages/*/SKILL.md` files for an exact or near match before coding.
3. If a package is reusable, use it directly and document the integration.
4. If no package fits, propose extension/new package and record the decision in `docs/plan.md`.
5. Keep interfaces/ports in domain or application boundaries and adapters in infrastructure.

## DDD implementation checklist

- **Bounded context**: Keep each module focused on one business capability.
- **Entities**: Use entities for objects with identity and lifecycle.
- **Value objects**: Use immutable value objects for validated domain data.
- **Domain services**: Put cross-entity business rules in domain services.
- **Application services**: Orchestrate use-cases; avoid domain rule ownership here.
- **Ports/adapters**: Define ports as abstractions and place concrete adapters in infrastructure.
- **Transport isolation**: HTTP/WS/SSE schemas and handlers map inputs to application calls only.

## Package reuse policy

Before writing new utility code or adding a dependency:

1. Search existing workspace packages in `packages/`.
2. Read the candidate package `SKILL.md`.
3. Choose one:
   - **Exact match**: Use the package.
   - **Near match**: Reuse and extend with explicit plan entry.
   - **No match**: Propose a new `util-*` package only if reuse is likely.

Record the decision and rationale in `docs/plan.md` Decision Log.

## Delivery requirements

For every edit touching implementation or architecture:

- Update `docs/plan.md` with decisions or scope changes.
- Update relevant README and package SKILL if behavior/usage changed.
- Ensure naming reflects domain terms, not framework details.
