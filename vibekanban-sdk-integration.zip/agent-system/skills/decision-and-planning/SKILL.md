---
name: decision-and-planning
description: Full planning guidance — problem definition, requirements, architecture, decisions, and phase-wise execution. Use before starting any package, feature, or app work, and whenever making design or technical decisions.
metadata:
  version: "2.0"
---

# Decision & Planning Guidance

Use this skill for **any kind of work** — packages, features, apps, architecture, infra, or process. Follow these steps in order before writing any code.

---

## Step 1 — Problem Definition

Before anything else, answer these three questions. Do not proceed until all three are clear.

| Question                     | What to ask the user                                                                        |
| ---------------------------- | ------------------------------------------------------------------------------------------- |
| What problem are we solving? | "What is broken, missing, or slow right now? What does the user have to do manually today?" |
| Who is the user?             | "Who uses this — a developer, an end user, an internal service, another package?"           |
| What does success look like? | "How will we know this is done and working? What is the measurable outcome?"                |

**Output — write into `docs/plan.md`:**

```markdown
## Problem Definition

**Problem:** <one sentence — what is broken or missing>
**User:** <who uses this and how>
**Success:** <measurable outcome — e.g. "Logger initializes in < 50ms, zero dropped messages under load">
```

Never skip this. Vague problems produce vague solutions.

---

## Step 2 — Requirement Gathering

Split requirements into two buckets before designing anything.

**Functional requirements** — what the system must do:

- List each capability as a verb phrase ("store a log entry", "fetch secrets by ID", "rate-limit requests")
- One line per requirement, no implementation detail yet

**Non-functional requirements** — how the system must behave:

- Performance (latency, throughput)
- Scale (concurrent users, data volume)
- Security (auth, secrets, input validation)
- Reliability (retry, graceful shutdown, error recovery)

**Output — write into `docs/plan.md`:**

```markdown
## Requirements

### Functional

- <capability 1>
- <capability 2>

### Non-functional

- Performance: <target>
- Security: <requirement>
- Reliability: <requirement>
```

If a requirement is unclear, ask the user before designing. Do not assume scope.

---

## Step 3 — Architecture & System Design

Design before building. For every non-trivial package or feature, produce both levels:

**HLD (High Level Design)** — the big picture:

- What are the main components?
- How do they interact? (data flow, API contracts)
- What external dependencies exist?
- Monolith vs modular, sync vs async, stateful vs stateless?

**LLD (Low Level Design)** — the implementation detail:

- Public class and method signatures (before writing code)
- Key types and interfaces
- Which patterns apply (singleton, factory, adapter — see **design-patterns** skill)
- Error handling strategy
- State management

**Output — write into `docs/plan.md`:**

```markdown
## Architecture

### HLD

<diagram or bullet list of components and data flow>

### LLD

- Public API: `ClassName.method(input: InputType): OutputType`
- Key types: <list>
- Pattern: <e.g. singleton + factory>
- Error handling: <approach>
```

If there are multiple valid architectures, present them to the user as options with pros/cons before choosing.

---

## Step 4 — Decision Making

Before making any design, implementation, structure, or process choice:

1. **Ask the user** — "Why are you choosing this option?"
2. **Present 2–3 alternatives** with pros/cons
3. **Do not decide alone** — proceed only after user confirms
4. **Record the choice** in `docs/plan.md` so the reasoning is never lost

**Wrong:** "I'll use UUID for `_id`."

**Right:** "For `_id`, we could use:

- **UUID** — standard, no DB dependency. Longer strings.
- **ObjectId** — sortable, compact. MongoDB-specific.
- **NanoID** — URL-safe, short. Extra dep.
  Which do you prefer, and why?"

**Ask instead of assume.** Every decision recorded in `plan.md` is part of the story of the code.

---

## Step 5 — Phase Planning

After problem, requirements, and architecture are defined, break work into phases.

**Rules:**

- Define phases in `docs/plan.md` under `## Phases` before writing any code
- Keep each phase small and independently reviewable
- Each phase ends with a **review gate**: run **code-review**, fix all `[high]` and `[med]` findings before the next phase
- `[low]` findings can carry over but must be resolved before the final phase
- Never start a new phase while the previous phase has unresolved `[high]` or `[med]` issues

**Phase structure in `docs/plan.md`:**

```markdown
## Phases

### Phase 1 — <name>

Goal: <one sentence>
Deliverables:

- <file or feature 1>
- <file or feature 2>
  Review gate: run code-review, fix [high] + [med] before Phase 2.

### Phase 2 — <name>

Goal: <one sentence>
Deliverables:

- <file or feature>
  Review gate: run code-review, fix [high] + [med] before Phase 3.
```

---

## docs/plan.md — Full Required Structure

Every package or feature must have a `docs/plan.md` with all sections:

```markdown
## Problem Definition

## Requirements

## Architecture

## Phases

## Test Plan

## Planning Discussion

## Decision Log
```

**All decision and plan discussion in the plan:** Every discussion, clarification, Q&A, alternative considered, and user preference raised during planning must be recorded in `docs/plan.md`. Use `## Planning Discussion` for back-and-forth (user questions, clarifications, reasoning). Use `## Decision Log` for the final choices with reasoning. Nothing stays only in chat — the plan is the single source of truth.

**Test Plan timing:** The Test Plan section must be created at the same time as the plan. A plan without a Test Plan is incomplete. Do not create or publish a plan without it. List every `describe` block and its `it` cases so coverage decisions are visible before any test file is written.

**README, plan, and SKILL sync:** When modifying a package (new features, API changes, doc improvements), update all three: README (use cases, how-to examples, API table), plan (missed items, design changes in Decision Log), SKILL (usage or vendoring guidance). Never leave README stale.

The `## Decision Log` records every choice made during development with the reasoning:

```markdown
## Decision Log

- <date> — Chose singleton pattern over multi-instance because <reason confirmed by user>
- <date> — Used Winston over Pino because <reason>
```

This is the story of the code — decisions, reasoning, and updates tracked from initial build through every change.

## Phase-wise development

Use **Step 5 — Phase Planning** above as the required source for phase rules and `docs/plan.md` structure.

### Why phase-wise

- Catches problems before the next phase builds on top of them
- Keeps each review focused and manageable
- Prevents accumulated debt from making the codebase hard to fix later
- Aligns with the Bugbot principle: flag issues early when they are cheap to fix
