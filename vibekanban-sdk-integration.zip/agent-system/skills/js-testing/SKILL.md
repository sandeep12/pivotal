---
name: js-testing
description: Enforces zero-mocking, real-execution testing strategy for MEAN/MERN and full-stack JavaScript/TypeScript projects. Use when generating, reviewing, or refactoring tests in JavaScript or TypeScript.
metadata:
  version: "1.0"
---

# Testing Strategy for JavaScript / TypeScript Projects

These rules apply to all MEAN, MERN, and full-stack JavaScript/TypeScript test suites.

## Zero Mocking

Do **not** use mocks, stubs, spies, or any test doubles.

**Forbidden patterns:**

```typescript
// All of these are disallowed
jest.mock("./user.service");
jest.spyOn(service, "findUser");
sinon.stub(db, "query");
vi.mock("../lib/mailer");
sandbox.stub(axios, "get");
```

If a test feels like it needs a mock, that usually means the code under test should be refactored, or the test should be written as a broader integration test that exercises the real dependency.

## Real Execution

Every test must call the **actual implementation** of the function and all its dependencies. No fake or in-memory replacements for databases, caches, queues, or external services that are under your control.

**Wrong:**

```typescript
const mockRepo = { findById: () => Promise.resolve(fakeUser) };
const service = new UserService(mockRepo);
const result = await service.getUser("123");
```

**Right:**

```typescript
const service = new UserService(userRepository);
const result = await service.getUser(testUserId);
```

The test environment must be configured so that the real dependencies (database, cache, etc.) are available — typically a dedicated test database seeded with known data.

## Treat Unit Tests as Functional Integration Tests

Since tests run against a **dedicated database** and **target configuration**:

- Side effects (creating, updating, deleting records) are permitted.
- Tests should set up their own preconditions and clean up when appropriate.
- Test ordering should not matter — each test should be independently runnable.

**Example — testing a service that writes to the database:**

```typescript
describe("OrderService", () => {
  let orderId: string;

  beforeAll(async () => {
    await seedTestData();
  });

  afterAll(async () => {
    await cleanupTestData();
  });

  it("should create an order", async () => {
    const order = await orderService.createOrder(validOrderPayload);
    orderId = order.id;
    expect(order.status).toBe("pending");
  });

  it("should retrieve the created order", async () => {
    const order = await orderService.getOrderById(orderId);
    expect(order).toBeDefined();
    expect(order.id).toBe(orderId);
  });
});
```

## Test File Conventions

- Place test files **co-located** with the source file — same directory, adjacent to the module under test.
- Name test files `<source-file-name>.test.ts` or `<source-file-name>.spec.ts` (kebab-case, matching the naming conventions skill).
- One test file per source module.

**Example:**

```
services/
  user.service.ts
  user.service.test.ts
  order.service.ts
  order.service.test.ts
```

## Assertions

- Prefer explicit assertions over snapshot tests.
- Assert on specific properties rather than entire objects when possible.
- Use descriptive test names that state the expected behaviour.

**Wrong:**

```typescript
it("works", async () => {
  const result = await doSomething();
  expect(result).toMatchSnapshot();
});
```

**Right:**

```typescript
it("should return the user email when given a valid user id", async () => {
  const result = await getUserById(testUserId);
  expect(result.email).toBe("alice@example.com");
});
```

## Input and Output Variables

When a test compares input (what you pass in) with output (what you assert on), use a single variable for both. This avoids duplication, typos, and drift between the two.

**Wrong:**

```typescript
it("should write logs to MongoDB", async () => {
  logger.info("logger mongo test message");
  await logger.close();
  const docs = await collection.find({}).toArray();
  const msgDoc = docs.find((d) => d.msg === "logger mongo test message");
  expect(msgDoc).toBeDefined();
});
```

**Right:**

```typescript
it("should write logs to MongoDB", async () => {
  const msg = "logger mongo test message";
  logger.info(msg);
  await logger.close();
  const docs = await collection.find({}).toArray();
  const msgDoc = docs.find((d) => d.msg === msg);
  expect(msgDoc).toBeDefined();
});
```

## Test Coverage Categories

Every package or module must cover all relevant categories below. Before writing any test, plan which categories apply and list the specific cases.

### Happy path

The normal, successful flow. Cover the most common real-world usage.

```typescript
it("should create a logger with console transport and log a message", async () => { ... });
it("should insert a document and return the inserted id", async () => { ... });
```

### Edge cases and error paths

Boundary conditions, invalid inputs, missing config, and failure scenarios.

```typescript
it("should throw if getInstance() is called before create()", () => { ... });
it("should reject with a typed error when the DB connection is unreachable", async () => { ... });
it("should handle an empty string input without throwing", async () => { ... });
```

### Singleton / lifecycle

For packages that use the singleton + factory pattern, test the full lifecycle:

- `create()` initializes and stores the instance
- `getInstance()` returns the same instance
- `getInstance()` throws before `create()` is called
- `close()` flushes, cleans up, and clears the singleton
- `create()` can be called again after `close()` to reinitialize

```typescript
it("should return the same instance on repeated getInstance() calls", () => { ... });
it("should clear the singleton after close()", async () => { ... });
it("should reinitialize cleanly after close() + create()", async () => { ... });
```

### Per-transport / per-feature

If the package has multiple transports, adapters, or modes, **each one must have its own describe block** with at minimum a happy path and one error case.

```typescript
describe("console transport", () => {
  it("should log to stdout", () => { ... });
});

describe("MongoDB transport", () => {
  it("should write a log entry to the collection", async () => { ... });
  it("should reconnect after a dropped connection", async () => { ... });
});
```

### Per-function / per-method

Each public method or exported function gets its own `it` block — do not bundle multiple method calls into one test.

```typescript
// Wrong: one test covering create + log + close
it("should work end to end", async () => { ... });

// Right: each behaviour tested independently
it("should create with default level 'info'", async () => { ... });
it("should log at the specified level", async () => { ... });
it("should flush pending writes on close()", async () => { ... });
```

### Deep function-level matrix

For each public function/method and key helper function, plan both:

- one **happy-path** test (valid input, expected output)
- one **issue-path** test (invalid input, boundary case, or dependency failure)

Use this matrix in `docs/plan.md` before writing tests:

```markdown
| Function    | Happy path test                   | Issue path test             |
| ----------- | --------------------------------- | --------------------------- |
| uploadImage | valid image uploads successfully  | invalid content type throws |
| deleteImage | existing key deletes successfully | empty key throws            |
```

If happy path requires external infra (AWS, Redis, DB), keep it as an opt-in integration test guarded by env vars instead of skipping coverage entirely.

### Child / scoped instances

If the package supports scoped children (child loggers, request-scoped clients), test that:

- The child inherits parent config
- The child adds its own bindings without modifying the parent
- The parent's lifecycle does not break child usage

```typescript
it("should create a child logger that inherits parent transports", async () => { ... });
it("should not affect parent bindings when child bindings are added", () => { ... });
```

---

## Test Plan — Required Before Writing Tests

Before writing any test file, write a test plan inside `docs/plan.md` (in the `## Test Plan` section). The plan lists every `describe` block and its `it` cases so coverage decisions are visible and reviewable before code is written.

**Format:**

```markdown
## Test Plan

### Logger (singleton + lifecycle)

- create() with console transport → instance returned
- getInstance() before create() → throws
- getInstance() after create() → same instance
- close() → flushes + clears singleton
- create() after close() → reinitializes cleanly

### Console transport

- log at info level → message appears on stdout
- log at error level → message appears on stderr
- respects log level filter (debug not logged when level=info)

### MongoDB transport

- log entry written to collection → document found with correct msg
- connection failure → logs error and does not crash

### Child logger

- child inherits parent transports
- child bindings do not leak to parent
```

Write this plan in `docs/plan.md` **before** creating any test file. Update it as the package evolves.

---

## Summary Checklist

| Rule         | Key point                                                   |
| ------------ | ----------------------------------------------------------- |
| Mocking      | Never use mocks, stubs, or spies                            |
| Execution    | Always call real implementations                            |
| Side effects | Permitted — tests run against a dedicated test environment  |
| Isolation    | Each test must be independently runnable                    |
| Assertions   | Explicit, property-level checks — no snapshots              |
| Input/output | Use a single variable when comparing input vs output        |
| Happy path   | Always covered                                              |
| Edge cases   | Always covered — invalid input, missing config, error paths |
| Singleton    | Full lifecycle covered (create, get, close, reinit)         |
| Per-feature  | Each transport/adapter/mode has its own describe block      |
| Per-method   | Each public method has its own it block                     |
| Child/scoped | Covered if the package supports child instances             |
| Test plan    | Written in docs/plan.md before any test file is created     |
