---
name: commit-policy
description: Portable commit and change hygiene policy.
---

# Commit Policy Skill

Use when preparing commits or PR-ready changes.

## Rules

- Never commit secrets or credential files.
- Keep commits scoped to one logical change.
- Use message text that explains why, not only what.
- Run relevant checks before proposing completion.
- Do not amend or force-push unless explicitly requested.
