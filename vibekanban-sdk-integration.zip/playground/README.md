# Playground

This folder is reserved for experiments and quick prototypes that shouldn't be wired into the main production app or package tooling yet.

Ideas that fit here:

- quick front-end UI experiments
- experimental API shapes / request payload structures
- temporary demos that help validate end-to-end flows

If something becomes stable, it can be promoted into `app/` (backend) or a dedicated demo app like `front-end-demo/`.
