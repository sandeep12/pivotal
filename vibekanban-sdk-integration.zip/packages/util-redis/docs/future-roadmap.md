# Future Roadmap

Planned Redis capabilities to add after TTL record storage is production-ready:

- Distributed locking (`LockManager`)
- Event queueing (enqueue/consume with retries and dead-letter)
- Optional adapters for middleware record storage (e.g. `express-session`)
