## Future Roadmap — @util/rate-limit-core

- Sliding-window and token-bucket algorithms as optional strategies.
- Optional built-in Redis store implementation behind optional peer dependency.
- Optional built-in MongoDB store implementation.
- Distributed coordination utilities for advanced multi-region use cases.
- Metrics hooks (consume latency, allow/deny counters, per-scope cardinality).
- Framework adapters for Fastify and Koa.
