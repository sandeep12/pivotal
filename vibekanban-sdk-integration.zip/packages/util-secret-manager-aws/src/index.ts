import { AwsSecretManager } from "./aws-secret-manager.js";
import type { SecretManager, SecretManagerFactory } from "./interfaces.js";
import type { AwsSecretManagerConfig } from "./types.js";

export { AwsSecretManager };
export type { SecretManager, SecretManagerFactory, AwsSecretManagerConfig };
