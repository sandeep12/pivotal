type AwsSecretManagerConfig = {
  region?: string;
  credentials?: {
    accessKeyId: string;
    secretAccessKey: string;
    sessionToken?: string;
  };
};

export type { AwsSecretManagerConfig };
