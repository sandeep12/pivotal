---

## name: util-websocket

description: WebSocket server (ws) with sessions, session manager, and optional client wrapper.
metadata:
author: aatmix
version: "0.1.0"
path: packages/util-websocket

# @util/websocket

Lightweight WebSocket utilities for Nexus services, built on `ws`.

For full API reference see [README.md](./README.md).

## When to use

Use this package when the user needs:

- A **Node WebSocket server** with a simple `**onConnection` → `Session`\*\* model
- A **session registry** (`sessions.all()`, `get`, `broadcast`) without pulling in a full framework
- A **WebSocket endpoint attached to an existing HTTP server** (`attachWebSocketToHttpServer`)
- A thin **client** wrapper around `ws` with typed callbacks

Prefer something else (framework-specific plugins, Socket.IO, etc.) when you need rooms, automatic reconnection, or browser-first abstractions out of the box.

## Workspace usage (Nexus monorepo)

```bash
pnpm add @util/websocket --filter app
```

## Quick usage

```typescript
import { createServer, createClient } from "@util/websocket";

const server = createServer({ port: 8080 });
server.onConnection((session) => {
  session.onMessage((data) => session.send(data));
});

const client = createClient({ url: "ws://localhost:8080" });
client.onOpen(() => client.send("ping"));
```

## Rules

- Keep **authentication, authorization, and message schemas** in the app layer; this package only moves bytes and exposes session lifecycle hooks.
- Call `**onConnection` once** (or be aware it **replaces\*\* the previous handler).
- **Bind `port` (and TLS termination)** from environment or app config, not literals checked into source for production.
