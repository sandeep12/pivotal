## Future Roadmap -- @util/websocket

- Add optional heartbeat/ping-pong helpers for stale connection cleanup.
- Add connection metadata hooks (remote address, headers) on `Session`.
- Add lightweight reconnect/backoff helper in client wrapper (opt-in).
- Add per-session message size guardrails and configurable drop strategy.
- Add transport metrics hooks for observability (connections, bytes, errors).
