# @util/websocket -- Design Plan

Utility package for transport-level WebSocket primitives used by app channels and adapters.

## 1. Goals

- Provide a minimal `Session` abstraction for binary/string messaging and lifecycle hooks.
- Support two integration styles:
  - Standalone WS server (`createServer`)
  - HTTP-server upgrade attachment (`attachWebSocketToHttpServer`)
- Expose a thin WS client wrapper (`createClient`) for upstream/provider connections.
- Keep protocol concerns (auth, message schema, business rules) in app/service layers.

## 2. Public API

- `createServer(options)` -> `WebSocketServer`
- `attachWebSocketToHttpServer(options)` -> `{ close(): Promise<void> }`
- `createSession(socket, id)` -> `Session`
- `createSessionManager()` -> `SessionManager`
- `createClient(options)` -> `WebSocketClient`

## 3. Requirements

| ID  | Requirement                                       | Status |
| --- | ------------------------------------------------- | ------ |
| W1  | Session abstraction for send/onMessage/onClose    | Done   |
| W2  | Session manager with add/remove/get/all/broadcast | Done   |
| W3  | Standalone WS server creation                     | Done   |
| W4  | HTTP server upgrade attachment by path            | Done   |
| W5  | Client wrapper for upstream WS integrations       | Done   |
| W6  | NodeNext + ESM compatibility                      | Done   |

## 4. Test Plan

- `src/server.test.ts`: connection + echo behavior through server/session abstraction.
- `src/attach-http.test.ts`: attach-by-path behavior on existing HTTP server.
- Validate session manager operations and broadcast semantics.

## 5. Decision Log

| #   | Decision                            | Rationale                                         |
| --- | ----------------------------------- | ------------------------------------------------- |
| 1   | Use `ws` as sole runtime dependency | Small, stable, Node-focused                       |
| 2   | Keep package transport-only         | Preserve DDD boundaries; app owns protocol/domain |
| 3   | Add `attachWebSocketToHttpServer`   | Reuse same HTTP port as API server                |
