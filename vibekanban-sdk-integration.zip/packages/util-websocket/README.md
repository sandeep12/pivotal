# @util/websocket

Small helpers on top of `[ws](https://github.com/websockets/ws)`: a listenable WebSocket server with per-connection **sessions**, a **session manager**, and an optional **client** wrapper.

## Install

```bash
pnpm add @util/websocket
```

Requires **Node.js ≥ 22** (see repo `engines`). The package is **ESM** (`"type": "module"`).

## Quick start (server)

```typescript
import { createServer } from "@util/websocket";

const server = createServer({ port: 8080 });

server.onConnection((session) => {
  session.onMessage((data) => {
    session.send(data);
  });
});

// server.sessions.all(), .get(id), .broadcast(...)
// server.close();
```

## Quick start (client)

```typescript
import { createClient } from "@util/websocket";

const client = createClient({
  url: "ws://localhost:8080",
  headers: { Authorization: "Bearer …" }, // optional
});

client.onOpen(() => client.send(Buffer.from("hello")));
client.onMessage((buf) => {
  console.log(buf.toString());
});
client.close();
```

## Workspace usage (Nexus monorepo)

```bash
pnpm add @util/websocket --filter app
```

## API

### `attachWebSocketToHttpServer(options)`

- `**options**`: `{ httpServer: HttpServer; path: string; onSession(session): void }`
- Attaches WebSocket upgrade handling to an existing Node HTTP server at a path.
- Returns `{ close(): Promise<void> }` for graceful shutdown.

### `createServer(options)`

- `**options**`: `{ port: number }` — passed through to the underlying `WebSocketServer`.
- Returns a `**WebSocketServer**`:
  - `**onConnection(handler)**` — register the handler for new connections (call before or after clients connect; only the latest handler is used).
  - `**sessions**` — `**SessionManager**` for the current server instance.
  - `**close()**` — stops the server.

### `Session` (per connection)

- `**id**` — stable string id (`session-1`, `session-2`, … for the process lifetime).
- `**send(data)**` — `Buffer | string`.
- `**onMessage(handler)**` — binary `Buffer` payloads (non-empty only).
- `**onClose(handler)**`, `**close()**`.

### `SessionManager`

Created internally by `createServer`; you can also use `**createSessionManager()**` if you build a custom server.

- `**add` / `remove` / `get` / `all**`
- `**broadcast(data)**` — `Buffer | string` to every tracked session.

### `createClient(options)`

- `**options**`: `{ url: string; headers?: Record<string, string> }`.
- Returns `**WebSocketClient**`: `send`, `isOpen`, `onOpen`, `onMessage`, `onTextMessage`, `onError`, `onClose`, `close`.

## Design notes

- **Transport only** — no auth, routing, or framing protocol; wire that in your app (e.g. parse JSON in `onMessage`).
- **Handler registration** — `onConnection` replaces the previous handler; register once during startup for predictable behavior.
- **Ports** — pick ports from configuration; avoid hardcoding secrets; use TLS terminators or `wss:` in production as appropriate.

## Package layout

```text
packages/util-websocket/
  src/
  tsconfig.json
  package.json
  SKILL.md
  README.md
```

## Monorepo template sync

From the repository root, use `pnpm template:ensure`, `template:add`, `template:update`, or `template:pr` (see root `package.json`) when syncing `packages/*` with upstream.
