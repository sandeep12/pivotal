import http from "node:http";

import WebSocket from "ws";

import { attachWebSocketToHttpServer } from "./attach-http.js";

describe("attachWebSocketToHttpServer", () => {
  it("accepts connections on path and echoes binary", (done) => {
    const httpServer = http.createServer();
    const attached = attachWebSocketToHttpServer({
      httpServer,
      path: "/ws",
      onSession: (session) => {
        session.onMessage((data) => {
          session.send(data);
        });
      },
    });

    httpServer.listen(0, "127.0.0.1", () => {
      const addr = httpServer.address();
      if (addr === null || typeof addr === "string") {
        done(new Error("expected AddressInfo"));
        return;
      }
      const ws = new WebSocket(`ws://127.0.0.1:${addr.port}/ws`);
      const received: Buffer[] = [];

      ws.on("open", () => {
        ws.send(Buffer.from([4, 5, 6]));
      });

      ws.on("message", (data: WebSocket.RawData) => {
        received.push(
          Buffer.isBuffer(data) ? data : Buffer.from(data as ArrayBuffer)
        );
        if (received.length >= 1) {
          const finish = (err?: Error) => {
            ws.close();
            void attached.close().then(() => {
              httpServer.close(() => (err ? done(err) : done()));
            });
          };
          try {
            expect(received[0]).toEqual(Buffer.from([4, 5, 6]));
            finish();
          } catch (e) {
            finish(e as Error);
          }
        }
      });

      ws.on("error", (err) => {
        ws.close();
        void attached.close().then(() => {
          httpServer.close(() => done(err));
        });
      });
    });
  });
});
