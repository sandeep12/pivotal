import type { Server as HttpServer } from "node:http";

import type WebSocket from "ws";
import { WebSocketServer } from "ws";

import { createSession } from "./session.js";
import type { Session } from "./session.js";

export interface AttachWebSocketToHttpOptions {
  httpServer: HttpServer;
  path: string;
  onSession: (session: Session) => void;
}

export interface AttachWebSocketRouteOptions extends AttachWebSocketToHttpOptions {
  name: string;
  onAttached?: (meta: { name: string; path: string }) => void;
}

/**
 * WebSocket upgrade on an existing HTTP(S) server at `path` (same pattern as `ws` noServer: false).
 */
export function attachWebSocketToHttpServer(
  options: AttachWebSocketToHttpOptions
): { close: () => Promise<void> } {
  let sessionCounter = 0;
  const wss = new WebSocketServer({
    server: options.httpServer,
    path: options.path,
  });

  wss.on("connection", (socket: WebSocket) => {
    const id = `session-${++sessionCounter}`;
    const session = createSession(socket, id);
    options.onSession(session);
  });

  return {
    close: () =>
      new Promise<void>((resolve, reject) => {
        wss.close((err?: Error) => {
          if (err) reject(err);
          else resolve();
        });
      }),
  };
}

/**
 * Attach a named WebSocket route to an existing HTTP(S) server.
 * Optional `onAttached` callback lets consumers handle logging/metrics.
 */
export function attachWebSocketRoute(options: AttachWebSocketRouteOptions): {
  close: () => Promise<void>;
} {
  const attached = attachWebSocketToHttpServer(options);
  options.onAttached?.({ name: options.name, path: options.path });
  return attached;
}
