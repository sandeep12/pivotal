import { createServer } from "./index.js";
import WebSocket from "ws";

const PORT = 18081;

describe("util-websocket server", () => {
  it("echoes binary messages and tracks sessions", (done) => {
    const server = createServer({ port: PORT });

    server.onConnection((session) => {
      session.onMessage((data) => {
        session.send(data);
      });
    });

    const ws = new WebSocket(`ws://localhost:${PORT}`);
    const received: Buffer[] = [];

    ws.on("open", () => {
      expect(server.sessions.all().length).toBe(1);
      const session = server.sessions.all()[0];
      expect(session.id.startsWith("session-")).toBe(true);
      ws.send(Buffer.from([1, 2, 3]));
    });

    ws.on("message", (data: WebSocket.RawData) => {
      received.push(Buffer.isBuffer(data) ? data : Buffer.from(data as ArrayBuffer));
      if (received.length >= 1) {
        try {
          expect(received[0]).toEqual(Buffer.from([1, 2, 3]));
          server.close();
          ws.close();
          done();
        } catch (e) {
          server.close();
          ws.close();
          done(e as Error);
        }
      }
    });

    ws.on("error", (err) => {
      server.close();
      done(err);
    });
  });
});
