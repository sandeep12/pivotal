# @util/realtime -- Design Plan

Realtime protocol package for OpenAI Realtime adapter messages and Gemini Live SDK connector event handling.

## Goal

Provide reusable, strongly typed infrastructure primitives for realtime voice integrations while keeping provider protocols isolated from app/session business logic.

## Scope

- In scope:
  - OpenAI realtime adapter (`url`, headers, setup/audio/stop payloads, incoming parser)
  - Gemini Live SDK connector lifecycle and normalized events
  - Typed package exports for app integration
- Out of scope:
  - Websocket transport orchestration/reconnect policy
  - Conversation/business workflows
  - Provider account provisioning and secrets management

## Architecture

- OpenAI path:
  - Stateless adapter factory returns provider metadata and message builders
  - Parser converts inbound text frames into normalized `{ audio | event | providerError }`
- Gemini path:
  - Stateful connector wraps SDK session lifecycle
  - Callback events mapped into connector event union for app consumers
- Package boundary:
  - Protocol concerns only
  - App handles infra wiring, retries, and domain orchestration

## Public API

- `createProviderAdapter(mode, config)`
- `createOpenAIRealtimeAdapter(config)`
- `createGeminiLiveSdkConnector(config)`
- `extractPcmChunksFromGeminiLiveSdkMessage(message)`
- Type exports:
  - `AgentMode`
  - `ProviderAdapter`
  - `OpenAIRealtimeAdapterConfig`
  - `GeminiLiveSdkConfig`
  - `GeminiLiveSdkConnector`
  - `GeminiLiveSdkConnectorEvent`

## Phases

### Phase 1 -- Foundation

- Define package boundaries and contracts for OpenAI and Gemini integration points.
- Establish index exports and package ergonomics.
- Ensure package participates in monorepo TS project references.

### Phase 2 -- Core implementation

- Implement OpenAI adapter factories and parser normalization.
- Implement Gemini Live SDK connector lifecycle and event mapping.
- Add utility helpers for Gemini PCM extraction and typed event envelopes.

### Phase 3 -- Tests and reliability

- Add unit tests for parser/message generation and utility helpers.
- Add connector-level tests for event mapping and close/error handling.
- Validate fallback behavior on malformed payloads.

### Phase 4 -- Docs and developer experience

- Keep `README.md`, `SKILL.md`, and docs synchronized with current API.
- Provide quick-start examples for OpenAI and Gemini integrations.
- Track known limitations and roadmap items for next iteration.

## Requirements

| ID  | Requirement                                        | Status |
| --- | -------------------------------------------------- | ------ |
| R1  | OpenAI adapter provides setup/audio/stop messages  | Done   |
| R2  | OpenAI parser normalizes audio/event/error payload | Done   |
| R3  | Gemini connector exposes lifecycle methods         | Done   |
| R4  | Gemini connector emits normalized event union      | Done   |
| R5  | Package exports are typed and stable               | Done   |
| R6  | Tests exist for key parsing/connector behavior     | Done   |

## Test Plan

- Unit tests:
  - OpenAI adapter message shape and parser behavior
  - Gemini utility audio extraction behavior
  - Gemini connector event mapping and lifecycle transitions
- Type safety checks:
  - `pnpm --filter @util/realtime typecheck`
- Lint checks:
  - `pnpm --filter @util/realtime lint`
- Regression checks:
  - validate normalized output contracts consumed by app services

## Decision Log

| #   | Decision                                                  | Rationale                                                                   |
| --- | --------------------------------------------------------- | --------------------------------------------------------------------------- |
| 1   | Keep OpenAI path as a stateless adapter                   | Simple payload building and parser behavior does not need stateful wrappers |
| 2   | Keep Gemini SDK path as a stateful connector              | SDK live session lifecycle requires explicit connect/send/close semantics   |
| 3   | Keep `echo` mode outside this package                     | Echo is app behavior, not provider protocol integration                     |
| 4   | Use normalized event unions over provider-native payloads | Preserve provider flexibility while keeping app integration stable          |
