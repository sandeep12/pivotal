## Future Roadmap -- @util/realtime

- Add additional provider integrations behind consistent adapter/connector boundaries.
- Expand typed event contracts for high-value provider event families (for example tool calls, transcripts, and interruption semantics).
- Add optional observability hooks (metrics and structured logging callbacks) for connector lifecycle and parsing outcomes.
- Add conformance tests that assert compatibility across supported provider model versions.
- Add richer examples that demonstrate end-to-end wiring with `@util/websocket` and app-level session orchestration.
- Evaluate support for configurable audio transcoding helpers where providers expect non-PCM payload shapes.
