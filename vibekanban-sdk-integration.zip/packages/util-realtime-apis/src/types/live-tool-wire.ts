/**
 * Shared wire shapes for tool calls and results across Gemini Live and OpenAI Realtime.
 * Provider-specific tool *declarations* live on each config (`GeminiLiveSdkConfig.tools`,
 * `OpenAIRealtimeAdapterConfig.tools`).
 */

/** Normalized tool invocation emitted by connectors (Gemini `id` → `callId`). */
export interface RealtimeToolCallPayload {
  callId?: string;
  name: string;
  args: Record<string, unknown>;
}

/** One function result to send back to a provider after app-side execution. */
export interface RealtimeToolResult {
  callId?: string;
  name: string;
  output: Record<string, unknown>;
  isError?: boolean;
}
