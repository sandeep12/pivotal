import {
  openAiRealtimeToolResultMessages,
  parseOpenAiFunctionCallArgumentsJson,
} from "./function-call-protocol.js";

describe("parseOpenAiFunctionCallArgumentsJson", () => {
  it("parses valid JSON object", () => {
    expect(parseOpenAiFunctionCallArgumentsJson('{"format":"iso"}')).toEqual({
      format: "iso",
    });
  });

  it("returns empty object for invalid JSON", () => {
    expect(parseOpenAiFunctionCallArgumentsJson("{")).toEqual({});
  });
});

describe("openAiRealtimeToolResultMessages", () => {
  it("skips results without callId", () => {
    expect(
      openAiRealtimeToolResultMessages([{ name: "x", output: { a: 1 } }])
    ).toEqual([]);
  });

  it("emits function_call_output and response.create", () => {
    const messages = openAiRealtimeToolResultMessages([
      {
        callId: "call_1",
        name: "get_current_date",
        output: { iso: "2026-04-15T12:00:00.000Z" },
      },
    ]);
    expect(messages).toHaveLength(2);
    const item = JSON.parse(messages[0]) as Record<string, unknown>;
    expect(item.type).toBe("conversation.item.create");
    const created = item.item as Record<string, unknown>;
    expect(created.type).toBe("function_call_output");
    expect(created.call_id).toBe("call_1");
    expect(created.output).toBe('{"iso":"2026-04-15T12:00:00.000Z"}');
    expect(JSON.parse(messages[1])).toEqual({ type: "response.create" });
  });
});
