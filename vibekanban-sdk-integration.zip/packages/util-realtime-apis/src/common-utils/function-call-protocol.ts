import type { RealtimeToolResult } from "../types/live-tool-wire.js";

const defaultEmptyArgs = (): Record<string, unknown> => ({});

export function parseOpenAiFunctionCallArgumentsJson(
  argumentsJson: string
): Record<string, unknown> {
  if (!argumentsJson || argumentsJson.trim().length === 0) {
    return defaultEmptyArgs();
  }
  try {
    const parsed: unknown = JSON.parse(argumentsJson);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      return parsed as Record<string, unknown>;
    }
  } catch {
    /* fall through */
  }
  return defaultEmptyArgs();
}

/**
 * WebSocket messages to submit function outputs and continue the Realtime response.
 */
export function openAiRealtimeToolResultMessages(
  results: RealtimeToolResult[]
): string[] {
  const messages: string[] = [];
  for (const r of results) {
    if (!r.callId) {
      continue;
    }
    const payload = r.isError
      ? JSON.stringify({ error: r.output })
      : JSON.stringify(r.output);
    messages.push(
      JSON.stringify({
        type: "conversation.item.create",
        item: {
          type: "function_call_output",
          call_id: r.callId,
          output: payload,
        },
      })
    );
  }
  if (messages.length > 0) {
    messages.push(JSON.stringify({ type: "response.create" }));
  }
  return messages;
}
