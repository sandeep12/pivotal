import { createGeminiLiveSdkConnector } from "./gemini-live/connector.js";
import { createOpenAIRealtimeAdapter } from "./openai-realtime/adapter.js";

import type {
  GeminiLiveSdkConfig,
  GeminiLiveSdkConnector,
  GeminiLiveSdkConnectorEvent,
  GeminiLiveSdkClosedEvent,
  GeminiLiveSdkMessage,
  GeminiLiveSdkTranscriptEvent,
} from "./gemini-live/types.js";
import type {
  OpenAIRealtimeAdapterConfig,
  OpenAIRealtimeProviderAdapter,
  OpenAiRealtimeSessionTool,
} from "./openai-realtime/types.js";
import type {
  RealtimeToolCallPayload,
  RealtimeToolResult,
} from "./types/live-tool-wire.js";

export type { Tool } from "@google/genai";

export type AgentMode = "echo" | "openai" | "gemini";

export { createOpenAIRealtimeAdapter, createGeminiLiveSdkConnector };
export type {
  GeminiLiveSdkConfig,
  GeminiLiveSdkMessage,
  GeminiLiveSdkConnector,
  GeminiLiveSdkConnectorEvent,
  GeminiLiveSdkClosedEvent,
  GeminiLiveSdkTranscriptEvent,
  OpenAIRealtimeAdapterConfig,
  OpenAIRealtimeProviderAdapter as ProviderAdapter,
  OpenAiRealtimeSessionTool,
  RealtimeToolCallPayload,
  RealtimeToolResult,
};
export { extractPcmChunksFromGeminiLiveSdkMessage } from "./gemini-live/utils.js";

export function createProviderAdapter(
  mode: Exclude<AgentMode, "echo" | "gemini-sdk">,
  config: OpenAIRealtimeAdapterConfig
): OpenAIRealtimeProviderAdapter {
  if (mode !== "openai") {
    throw new Error(`Unsupported provider mode: ${String(mode)}`);
  }
  return createOpenAIRealtimeAdapter(config);
}
