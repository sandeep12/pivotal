import { Buffer } from "node:buffer";

import {
  openAiRealtimeToolResultMessages,
  parseOpenAiFunctionCallArgumentsJson,
} from "../common-utils/function-call-protocol.js";
import type {
  OpenAIRealtimeAdapterConfig,
  OpenAIRealtimeProviderAdapter,
} from "./types.js";

const DEFAULT_OPENAI_REALTIME_MODEL = "gpt-4o-realtime-preview";
const DEFAULT_SAMPLE_RATE = 16000;

function base64(chunk: Uint8Array): string {
  return Buffer.from(chunk).toString("base64");
}

export function createOpenAIRealtimeAdapter(
  config: OpenAIRealtimeAdapterConfig
): OpenAIRealtimeProviderAdapter {
  const { apiKey } = config;
  const model = config.model ?? DEFAULT_OPENAI_REALTIME_MODEL;
  const sampleRate = config.sampleRate ?? DEFAULT_SAMPLE_RATE;

  const url = `wss://api.openai.com/v1/realtime?model=${encodeURIComponent(model)}`;
  const inputFormat =
    sampleRate === 16000 ? "pcm16" : `pcm16_${Math.round(sampleRate)}hz`;

  const sessionTools = config.tools ?? [];

  const sessionPayload: Record<string, unknown> = {
    modalities: ["audio", "text"],
    input_audio_format: inputFormat,
    output_audio_format: "pcm16",
    turn_detection: {
      type: "server_vad",
    },
  };
  if (sessionTools.length > 0) {
    sessionPayload.tools = sessionTools;
  }

  return {
    provider: "openai",
    url,
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "OpenAI-Beta": "realtime=v1",
    },
    setupMessages: () => [
      JSON.stringify({
        type: "session.update",
        session: sessionPayload,
      }),
    ],
    audioMessage: (chunk: Uint8Array) =>
      JSON.stringify({
        type: "input_audio_buffer.append",
        audio: base64(chunk),
      }),
    stopMessages: () => [
      JSON.stringify({ type: "input_audio_buffer.commit" }),
      JSON.stringify({ type: "response.create" }),
    ],
    toolResultMessages: (results) => openAiRealtimeToolResultMessages(results),
    parseIncomingText: (text: string) => {
      let evt: Record<string, unknown>;
      try {
        evt = JSON.parse(text) as Record<string, unknown>;
      } catch {
        return {};
      }

      const type = evt.type;
      if (type === "response.audio.delta") {
        const delta = evt.delta;
        if (typeof delta === "string" && delta.length > 0) {
          return { audio: [Buffer.from(delta, "base64")] };
        }
        return {};
      }

      if (type === "response.function_call_arguments.done") {
        const item = evt.item as Record<string, unknown> | undefined;
        const name =
          typeof item?.name === "string"
            ? item.name
            : typeof evt.name === "string"
              ? evt.name
              : "";
        const rawArgs =
          typeof item?.arguments === "string"
            ? item.arguments
            : typeof evt.arguments === "string"
              ? evt.arguments
              : "{}";
        const callId =
          typeof item?.call_id === "string"
            ? item.call_id
            : typeof evt.call_id === "string"
              ? evt.call_id
              : undefined;
        const args = parseOpenAiFunctionCallArgumentsJson(rawArgs);
        return {
          event: evt,
          toolCalls: [{ callId, name, args }],
        };
      }

      if (type === "error") {
        const message =
          typeof evt.message === "string" ? evt.message : JSON.stringify(evt);
        return { providerError: message };
      }
      return { event: evt };
    },
  };
}
