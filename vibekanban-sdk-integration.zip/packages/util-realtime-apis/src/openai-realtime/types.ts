import type {
  RealtimeToolCallPayload,
  RealtimeToolResult,
} from "../types/live-tool-wire.js";

/** Shape of each `function` entry under Realtime `session.tools`. */
export interface OpenAiRealtimeSessionTool {
  type: "function";
  name: string;
  description?: string;
  parameters: Record<string, unknown>;
}

export interface OpenAIRealtimeAdapterConfig {
  apiKey: string;
  model?: string;
  sampleRate?: number;
  /** Passed through to Realtime `session.tools`. */
  tools?: OpenAiRealtimeSessionTool[];
}

export interface OpenAIRealtimeProviderAdapter {
  readonly provider: "openai";
  readonly url: string;
  readonly headers?: Record<string, string>;
  setupMessages(): string[];
  audioMessage(chunk: Uint8Array): string;
  audioStreamEndMessage?(): string;
  stopMessages(): string[];
  /** Messages to send after executing tools (function_call_output + response.create). */
  toolResultMessages(results: RealtimeToolResult[]): string[];
  parseIncomingText(text: string): {
    audio?: Uint8Array[];
    event?: Record<string, unknown>;
    providerError?: string;
    toolCalls?: RealtimeToolCallPayload[];
  };
}
