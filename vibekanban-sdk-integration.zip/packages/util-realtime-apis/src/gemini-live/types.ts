import type { Tool } from "@google/genai";

import type {
  RealtimeToolCallPayload,
  RealtimeToolResult,
} from "../types/live-tool-wire.js";

export interface GeminiLiveSdkConfig {
  apiKey: string;
  model?: string;
  systemInstruction?: string;
  voiceName?: string;
  inputAudioMimeType?: string;
  /** Passed to Gemini Live `config.tools` (SDK `Tool` entries). */
  tools?: Tool[];
}

export interface LiveServerMessage {
  setupComplete?: unknown;
  interrupted?: boolean;
  generationComplete?: boolean;
  inputTranscription?: { text?: string };
  outputTranscription?: { text?: string };
  modelTurn?: { parts?: unknown[] };
}

export interface GeminiLiveSdkMessage {
  setupComplete?: unknown;
  serverContent?: LiveServerMessage;
}

export interface GeminiLiveSdkTranscriptEvent {
  role: "user" | "assistant";
  text: string;
}

export interface GeminiLiveSdkClosedEvent {
  code?: number;
  reason?: string;
}

export type GeminiLiveSdkConnectorEvent =
  | { type: "ready" }
  | { type: "interrupted" }
  | { type: "audio"; chunks: Uint8Array[] }
  | { type: "transcript"; transcript: GeminiLiveSdkTranscriptEvent }
  | { type: "tool_call"; calls: RealtimeToolCallPayload[] }
  | { type: "tool_call_cancel"; ids: string[] }
  | { type: "provider_event"; payload: Record<string, unknown> }
  | { type: "error"; message: string }
  | { type: "closed"; details: GeminiLiveSdkClosedEvent };

export interface GeminiLiveSdkConnector {
  connect(): Promise<void>;
  sendAudioChunk(chunk: Uint8Array): void;
  endAudioStream(): void;
  /** Send app-executed tool results back to Gemini Live. */
  sendToolResults(results: RealtimeToolResult[]): void;
  close(): void;
  onEvent(handler: (event: GeminiLiveSdkConnectorEvent) => void): void;
}
