import type { GeminiLiveSdkMessage } from "./types.js";

function inlineDataFromPart(
  part: Record<string, unknown>
): { data?: string } | null {
  const inlineData = part.inlineData as Record<string, unknown> | undefined;
  const inline_data = part.inline_data as Record<string, unknown> | undefined;
  const audio = part.audio as Record<string, unknown> | undefined;
  for (const blob of [inlineData, inline_data, audio]) {
    if (blob && typeof blob.data === "string" && blob.data.length > 0) {
      return blob as { data: string };
    }
  }
  return null;
}

export function extractPcmChunksFromGeminiLiveSdkMessage(
  message: GeminiLiveSdkMessage
): Buffer[] {
  const out: Buffer[] = [];
  const parts = message.serverContent?.modelTurn?.parts;
  if (!Array.isArray(parts)) return out;
  for (const p of parts) {
    if (typeof p !== "object" || p === null) continue;
    const blob = inlineDataFromPart(p as Record<string, unknown>);
    if (blob?.data) {
      out.push(Buffer.from(blob.data, "base64"));
    }
  }
  return out;
}
