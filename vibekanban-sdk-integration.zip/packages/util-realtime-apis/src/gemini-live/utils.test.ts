import { extractPcmChunksFromGeminiLiveSdkMessage } from "./utils.js";

describe("extractPcmChunksFromGeminiLiveSdkMessage", () => {
  it("decodes inlineData base64 chunks", () => {
    const pcm = Buffer.from([1, 2, 3, 4]);
    const message = {
      serverContent: {
        modelTurn: {
          parts: [{ inlineData: { data: pcm.toString("base64") } }],
        },
      },
    };
    const out = extractPcmChunksFromGeminiLiveSdkMessage(message);
    expect(out).toHaveLength(1);
    expect(out[0]?.equals(pcm)).toBe(true);
  });

  it("accepts snake_case inline_data", () => {
    const pcm = Buffer.from([9]);
    const message = {
      serverContent: {
        modelTurn: {
          parts: [{ inline_data: { data: pcm.toString("base64") } }],
        },
      },
    };
    const out = extractPcmChunksFromGeminiLiveSdkMessage(message);
    expect(out).toHaveLength(1);
    expect(out[0]?.equals(pcm)).toBe(true);
  });

  it("returns empty when no parts", () => {
    expect(extractPcmChunksFromGeminiLiveSdkMessage({})).toEqual([]);
  });
});
