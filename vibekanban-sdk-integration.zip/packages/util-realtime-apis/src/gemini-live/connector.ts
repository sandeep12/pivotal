import {
  GoogleGenAI,
  Modality,
  type FunctionResponse,
  type Session,
  type LiveServerMessage,
} from "@google/genai";

import type { RealtimeToolResult } from "../types/live-tool-wire.js";
import { extractPcmChunksFromGeminiLiveSdkMessage } from "./utils.js";
import type {
  GeminiLiveSdkConfig,
  GeminiLiveSdkConnector,
  GeminiLiveSdkConnectorEvent,
  GeminiLiveSdkMessage,
} from "./types.js";

const DEFAULT_GEMINI_SDK_MODEL = "gemini-3.1-flash-live-preview";
const DEFAULT_SYSTEM_INSTRUCTION =
  "You are a helpful and friendly AI assistant.";
/** Gemini Live prebuilt voice (e.g. Puck, Charon, Kore, Fenrir, Aoede). */
const DEFAULT_VOICE_NAME = "Aoede";
const DEFAULT_INPUT_AUDIO_MIME_TYPE = "audio/pcm;rate=16000";

interface LiveErrorEvent {
  message?: unknown;
  error?: unknown;
}

interface LiveCloseEvent {
  code?: unknown;
  reason?: unknown;
}

const toErrorMessage = (event: LiveErrorEvent): string => {
  if (typeof event.message === "string" && event.message.length > 0) {
    return event.message;
  }
  if (event.error instanceof Error) {
    return event.error.message;
  }
  return String(event.error ?? "Gemini Live SDK error");
};

const providerConnectorEvent = (
  payload: Record<string, unknown>
): GeminiLiveSdkConnectorEvent => ({
  type: "provider_event",
  payload: { source: "gemini_live_sdk_connector", ...payload },
});

const geminiFunctionResponsesFromResults = (
  results: RealtimeToolResult[]
): FunctionResponse[] =>
  results.map(
    (r) =>
      ({
        ...(r.callId !== undefined ? { id: r.callId } : {}),
        name: r.name,
        response: r.isError ? { error: r.output } : { output: r.output },
      }) as FunctionResponse
  );

const handleServerMessage = (
  message: LiveServerMessage,
  emit: (event: GeminiLiveSdkConnectorEvent) => void
): void => {
  const toolCall = message.toolCall;
  if (toolCall?.functionCalls && toolCall.functionCalls.length > 0) {
    emit({
      type: "tool_call",
      calls: toolCall.functionCalls.map((fc) => ({
        callId: typeof fc.id === "string" ? fc.id : undefined,
        name: typeof fc.name === "string" ? fc.name : "",
        args:
          fc.args && typeof fc.args === "object" && !Array.isArray(fc.args)
            ? fc.args
            : {},
      })),
    });
  }
  const cancelIds = message.toolCallCancellation?.ids;
  if (cancelIds && cancelIds.length > 0) {
    emit({ type: "tool_call_cancel", ids: cancelIds });
  }

  const content = message.serverContent;
  if (message.setupComplete) {
    emit({ type: "ready" });
  }
  if (content?.interrupted) {
    emit({ type: "interrupted" });
  }
  if (content?.inputTranscription?.text) {
    emit({
      type: "transcript",
      transcript: {
        role: "user",
        text: content.inputTranscription.text,
      },
    });
  }
  if (content?.outputTranscription?.text) {
    emit({
      type: "transcript",
      transcript: {
        role: "assistant",
        text: content.outputTranscription.text,
      },
    });
  }
  const chunks = extractPcmChunksFromGeminiLiveSdkMessage(
    message as unknown as GeminiLiveSdkMessage
  );
  if (chunks.length > 0) {
    emit({ type: "audio", chunks });
  }
  if (content?.generationComplete) {
    emit(providerConnectorEvent({ generationComplete: true }));
  }
};

export const createGeminiLiveSdkConnector = (
  config: GeminiLiveSdkConfig
): GeminiLiveSdkConnector => {
  const ai = new GoogleGenAI({ apiKey: config.apiKey });

  const model = config.model ?? DEFAULT_GEMINI_SDK_MODEL;

  const systemInstruction =
    config.systemInstruction ?? DEFAULT_SYSTEM_INSTRUCTION;
  const voiceName = config.voiceName ?? DEFAULT_VOICE_NAME;

  const inputAudioMimeType =
    config.inputAudioMimeType ?? DEFAULT_INPUT_AUDIO_MIME_TYPE;

  const geminiTools = config.tools ?? [];

  let liveSession: Session | null = null;
  let closed = false;
  let eventHandler: ((event: GeminiLiveSdkConnectorEvent) => void) | null =
    null;

  return {
    onEvent: (handler) => {
      eventHandler = handler;
    },
    connect: async () => {
      if (closed) {
        throw new Error("Gemini Live SDK connector is closed");
      }
      if (liveSession) return;

      const emit = (event: GeminiLiveSdkConnectorEvent): void => {
        eventHandler?.(event);
      };
      const emitProvider = (payload: Record<string, unknown>): void => {
        emit(providerConnectorEvent(payload));
      };

      liveSession = await ai.live.connect({
        model,
        config: {
          responseModalities: [Modality.AUDIO],
          // Keep this literal shape aligned with the working sample.
          systemInstruction,
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: {
                voiceName,
              },
            },
          },
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          ...(geminiTools.length > 0 ? { tools: geminiTools } : {}),
        },
        callbacks: {
          onopen: () => {
            emitProvider({ stage: "onopen", model, voiceName });
          },
          onmessage: (message: LiveServerMessage) => {
            emitProvider({
              stage: "onmessage",
              hasSetupComplete: Boolean(message.setupComplete),
            });
            handleServerMessage(message, emit);
          },
          onerror: (event: unknown) => {
            const message = toErrorMessage((event ?? {}) as LiveErrorEvent);
            emitProvider({ stage: "onerror", errorMessage: message });
            emit({ type: "error", message });
          },
          onclose: (event: unknown) => {
            liveSession = null;
            const closeEvent = (event ?? {}) as LiveCloseEvent;
            const code =
              typeof closeEvent.code === "number" ? closeEvent.code : undefined;
            const reason =
              typeof closeEvent.reason === "string"
                ? closeEvent.reason
                : undefined;
            emitProvider({ stage: "onclose", code, reason });
            emit({ type: "closed", details: { code, reason } });
          },
        },
      });
    },
    sendAudioChunk: (chunk) => {
      if (!liveSession || closed || chunk.length === 0) return;
      liveSession.sendRealtimeInput({
        audio: {
          data: Buffer.from(chunk).toString("base64"),
          mimeType: inputAudioMimeType,
        },
      });
    },
    endAudioStream: () => {
      if (!liveSession || closed) return;
      liveSession.sendRealtimeInput({ audioStreamEnd: true });
    },
    sendToolResults: (results: RealtimeToolResult[]) => {
      if (!liveSession || closed || results.length === 0) return;
      liveSession.sendToolResponse({
        functionResponses: geminiFunctionResponsesFromResults(results),
      });
    },
    close: () => {
      if (closed) return;
      closed = true;
      const active = liveSession;
      liveSession = null;
      if (!active) return;
      try {
        active.close();
      } catch {
        /* ignore close errors */
      }
    },
  };
};
