---
name: util-realtime
description: Realtime provider adapter and Gemini Live SDK connector utilities. Use when wiring voice/audio streams to OpenAI Realtime or Gemini Live while keeping protocol logic isolated.
metadata:
  author: aatmix
  version: "0.1.0"
  path: packages/util-realtime-apis
---

# @util/realtime

Realtime protocol package for provider-specific message formatting and event normalization.

For full API reference see [README.md](./README.md).

## When to use

Use this package when you need:

- OpenAI realtime setup/audio/stop payload construction
- OpenAI realtime event parsing into normalized outputs
- Gemini Live SDK connector lifecycle (`connect`, `sendAudioChunk`, `endAudioStream`, `close`)
- Gemini event normalization into consistent connector events (`ready`, `audio`, `transcript`, `closed`, etc.)

Do not use this package as a transport or session manager. Pair with `@util/websocket` in app services/channels.

## Quick usage

```typescript
import {
  createProviderAdapter,
  createGeminiLiveSdkConnector,
} from "@util/realtime";

const adapter = createProviderAdapter("openai", {
  apiKey: process.env.OPENAI_API_KEY!,
  sampleRate: 16000,
});

const connector = createGeminiLiveSdkConnector({
  apiKey: process.env.GEMINI_API_KEY!,
});
```

## API surface

- `createProviderAdapter("openai", config)`
- `createOpenAIRealtimeAdapter(config)`
- `createGeminiLiveSdkConnector(config)`
- `extractPcmChunksFromGeminiLiveSdkMessage(message)`
- Type exports for OpenAI and Gemini connector contracts/events

## Guardrails

- Keep provider protocol specifics in this package.
- Keep env loading/secrets at app bootstrap and pass explicit config into factories.
- Do not move domain orchestration or conversation policy into adapters/connectors.
- Treat this package as infra utility layer, not application behavior layer.
