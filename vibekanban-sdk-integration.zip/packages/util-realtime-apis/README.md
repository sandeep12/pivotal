# @util/realtime

Provider adapters for realtime voice APIs, with support for OpenAI Realtime adapter messages and Gemini Live SDK connector events.

This package is protocol-focused. It builds provider-specific payloads/events while keeping transport and session orchestration in application services.

## Install

```bash
pnpm add @util/realtime
```

## Quick Start

### OpenAI Realtime adapter

```typescript
import { createProviderAdapter } from "@util/realtime";

const adapter = createProviderAdapter("openai", {
  apiKey: process.env.OPENAI_API_KEY!,
  sampleRate: 16000,
});

const setupMessages = adapter.setupMessages();
const audioMessage = adapter.audioMessage(new Uint8Array([1, 2, 3]));
const stopMessages = adapter.stopMessages();
```

### Gemini Live SDK connector

```typescript
import { createGeminiLiveSdkConnector } from "@util/realtime";

const connector = createGeminiLiveSdkConnector({
  apiKey: process.env.GEMINI_API_KEY!,
});

connector.onEvent((event) => {
  if (event.type === "audio") {
    // Forward PCM chunks to playback pipeline
  }
});

await connector.connect();
connector.sendAudioChunk(new Uint8Array([1, 2, 3]));
connector.endAudioStream();
```

## API

### Exports

- `createProviderAdapter(mode, config)` for OpenAI provider adapter creation
- `createOpenAIRealtimeAdapter(config)` direct OpenAI adapter factory
- `createGeminiLiveSdkConnector(config)` Gemini Live connector factory
- `extractPcmChunksFromGeminiLiveSdkMessage(message)` helper for PCM extraction
- Types:
  - `AgentMode`
  - `ProviderAdapter` (`OpenAIRealtimeProviderAdapter`)
  - `OpenAIRealtimeAdapterConfig`
  - `GeminiLiveSdkConfig`
  - `GeminiLiveSdkConnector`
  - `GeminiLiveSdkConnectorEvent`

### `createProviderAdapter(mode, config)`

- Supported `mode`: `"openai"` only
- Unsupported values throw an error (`"echo"` and `"gemini-sdk"` are app-level routing concerns)
- Returns `ProviderAdapter`

### `ProviderAdapter` (OpenAI)

- `provider`, `url`, optional `headers`
- `setupMessages(): string[]`
- `audioMessage(chunk: Uint8Array): string`
- `audioStreamEndMessage?(): string`
- `stopMessages(): string[]`
- `parseIncomingText(text: string): { audio?: Uint8Array[]; event?: Record<string, unknown>; providerError?: string }`

### `GeminiLiveSdkConnector`

- `connect(): Promise<void>`
- `sendAudioChunk(chunk: Uint8Array): void`
- `endAudioStream(): void`
- `close(): void`
- `onEvent(handler): void`

## Environment Variables

- OpenAI:
  - `OPENAI_API_KEY` (required)
  - `OPENAI_REALTIME_MODEL` (optional, if wired by consumer config)
- Gemini:
  - `GEMINI_API_KEY` (required)
  - `GEMINI_LIVE_MODEL` (optional, if wired by consumer config)

## Package Structure

```text
packages/util-realtime-apis/
├── docs/
│   ├── plan.md
│   └── future-roadmap.md
├── src/
│   ├── gemini-live/
│   ├── openai-realtime/
│   └── index.ts
├── package.json
├── tsconfig.json
├── README.md
└── SKILL.md
```

## Scripts

- `pnpm --filter @util/realtime build` - Build package output
- `pnpm --filter @util/realtime test` - Run Jest tests
- `pnpm --filter @util/realtime lint` - Run ESLint
- `pnpm --filter @util/realtime typecheck` - Run TypeScript checks

## Design Notes

- Keep provider protocol specifics in this package.
- Keep websocket lifecycle and retries in consumer app/infrastructure layers.
- Keep business/domain logic outside adapters/connectors.
