# @vibe/vk-remote-sdk

Small **Node 20+** (ESM) client for the Vibe Kanban **remote** HTTP API (`/v1`) plus helpers for **`issue.status_changed`** workflow callbacks.

## Install

Inside this monorepo the package is `private`; for external use, publish or `npm pack` from `packages/vk-remote-sdk` after `pnpm run build`.

## Usage

```ts
import { VkRemoteClient } from "@vibe/vk-remote-sdk";

// Direct remote `/v1` (self-hosted remote, cloud, etc.)
const remote = new VkRemoteClient({
  baseUrl: "https://your-remote-host",
  accessToken: process.env.VK_ACCESS_TOKEN!,
});

// Local desktop (`pnpm run dev`) — same origin as the browser; Vite proxies /api to Rust
const local = new VkRemoteClient({
  baseUrl: "http://localhost:3000",
  accessToken: "",
  transport: "localDesktop",
});

const { organizations } = await remote.organizations.list();
const created = await remote.createProject({
  organization_id: organizations[0].id,
  name: "SDK Project",
  color: "220 14% 96%",
});
```

### Local agent workflows (`/api`)

For local execution workflows (sessions, queue, workspace summaries, git status, execution stop), use `LocalAgentClient`:

```ts
import { LocalAgentClient } from "@vibe/vk-remote-sdk";

const agent = new LocalAgentClient({
  baseUrl: "http://localhost:3000",
});

const sessions = await agent.sessions.list(workspaceId);
const summaries = await agent.workspaces.summaries({ archived: false });
```

`LocalAgentClient` targets **local** `/api/...` routes (desktop server), while `VkRemoteClient` targets remote `/v1` (or local `/api/remote` proxy in `localDesktop` mode).

Extended methods are also available for session reset/setup/review, workspace CRUD/list, execution repo states, and WebSocket log stream URLs.

### MVP remote chain (hosted board + remote workspace row)

Typical automation: resolve **organization** → **project** → **project statuses** (columns) to get a `status_id` → **create issue** → **create remote workspace** linked to that issue (use the same `local_workspace_id` when starting the local agent).

```ts
const { projects } = await client.projects.list({
  organization_id: orgId,
});
const { project_statuses } = await client.projectStatuses.list({
  project_id: projects[0].id,
});
const statusId = project_statuses[0].id;

const { data: issue } = await client.issues.create({
  project_id: projects[0].id,
  status_id: statusId,
  title: "From automation",
  sort_order: 0,
  extension_metadata: {},
});

const localWorkspaceId = crypto.randomUUID();
const workspace = await client.workspaces.createAttachedToIssue({
  project_id: projects[0].id,
  issue_id: issue.id,
  local_workspace_id: localWorkspaceId,
  name: "Agent workspace",
  ownership: {
    // Ensure workspace owner follows task owner (issue creator)
    mode: "issueCreator",
  },
});
```

### Ownership-safe workspace attachment

When workspace click/open behavior depends on owner identity, use `createAttachedToIssue()` instead of raw `create()`:

- `mode: 'issueCreator'` — owner must match `issue.creator_user_id` (task owner path).
- `mode: 'explicitUser'` — owner must match `expected_owner_user_id`.
- `mode: 'none'` — skip ownership validation (default).

For “current logged-in desktop user” ownership, create through `transport: 'localDesktop'` so calls run with the desktop app’s session.

Not every remote route is mirrored under `/api/remote` on the desktop server; start with **organizations**, **project_statuses**, **issues**, and **workspaces** (see [`examples/README.md`](./examples/README.md)). Local dev needs **`VK_SHARED_API_BASE`** on the backend for those calls (see README there).

Webhook verification and server env helpers:

```ts
import {
  parseVerifiedWebhook,
  buildWorkflowCallbackEnv,
} from "@vibe/vk-remote-sdk";
```

Configure the **remote server** to POST callbacks using env vars (there is no REST “register webhook” API). See [`COMPATIBILITY.md`](./COMPATIBILITY.md) and [`crates/remote/WORKFLOW_CALLBACKS_PLAN.md`](../../crates/remote/WORKFLOW_CALLBACKS_PLAN.md).

## Scripts

- `pnpm run build` — emit `dist/` (`.js` + `.d.ts`)
- `pnpm run check` — `tsc -p tsconfig.json --noEmit`
- `pnpm run examples` — build, then run local demos (workflow env + webhook verify)
- From **monorepo root**: `pnpm run vk-remote-sdk:build`, then `pnpm run example:http`, `pnpm run vk-remote-sdk:example:mvp-chain`, or `pnpm run vk-remote-sdk:example:local-agent-mvp` (see [`examples/README.md`](./examples/README.md))

## Details

See [`IMPLEMENTATION_PLAN.md`](./IMPLEMENTATION_PLAN.md). Roadmap checklists: [`ACTION_ITEMS.md`](./ACTION_ITEMS.md) (remote SDK enhancements + `LocalAgentClient`). **MVP remote chain (org → project → statuses → issue → workspace):** [`REMOTE_SDK_MVP_ENHANCEMENT_PLAN.md`](./REMOTE_SDK_MVP_ENHANCEMENT_PLAN.md).
