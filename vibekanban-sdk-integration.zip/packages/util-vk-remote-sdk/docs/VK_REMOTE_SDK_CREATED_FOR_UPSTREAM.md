# vk-remote-sdk Created Artifacts (Upstream Reference)

This document captures what was created in `packages/vk-remote-sdk` so it can be reapplied during upstream sync/cherry-picking.

## Package metadata and setup

- `package.json`
  - New package: `@vibe/vk-remote-sdk` (`0.0.1`, private, ESM, Node `>=20`)
  - Build/check scripts using `tsc`
  - Example runner scripts (webhook, workflow env, HTTP, end-to-end flow)
  - Publishes only `dist/` via `files`
- `tsconfig.json`
  - TypeScript config for package build output and declarations
- `.gitignore`
  - Package-local ignore rules for build/runtime artifacts
- `.env.example`
  - SDK/example environment template

## Core SDK entrypoints

- `src/index.ts`
  - Barrel export for all public SDK APIs
  - Exports:
    - Remote client (`VkRemoteClient`)
    - Local client (`LocalAgentClient`)
    - Resource classes (organizations/projects/issues/workspaces/attachments/project statuses)
    - Webhook + workflow callback helpers
    - Shared types + local-agent types
    - Utility helpers (`createStepLogger`, MIME and attachment markdown helpers)
- `src/client.ts`
  - Main remote API client composition
- `src/http.ts`
  - HTTP transport layer and shared request option types
- `src/vk-remote-client.ts`
  - Convenience constructor wrapper (`createVkRemoteClient`)
- `src/errors.ts`
  - SDK error types (`VkApiError`, ownership mismatch error)

## Remote `/v1` resource modules

- `src/organizations.ts`
- `src/projects.ts`
- `src/project-statuses/project_statuses.ts`
- `src/project-statuses/kanban-defaults.ts`
- `src/issues.ts`
- `src/workspaces.ts`
- `src/attachments.ts`

These implement typed wrappers around remote operations, including:

- organization/project/status listing and mutation helpers
- issue create/update/list
- workspace create/update plus issue-attached ownership-safe creation
- attachment init/upload/confirm/commit flows

## Webhook and workflow callback helpers

- `src/webhooks.ts`
  - Signature verification and validated payload parsing for `issue.status_changed`
- `src/workflow-server-config.ts`
  - Helpers to construct/format server env values used by workflow callbacks

## Auth helper

- `src/auth/remote-local-login.ts`
  - Helper for self-hosted local-auth endpoint (`/v1/auth/local/login`)

## Local agent (`/api`) support

Created local desktop API client and resources:

- `src/local-agent/index.ts`
- `src/local-agent/client.ts`
- `src/local-agent/sessions.ts`
- `src/local-agent/workspaces.ts`
- `src/local-agent/repos.ts`
- `src/local-agent/execution-processes.ts`
- `src/local-agent/types-local-agent.ts`
- `src/local-agent/normalize-base-url.ts`
- `src/local-agent/repo-utils.ts`
- `src/local-agent/bootstrap-workspace.ts`
- `src/local-agent/resolve-workspace.ts`

Purpose:

- typed access to local `/api` routes for sessions/workspaces/repos/processes
- utilities for workspace bootstrap and repo branch normalization

## Shared and utility modules

- `src/types.ts`
  - Shared request/response and domain types (remote entities + webhook payload type)
- `src/utils/create-step-logger.ts`
- `src/utils/file-mime-type.ts`
- `src/utils/issue-attachments.ts`

## Environment variables used by SDK/examples

Primary runtime variables referenced by SDK examples and helper flows:

- `VK_SDK_TRANSPORT`
  - `remote` (default) for direct `/v1` calls, or `local`/local-desktop style flow for local `/api` proxy usage.
- `VK_REMOTE_BASE_URL`
  - Base origin for remote server (no `/v1` suffix), used in remote transport.
- `VK_REMOTE_ACCESS_TOKEN`
  - Bearer token used for authenticated remote API calls.
- `VK_LOCAL_API_BASE`
  - Local desktop/Vite origin (no `/api` suffix), used for local agent and local desktop transport examples.
- `VK_SHARED_API_BASE`
  - Not consumed by SDK package directly; consumed by local desktop backend at startup to enable proxied remote calls.

Auth and callback related:

- `VK_REMOTE_EMAIL`, `VK_REMOTE_PASSWORD`
  - Optional self-hosted local auth login fallback when token is not provided.
- `EXAMPLE_CALLBACK_URL`, `EXAMPLE_CALLBACK_SECRET`
  - Input vars for callback env generation demo scripts.
- `WEBHOOK_SECRET`, `WEBHOOK_TARGET_URL`, `WEBHOOK_PORT`
  - Used by webhook receiver/sender examples for signature verification and local callback testing.

End-to-end flow variables (examples):

- `VK_ENV_FILE`
  - Override default env file location for e2e script.
- `VK_MVP_PROJECT_ID`, `VK_MVP_ISSUE_TITLE`
  - Optional project/issue selection inputs in MVP scripts.
- `VK_LOCAL_API_BASE`
  - Enables strict local bootstrap path in e2e flow.
- `VK_E2E_LOCAL_REPO_ID`, `VK_E2E_LOCAL_TARGET_BRANCH`
  - Optional repo/branch selectors for local bootstrap.
- `VK_E2E_FILE_PATH`, `VK_E2E_SKIP_UPLOADS`
  - Attachment upload controls for e2e flow.
- `VK_E2E_LOCAL_FOLLOW_UP_PROMPT`, `VK_E2E_LOCAL_FOLLOW_UP_EXECUTOR`
  - Optional local follow-up/send-button simulation controls.

Workflow callback server-side variables (documented by SDK helpers):

- `VK_WORKFLOW_CALLBACK_URL`
- `VK_WORKFLOW_CALLBACK_SECRET`
- `VK_WORKFLOW_CALLBACK_TIMEOUT_MS`

These are set on the **remote server** side (not as SDK client runtime config) and are surfaced in SDK docs/examples so operators can configure callback delivery.

## Environment setup to run SDK/examples

Use one of these minimal env sets depending on how you run the SDK.

### 1) Remote mode (direct `/v1`)

Required:

- `VK_SDK_TRANSPORT=remote` (or omit; remote is default)
- `VK_REMOTE_BASE_URL=https://<remote-host>`
- `VK_REMOTE_ACCESS_TOKEN=<jwt>`

Optional:

- `VK_REMOTE_EMAIL`, `VK_REMOTE_PASSWORD` (self-hosted local-auth fallback path in e2e flow)

### 2) Local desktop mode (via local `/api` proxy)

Required:

- `VK_SDK_TRANSPORT=local`
- `VK_LOCAL_API_BASE=http://localhost:<frontend-port>`

Also required in the terminal that starts `pnpm run dev`:

- `VK_SHARED_API_BASE=https://<remote-host-serving-/v1>`

Notes:

- `VK_LOCAL_API_BASE` is for the Node script/client target.
- `VK_SHARED_API_BASE` is for local desktop backend remote-client config.
- They are usually different URLs.

### 3) End-to-end example mode

Common:

- `VK_ENV_FILE=examples/.env.e2e` (optional override)
- plus remote or local variables from sections above

Optional e2e controls:

- `VK_E2E_LOCAL_REPO_ID`
- `VK_E2E_LOCAL_TARGET_BRANCH`
- `VK_E2E_FILE_PATH`
- `VK_E2E_SKIP_UPLOADS=1`
- `VK_E2E_LOCAL_FOLLOW_UP_PROMPT`
- `VK_E2E_LOCAL_FOLLOW_UP_EXECUTOR`

### 4) Webhook local test mode

Receiver/sender examples:

- `WEBHOOK_SECRET=dev-secret`
- `WEBHOOK_TARGET_URL=http://127.0.0.1:8765/vk-workflow`
- `WEBHOOK_PORT=8765`

Server-side callback vars (set on remote server process):

- `VK_WORKFLOW_CALLBACK_URL`
- `VK_WORKFLOW_CALLBACK_SECRET`
- `VK_WORKFLOW_CALLBACK_TIMEOUT_MS`

## Examples and docs

- `README.md`
  - package usage for remote + local transport
  - workflow callback usage and scripts
- `examples/README.md`
  - runnable example guide
- `examples/.env.e2e.example`
  - env template for end-to-end flow
- `examples/end-to-end-workspace-flow.mjs`
  - automation flow script (org -> project -> statuses -> issue -> workspace + local bootstrap/upload path)
- `examples/webhook-verify.mjs`
  - webhook verification example

## File inventory (created)

All currently created tracked-intent files under `packages/vk-remote-sdk`:

- `.env.example`
- `.gitignore`
- `README.md`
- `examples/.env.e2e.example`
- `examples/README.md`
- `examples/end-to-end-workspace-flow.mjs`
- `examples/webhook-verify.mjs`
- `package.json`
- `src/attachments.ts`
- `src/auth/remote-local-login.ts`
- `src/client.ts`
- `src/errors.ts`
- `src/http.ts`
- `src/index.ts`
- `src/issues.ts`
- `src/local-agent/bootstrap-workspace.ts`
- `src/local-agent/client.ts`
- `src/local-agent/execution-processes.ts`
- `src/local-agent/index.ts`
- `src/local-agent/normalize-base-url.ts`
- `src/local-agent/repo-utils.ts`
- `src/local-agent/repos.ts`
- `src/local-agent/resolve-workspace.ts`
- `src/local-agent/sessions.ts`
- `src/local-agent/types-local-agent.ts`
- `src/local-agent/workspaces.ts`
- `src/organizations.ts`
- `src/project-statuses/kanban-defaults.ts`
- `src/project-statuses/project_statuses.ts`
- `src/projects.ts`
- `src/types.ts`
- `src/utils/create-step-logger.ts`
- `src/utils/file-mime-type.ts`
- `src/utils/issue-attachments.ts`
- `src/vk-remote-client.ts`
- `src/webhooks.ts`
- `src/workflow-server-config.ts`
- `src/workspaces.ts`
- `tsconfig.json`

## Upstream apply checklist

- [ ] Add package scaffolding (`package.json`, `tsconfig.json`, env/examples docs).
- [ ] Add core transport + client + index exports.
- [ ] Add remote `/v1` resource modules.
- [ ] Add webhook/workflow helper modules.
- [ ] Add local-agent client/resources/types/utilities.
- [ ] Add shared types and utility helpers.
- [ ] Add/validate examples for e2e flow and webhook verification.
