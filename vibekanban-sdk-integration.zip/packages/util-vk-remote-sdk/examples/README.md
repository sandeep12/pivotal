# Examples

Examples are plain **Node ESM** (`.mjs`) and import the **built** package from `../dist/`.

From **repo root** (after `pnpm run vk-remote-sdk:build`):

```bash
pnpm run example:http
pnpm run vk-remote-sdk:example:workflow-env
pnpm run vk-remote-sdk:example:webhook
pnpm run vk-remote-sdk:example:mvp-chain
pnpm run vk-remote-sdk:example:local-agent-mvp
pnpm run vk-remote-sdk:example:e2e-flow
pnpm run vk-remote-sdk:example:local-workspace-min-sequence
```

From `packages/vk-remote-sdk` you can use the same names without the `vk-remote-sdk:` prefix (e.g. `pnpm run build && pnpm run example:http`).

### `06-mvp-remote-chain.mjs`

Lists **project statuses** for `VK_MVP_PROJECT_ID`, creates an **issue**, then a **remote workspace** with a new `local_workspace_id`. Requires the same auth as `03` (`VK_REMOTE_*` or local desktop + `VK_SDK_TRANSPORT=local`). Optional: `VK_MVP_ISSUE_TITLE`.

### `07-local-agent-mvp.mjs`

Uses `LocalAgentClient` against local `/api` to list/create sessions, inspect queue state, and fetch workspace summaries + git status.
Uses CLI args (no env required for local agent), e.g. `--local-base-url http://localhost:3000`.
Supports optional workspace hints (`--local-workspace-id`, `--local-workspace-name`) and creates a workspace if none exists.

### `10-local-workspace-min-sequence.mjs`

Minimal required local API sequence to ensure `git/status` works:

- list repos (`GET /api/repos`)
- create workspace (`POST /api/workspaces`)
- attach repo (`POST /api/workspaces/{id}/repos`)
- verify attached repos (`GET /api/workspaces/{id}/repos`)
- list/create session (`GET/POST /api/sessions`)
- fetch git status (`GET /api/workspaces/{id}/git/status`)

Run with:

```bash
node examples/10-local-workspace-min-sequence.mjs \
  --local-base-url http://localhost:3000 \
  --workspace-name "SDK Minimal Local Workspace"
```

### `08-end-to-end-workspace-flow.mjs`

End-to-end board flow for automation:

- loads **`examples/.env.e2e`** by default (override with `VK_ENV_FILE`); copy from **`examples/.env.e2e.example`**
- picks the **first organization** and **first project**
- resolves statuses and prefers **To do/TODO** + **In progress**
- creates an issue in TODO
- creates a linked workspace with `local_workspace_id`
- if `VK_LOCAL_API_BASE` is set, the script now runs strict local bootstrap before remote workspace creation: `GET /api/repos` → create local workspace → attach repo (`POST /api/workspaces/{id}/repos`) → verify `/repos` and `git/status`; failures are fatal (non-zero exit)
- uploads and commits a tiny `.js` file attachment; if **`VK_E2E_FILE_PATH`** is set, uploads that file too (e.g. `.docx`) — requires blob storage on the remote; use **`VK_E2E_SKIP_UPLOADS=1`** to skip uploads when storage is not configured
- if **`VK_REMOTE_EMAIL`** + **`VK_REMOTE_PASSWORD`** are set (and no `VK_REMOTE_ACCESS_TOKEN`), calls **`POST /v1/auth/local/login`** on **`VK_REMOTE_BASE_URL`** (self-hosted local auth)
- moves the issue to In Progress
- validates workspace linkage and prints clickability hints
- optional: **`VK_LOCAL_API_BASE`** — enables strict local bootstrap (required local readiness checks) before remote workspace creation
- optional local bootstrap selectors: `VK_E2E_LOCAL_REPO_ID` (pick a specific local repo), `VK_E2E_LOCAL_TARGET_BRANCH` (override branch used during attach)
- optional local send-button simulation:
  - `VK_E2E_LOCAL_FOLLOW_UP_PROMPT` — if set, script calls local `POST /api/sessions/{id}/follow-up` on the bootstrapped workspace
  - `VK_E2E_LOCAL_FOLLOW_UP_EXECUTOR` — optional executor override for that follow-up (defaults to session executor, then `CURSOR_AGENT`)
- optional scratch defaults: `VK_E2E_PROJECT_REPO_DEFAULTS=1` — when `VK_LOCAL_API_BASE` is set, exercises `PUT` then `GET` `/api/scratch/PROJECT_REPO_DEFAULTS/{project_id}` using the bootstrapped repo (non-fatal on failure)

**Attachments vs UI / Azure:** blobs go to the storage container (default **`issue-attachments`**, blob name prefix `attachments/{project_id}/…`). The Kanban description editor only **renders** uploads when the issue description contains `attachment://…` markdown; the script now uses a **staged** confirm → **`commitToIssue`** flow and patches the description so files show on the task. Remote **workspaces** do not store attachments — link files to the **issue** (or a **comment**).

Use this when debugging "workspace not clickable after programmatic move". The most common cause is ownership mismatch: the workspace row owner must match the currently signed-in desktop user, and `local_workspace_id` must be set.

### Local desktop (`pnpm run dev`)

The desktop server exposes proxied remote routes under `/api` and `/api/remote` and uses the **session already stored in the app** (not a Bearer token from this script).

1. Start Vibe Kanban locally (`pnpm run dev` from the repo root) and sign in to remote/cloud in the UI.
2. Set `**VK_LOCAL_API_BASE` to the same origin as the browser** (DevTools → Network), e.g. `http://localhost:3000`. In dev, **Vite proxies `/api`** to Rust (`packages/local-web/vite.config.ts`), so scripts should usually target **Vite’s port** (repo-root `**.dev-ports.json`** → `"frontend"`), not a port where nothing listens.
3. Run:

```bash
export VK_SDK_TRANSPORT=local
# Optional if .dev-ports.json exists — example uses "frontend" → http://localhost:<port>
# export VK_LOCAL_API_BASE=http://localhost:3000
pnpm run build && pnpm run example:http
```

For `**crates/remote**` in Docker (real `**/v1**` on the host), use `**remote**` transport + `**VK_REMOTE_BASE_URL**` + JWT — that is **not** the Vite `/api` proxy.

### `VK_LOCAL_API_BASE` vs `VK_SHARED_API_BASE` (do **not** set both to the same URL in typical dev)

| Variable                   | Who reads it                                                                 | What it must be                                                                                                                                                                                                                                                                                                                                 |
| -------------------------- | ---------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `**VK_LOCAL_API_BASE`\*\*  | This **Node** example only                                                   | **Vite** origin (browser tab), e.g. `http://localhost:3001` — where `/api` is proxied to the desktop Rust server.                                                                                                                                                                                                                               |
| `**VK_SHARED_API_BASE`\*\* | **Desktop Rust** at `**pnpm run dev` startup\*\* (`crates/local-deployment`) | Base URL of the **remote API** (`/v1/...`). For **local dev without self-hosting remote**, this is usually your **cloud** origin (see root `README.md`). Self-hosted `**crates/remote`** (Docker or otherwise) is optional — use its URL only if you actually run it. **Never\*\* point this at Vite unless that same host really serves `/v1`. |

If `**VK_SHARED_API_BASE`** points at **Vite** (same host/port as the browser), `RemoteClient` calls `**/v1/...`** against the wrong process (Vite does not serve `/v1`), and remote features break or misbehave. When you run **both** Vite and self-hosted remote locally, the two ports **differ** (e.g. Vite `3001`, remote `3000`).

### `ECONNREFUSED` on local desktop

Nothing is accepting TCP on that URL. `**pnpm run dev` must be running.** `setup-dev-environment.js get` does not start servers. Prefer `**http://localhost:<frontend>`** from `.dev-ports.json` / the browser address bar, not a stale or internal-only port.

### HTTP 400: `Remote client not configured`

The desktop **Rust** server only enables cloud/remote API calls when `**VK_SHARED_API_BASE`** is set in the environment **before** you start `pnpm run dev` (see `crates/local-deployment`). Without it, routes like `**/api/organizations`** fail even though purely local routes (e.g. `**/api/workspaces/summaries**`) can still work in the browser.

1. `export VK_SHARED_API_BASE=https://…` to your **cloud** remote API, **or** to `http://127.0.0.1:<port>` only if you run `**crates/remote`\*\* yourself on that port (Docker not required).
2. **Fully restart** `**pnpm run dev`** from a shell that already has `**VK_SHARED_API_BASE**`(export it *before* starting dev in that same terminal, or`source .env`there). Variables you set only in the terminal where you run`example:http` do **not\*\* change a backend that is already running elsewhere.
3. Sign in to remote in the app, then run the SDK example again.

### Testing workflow webhooks (`issue.status_changed`)

Callbacks are implemented on `**crates/remote*`\* (see `[crates/remote/WORKFLOW_CALLBACKS_PLAN.md](../../crates/remote/WORKFLOW_CALLBACKS_PLAN.md)`). The remote server **POSTs JSON** to `**VK_WORKFLOW_CALLBACK_URL`** with optional `**X-VK-Signature: sha256=...**`when an issue’s`**status_id\*\*` changes after commit.

#### 1) SDK only (no remote process)

Verifies HMAC + parsing against a synthetic payload:

```bash
pnpm run vk-remote-sdk:build
pnpm run vk-remote-sdk:example:webhook
```

Prints `**VK_WORKFLOW_CALLBACK_***` env lines for a **self-hosted** remote (operators paste into compose / systemd):

```bash
pnpm run vk-remote-sdk:example:workflow-env
```

#### 2) Local receiver + signed POST (two terminals)

Minimal `**POST /vk-workflow**` server uses `**parseVerifiedWebhook**` from the SDK. Sender signs the same way the remote server does.

From **repo root**:

```bash
pnpm run vk-remote-sdk:build
```

**Terminal A** (leave running):

```bash
pnpm run vk-remote-sdk:example:webhook-server
```

**Terminal B**:

```bash
pnpm run vk-remote-sdk:example:webhook-send
```

Defaults: receiver `http://127.0.0.1:8765/vk-workflow`, shared secret `**dev-secret**` (override with `**WEBHOOK_SECRET**`, `**WEBHOOK_TARGET_URL**`). Terminal A should log `issue.status_changed` and return `200 {"ok":true}`.

#### 3) End-to-end (real status change → real POST)

You must run `**crates/remote**` somewhere you control and set:

| Variable                      | Purpose                                                                                                                                |
| ----------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| `VK_WORKFLOW_CALLBACK_URL`    | Full URL the remote server will **POST** to (must match your listener path, e.g. `http://127.0.0.1:8765/vk-workflow` for local tests). |
| `VK_WORKFLOW_CALLBACK_SECRET` | Optional; if set, must match what your receiver uses to verify `**X-VK-Signature`\*\*.                                                 |

**Reachability:** the **remote** process must be able to open a TCP connection to that URL. If remote runs in **Docker** and the receiver on the host, use a URL the container can resolve (e.g. `http://host.docker.internal:8765/vk-workflow` on Docker Desktop, or **ngrok** / **Cloudflare Tunnel** to a public HTTPS URL).

**Hosted cloud (`https://api.vibekanban.com`):** you generally **cannot** set `VK_WORKFLOW_CALLBACK_`\* on that deployment yourself; full E2E is for **self-hosted** remote. With only local desktop + cloud API, use **§1–2** to validate your consumer code.

After configuring the remote, **change an issue’s column/status** in the UI (or via API); you should see a POST on the receiver.

Environment variables:

| Variable                  | Used in                                                                                                                          |
| ------------------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| `VK_SDK_TRANSPORT`        | `03` — set to `local` for desktop server; omit or `remote` for `/v1` API                                                         |
| `VK_LOCAL_API_BASE`       | `03` when local — **browser / Vite origin**, e.g. `http://localhost:3000` (no `/api` suffix)                                     |
| `VK_SHARED_API_BASE`      | **Not** read by this script — set **before** `pnpm run dev`; must be the **remote `/v1` API** origin, not Vite (see table above) |
| `VK_REMOTE_BASE_URL`      | `03` — remote origin, no `/v1` suffix                                                                                            |
| `VK_REMOTE_ACCESS_TOKEN`  | `03` — Bearer JWT for remote transport                                                                                           |
| `EXAMPLE_CALLBACK_URL`    | `01-workflow-callback-env.mjs` — defaults to `https://hooks.example.com/vk`                                                      |
| `EXAMPLE_CALLBACK_SECRET` | Optional secret for env snippet                                                                                                  |
| `WEBHOOK_SECRET`          | `04-webhook-receiver.mjs` — must match `05-webhook-send.mjs` (default `dev-secret`)                                              |
| `WEBHOOK_PORT`            | Receiver listen port (default `8765`)                                                                                            |
