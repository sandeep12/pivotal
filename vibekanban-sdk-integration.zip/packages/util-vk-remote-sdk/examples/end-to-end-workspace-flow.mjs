/**
 * End-to-end SDK flow with env file + optional local auth login:
 *
 * Loads env from `examples/.env.e2e` by default (override with `VK_ENV_FILE`).
 * For self-hosted remote with local email/password (`SELF_HOST_LOCAL_AUTH_*` on server):
 *   `POST {VK_REMOTE_BASE_URL}/v1/auth/local/login` → `VK_REMOTE_ACCESS_TOKEN`
 *
 * Flow:
 * 1) org (first) → project (first) → statuses (TODO + In Progress)
 * 2) create issue in TODO, create linked workspace, upload attachments
 * 3) move issue to In Progress, verify workspace row
 * 4) if `VK_LOCAL_API_BASE` is set and `VK_E2E_SKIP_LOCAL_DESKTOP` is not set, run strict local bootstrap:
 *    create local workspace, attach repo via `LocalAgentClient`, verify workspace repos + `gitStatus`.
 *    Then exercise `/api/sessions/{id}/queue`: GET status, POST a sample message (override with
 *    `VK_E2E_LOCAL_QUEUE_MESSAGE`), GET again, DELETE cancel, GET empty. Optional follow-up still
 *    uses `VK_E2E_LOCAL_FOLLOW_UP_PROMPT`.
 *    Optional: `VK_E2E_PROJECT_REPO_DEFAULTS=1` — PUT/GET `/api/scratch/PROJECT_REPO_DEFAULTS/{project_id}`
 *    using the bootstrapped repo (non-fatal on failure).
 *
 * From `packages/vk-remote-sdk`:
 *   pnpm run build && pnpm run example:e2e-flow
 */
import { randomUUID } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';
import { basename, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { TextEncoder } from 'node:util';

import {
  LocalAgentClient,
  getFileMimeType,
  bootstrapLocalWorkspaceWithRegisteredRepo,
  buildSmokeTestJsModuleContent,
  createStepLogger,
  createVkRemoteClient,
  formatIssueAttachmentMarkdownLine,
  getProjectRepoDefaults,
  normalizeLocalAgentBaseUrl,
  readVkE2eWorkspaceFlowEnvOptions,
  readVkRemoteSdkConfigFromEnv,
  resolveDefaultKanbanTodoAndInProgressStatuses,
  saveProjectRepoDefaults,
} from '../dist/index.js';

const stepDone = createStepLogger('e2e');

const scriptDir = dirname(fileURLToPath(import.meta.url));

function loadEnvFileIfExists(filePath) {
  if (!existsSync(filePath)) {
    return false;
  }

  const text = readFileSync(filePath, 'utf8');
  for (const rawLine of text.split('\n')) {
    const line = rawLine.replace(/\r$/, '');
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) {
      continue;
    }
    const eq = trimmed.indexOf('=');
    if (eq <= 0) {
      continue;
    }
    const key = trimmed.slice(0, eq).trim();
    let value = trimmed.slice(eq + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    if (process.env[key] === undefined) {
      process.env[key] = value;
    }
  }
  return true;
}

const envPath =
  process.env.VK_ENV_FILE?.trim() || join(scriptDir, '.env.e2e');
if (!loadEnvFileIfExists(envPath)) {
  console.error(
    `Missing env file: ${envPath}\nCopy examples/.env.e2e.example to examples/.env.e2e and edit.`,
  );
  process.exit(1);
}
stepDone('Loaded env file', envPath);

const sdkConfig = readVkRemoteSdkConfigFromEnv();
const e2eEnv = readVkE2eWorkspaceFlowEnvOptions();
stepDone('Parsed SDK config from env', `transport=${sdkConfig.transport}`);

let client;
try {
  client = await createVkRemoteClient({ config: sdkConfig, onStep: stepDone });
} catch (err) {
  console.error(err instanceof Error ? err.message : String(err));
  process.exit(1);
}

const { organizations } = await client.organizations.list();
if (!organizations.length) {
  console.error('No organizations available for this account.');
  process.exit(1);
}
const org = organizations[0];
stepDone('Listed organizations', `picked "${org.name}" (${org.id})`);

const { projects } = await client.projects.list({ organization_id: org.id });
let project = projects[0] ?? null;

if (!project) {
  const projectName = 'SDK E2E Project';
  const projectColor = '220 14% 96%';
  const { data: createdProject } = await client.projects.create({
    organization_id: org.id,
    name: projectName,
    color: projectColor,
  });
  project = createdProject;
  stepDone('Created project', `"${project.name}" (${project.id})`);
} else {
  stepDone('Listed projects', `picked "${project.name}" (${project.id})`);
}

const { project_statuses } = await client.projectStatuses.list({
  project_id: project.id,
});
if (!project_statuses.length) {
  console.error(`No statuses found in project "${project.name}".`);
  process.exit(1);
}

const { todo: todoStatus, inProgress: inProgressStatus } =
  resolveDefaultKanbanTodoAndInProgressStatuses(project_statuses);
stepDone(
  'Resolved statuses',
  `todo="${todoStatus.name}" (${todoStatus.id}), in_progress="${inProgressStatus.name}" (${inProgressStatus.id})`,
);

const issueTitle = `SDK E2E ${new Date().toISOString()}`;
const { data: issue } = await client.issues.create({
  project_id: project.id,
  status_id: todoStatus.id,
  title: issueTitle,
  description: 'Created by 08-end-to-end-workspace-flow.mjs',
  sort_order: 0,
  extension_metadata: {},
});
stepDone('Created issue', `${issue.simple_id} (${issue.id})`);

let localWorkspaceId = '';
const localBaseForEnsure = e2eEnv.localApiBase ?? undefined;
/** @type {Record<string, unknown> | null} */
let localAgentProbe = null;

if (localBaseForEnsure) {
  try {
    const localAgentBase = normalizeLocalAgentBaseUrl(localBaseForEnsure);
    const localAgent = new LocalAgentClient({ baseUrl: localAgentBase });
    const localBootstrap = await bootstrapLocalWorkspaceWithRegisteredRepo(
      localAgent,
      localAgentBase,
      {
        workspaceName: `SDK E2E Local ${issue.simple_id}`,
        repoId: e2eEnv.localRepoId,
        targetBranch: e2eEnv.localTargetBranch,
      },
    );
    localWorkspaceId = localBootstrap.workspace.id;
    stepDone(
      'Bootstrapped local workspace',
      `id=${localWorkspaceId}, repo=${localBootstrap.selectedRepo.name}, target_branch=${localBootstrap.targetBranch}`,
    );
    localAgentProbe = {
      workspace_id: localWorkspaceId,
      workspace_name: localBootstrap.workspace.name,
      local_base: localBootstrap.localBaseUrl,
      selected_repo: {
        id: localBootstrap.selectedRepo.id,
        name: localBootstrap.selectedRepo.name,
      },
      target_branch: localBootstrap.targetBranch,
      gitStatus: localBootstrap.gitStatus,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    const target =
      typeof localBaseForEnsure === 'string' ? localBaseForEnsure : String(localBaseForEnsure);
    console.error(
      [
        '[e2e] Local bootstrap failed (script requires a reachable desktop when VK_LOCAL_API_BASE is set).',
        `Tried: ${target}`,
        `Error: ${message}`,
        '',
        'Remote-only: set VK_E2E_SKIP_LOCAL_DESKTOP=1 or remove/comment VK_LOCAL_API_BASE in .env.e2e.',
        'With local: start the app so this URL responds (e.g. from repo root `pnpm run dev` for Vite on 3000).',
        'Also ensure this URL is the desktop /api origin, not the same port as VK_REMOTE_BASE_URL.',
      ].join('\n'),
    );
    process.exit(1);
  }
} else {
  localWorkspaceId = randomUUID();
  stepDone(
    'No local bootstrap',
    e2eEnv.skipLocalDesktopSections
      ? 'VK_E2E_SKIP_LOCAL_DESKTOP is set (or VK_LOCAL_API_BASE unset); using generated local_workspace_id'
      : 'VK_LOCAL_API_BASE is unset; using generated local_workspace_id',
  );
}

const workspace = await client.workspaces.create({
  project_id: project.id,
  issue_id: issue.id,
  local_workspace_id: localWorkspaceId,
  name: `SDK E2E Workspace ${issue.simple_id}`,
});
stepDone(
  'Created workspace',
  `remote id=${workspace.id}, local_workspace_id=${localWorkspaceId}`,
);

/** @type {{ id: string; filename: string; size_bytes: number } | null} */
let attachmentJs = null;
/** @type {{ id: string; filename: string; size_bytes: number } | null} */
let attachmentDocx = null;
/** @type {Awaited<ReturnType<typeof client.attachments.listForIssue>> | null} */
let issueAttachmentsListed = null;
const localBase = e2eEnv.localApiBase;
const remoteBase = sdkConfig.remoteBaseUrl ?? null;

/** @type {string} */
let attachmentStage = 'start';
try {
  const stagedIds = [];
  const markdownLines = [];
  const jsContentType = 'application/javascript';

  const jsContent = buildSmokeTestJsModuleContent(issue.simple_id);
  const jsBytes = new TextEncoder().encode(jsContent);
  attachmentStage = 'upload_and_confirm_js';
  const js = await client.attachments.uploadAndConfirm({
    projectId: project.id,
    filename: `e2e-${issue.simple_id}.js`,
    contentType: jsContentType,
    data: jsBytes,
  });
  stepDone('Uploaded & confirmed JS attachment (staged)', `id=${js.id}`);
  stagedIds.push(js.id);
  markdownLines.push(formatIssueAttachmentMarkdownLine(js, jsContentType));
  attachmentJs = {
    id: js.id,
    filename: js.original_name,
    size_bytes: js.size_bytes,
  };

  const extraPath = e2eEnv.extraFilePath ?? undefined;
  let docContentType = '';
  if (extraPath) {
    if (!existsSync(extraPath)) {
      console.error(`VK_E2E_FILE_PATH does not exist: ${extraPath}`);
      process.exit(1);
    }
    const name = basename(extraPath);
    const buf = readFileSync(extraPath);
    docContentType = getFileMimeType(name);
    attachmentStage = 'upload_and_confirm_extra_file';
    const doc = await client.attachments.uploadAndConfirm({
      projectId: project.id,
      filename: name,
      contentType: docContentType,
      data: buf,
    });
    stagedIds.push(doc.id);
    markdownLines.push(formatIssueAttachmentMarkdownLine(doc, docContentType));
    attachmentDocx = {
      id: doc.id,
      filename: doc.original_name,
      size_bytes: doc.size_bytes,
    };
    stepDone('Uploaded & confirmed extra file (staged)', `${name} id=${doc.id}`);
  }

  attachmentStage = 'commit_to_issue';
  const committed = await client.attachments.commitToIssue(issue.id, {
    attachment_ids: stagedIds,
  });
  stepDone(
    'Committed attachments to issue',
    `${committed.attachments.length} row(s) for issue ${issue.simple_id}`,
  );

  const baseDesc = issue.description?.trim() ?? '';
  const attachBlock = ['', '### Attachments (E2E)', ...markdownLines].join('\n');
  await client.issues.update(issue.id, {
    description: baseDesc ? `${baseDesc}\n${attachBlock}` : attachBlock.trim(),
  });
  stepDone('Updated issue description', 'includes attachment:// markdown for UI');

  attachmentStage = 'list_issue_attachments';
  issueAttachmentsListed = await client.attachments.listForIssue(issue.id);
  stepDone(
    'Listed issue attachments (API)',
    `${issueAttachmentsListed.attachments?.length ?? 0} attachment(s)`,
  );

  if (committed.attachments.length !== stagedIds.length) {
    console.error(
      'commitToIssue returned fewer rows than expected — staged confirm flow may be wrong.',
      committed,
    );
    process.exit(1);
  }
} catch (err) {
  const message = err instanceof Error ? err.message : String(err);
  console.error('[e2e] Attachment step failed:', message);
  console.error(
    '[e2e] Attachment diagnostics:',
    JSON.stringify(
      {
        stage: attachmentStage,
        local_base: localBase,
        remote_base: remoteBase,
        project_id: project.id,
        issue_id: issue.id,
      },
      null,
      2,
    ),
  );
  throw err;
}

const { data: movedIssue } = await client.issues.update(issue.id, {
  status_id: inProgressStatus.id,
});
stepDone(
  'Moved issue to In Progress',
  `${movedIssue.simple_id} status_id=${movedIssue.status_id}`,
);

const linkedWorkspace = await client.workspaces.getByLocalId(localWorkspaceId);
stepDone(
  'Fetched workspace by local_workspace_id',
  `issue_id=${linkedWorkspace.issue_id}`,
);

const clickableChecks = {
  hasLocalWorkspaceId: Boolean(linkedWorkspace.local_workspace_id),
  isOwnedByCurrentApiUser:
    linkedWorkspace.owner_user_id === workspace.owner_user_id,
  note:
    'UI clickability also depends on the currently signed-in desktop user matching workspace.owner_user_id.',
};

/** @type {Record<string, unknown> | null} */
let localAgentFollowUp = null;
/** @type {Record<string, unknown> | null} */
let localAgentQueue = null;
/** @type {Record<string, unknown> | null} */
let localAgentProjectRepoDefaults = null;
if (localBase) {
  stepDone('Local agent gitStatus', `workspace=${localWorkspaceId} (strict bootstrap)`);
  const localAgentOrigin =
    typeof localAgentProbe?.local_base === 'string'
      ? localAgentProbe.local_base
      : normalizeLocalAgentBaseUrl(localBase);
  const localAgent = new LocalAgentClient({ baseUrl: localAgentOrigin });
  const sessions = await localAgent.sessions.list(localWorkspaceId);
  const session =
    sessions[0] ??
    (await localAgent.sessions.create({
      workspace_id: localWorkspaceId,
      executor: e2eEnv.localFollowUpExecutor,
      name: `SDK E2E Session ${issue.simple_id}`,
    }));
  const preferredExecutor =
    e2eEnv.localFollowUpExecutor ||
    session.executor ||
    'CURSOR_AGENT';

  const queueSampleMessage =
    e2eEnv.localQueueMessage ||
    `[e2e] Queued follow-up sample for ${issue.simple_id}`;
  try {
    const queueInitial = await localAgent.sessions.queueStatus(session.id);
    const queuePost = await localAgent.sessions.queue(session.id, {
      message: queueSampleMessage,
      executor_config: { executor: preferredExecutor },
    });
    const queueAfterPost = await localAgent.sessions.queueStatus(session.id);
    await localAgent.sessions.cancelQueue(session.id);
    const queueAfterCancel = await localAgent.sessions.queueStatus(session.id);
    localAgentQueue = {
      session_id: session.id,
      sample_message: queueSampleMessage,
      queue_initial: queueInitial,
      queue_post_response: queuePost,
      queue_after_post: queueAfterPost,
      queue_after_cancel: queueAfterCancel,
    };
    stepDone(
      'Session queue API round-trip',
      `GET → POST sample → GET → DELETE → GET (${session.id})`,
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    localAgentQueue = { session_id: session.id, sample_message: queueSampleMessage, error: msg };
    stepDone('Session queue round-trip failed (non-fatal)', msg);
  }

  const followUpPrompt = e2eEnv.localFollowUpPrompt ?? undefined;
  if (followUpPrompt) {
    try {
      const executionProcess = await localAgent.sessions.followUp(session.id, {
        prompt: followUpPrompt,
        executor_config: {
          executor: preferredExecutor,
        },
        retry_process_id: null,
        force_when_dirty: null,
        perform_git_reset: null,
      });
      localAgentFollowUp = {
        prompt: followUpPrompt,
        session_id: session.id,
        execution_process_id: executionProcess.id,
        execution_status: executionProcess.status,
      };
      stepDone(
        'Triggered local follow-up',
        `session=${session.id}, process=${executionProcess.id}`,
      );
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      localAgentFollowUp = {
        prompt: followUpPrompt,
        error: msg,
      };
      stepDone('Local follow-up failed (non-fatal)', msg);
    }
  } else {
    stepDone(
      'Skipped local follow-up',
      'set VK_E2E_LOCAL_FOLLOW_UP_PROMPT to call /api/sessions/{id}/follow-up',
    );
  }

  if (e2eEnv.projectRepoDefaultsEnabled) {
    const probe = localAgentProbe;
    const repoId =
      probe && typeof probe === 'object' && probe.selected_repo && typeof probe.selected_repo === 'object'
        ? /** @type {{ id?: string }} */ (probe.selected_repo).id
        : undefined;
    const targetBranch =
      probe && typeof probe === 'object' && typeof probe.target_branch === 'string'
        ? probe.target_branch
        : undefined;
    if (!repoId || !targetBranch) {
      localAgentProjectRepoDefaults = {
        skipped: true,
        reason: 'missing localAgentProbe.selected_repo.id or target_branch',
      };
      stepDone(
        'Skipped project repo defaults scratch',
        'VK_E2E_PROJECT_REPO_DEFAULTS=1 but bootstrap probe data missing',
      );
    } else {
      try {
        await saveProjectRepoDefaults(localAgent.scratch, project.id, [
          { repo_id: repoId, target_branch: targetBranch },
        ]);
        const readBack = await getProjectRepoDefaults(localAgent.scratch, project.id);
        if (!readBack || readBack.length !== 1) {
          throw new Error(
            `expected 1 repo in read-back, got ${readBack ? readBack.length : 'null'}`,
          );
        }
        if (readBack[0].repo_id !== repoId || readBack[0].target_branch !== targetBranch) {
          throw new Error(
            `read-back mismatch: ${JSON.stringify(readBack[0])} vs ${repoId} / ${targetBranch}`,
          );
        }
        localAgentProjectRepoDefaults = {
          project_id: project.id,
          wrote: { repo_id: repoId, target_branch: targetBranch },
          read_back: readBack,
        };
        stepDone(
          'Scratch PROJECT_REPO_DEFAULTS PUT/GET',
          `project_id=${project.id}`,
        );
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        localAgentProjectRepoDefaults = {
          project_id: project.id,
          error: msg,
        };
        stepDone('Scratch PROJECT_REPO_DEFAULTS round-trip failed (non-fatal)', msg);
      }
    }
  }
} else {
  stepDone('Skipped local agent probe', 'set VK_LOCAL_API_BASE to enable');
}

console.error('[e2e] ✓ Emitting summary JSON on stdout\n');
console.log(
  JSON.stringify(
    {
      env_file: envPath,
      transport: sdkConfig.transport,
      organization: { id: org.id, name: org.name },
      project: { id: project.id, name: project.name },
      statuses: {
        todo: { id: todoStatus.id, name: todoStatus.name },
        in_progress: { id: inProgressStatus.id, name: inProgressStatus.name },
      },
      issue_before_move: {
        id: issue.id,
        simple_id: issue.simple_id,
        status_id: issue.status_id,
      },
      issue_after_move: {
        id: movedIssue.id,
        simple_id: movedIssue.simple_id,
        status_id: movedIssue.status_id,
      },
      workspace: {
        id: linkedWorkspace.id,
        local_workspace_id: linkedWorkspace.local_workspace_id,
        owner_user_id: linkedWorkspace.owner_user_id,
        issue_id: linkedWorkspace.issue_id,
      },
      uploaded_attachments: {
        js: attachmentJs,
        extra: attachmentDocx,
      },
      issue_attachments_via_api: issueAttachmentsListed,
      ui_note:
        'Kanban renders files from `attachment://` markdown in the issue description (or comments). Object keys typically look like attachments/{project_id}/...',
      local_desktop_workspace_ids:
        'When VK_LOCAL_API_BASE is set, this run enforces strict local bootstrap (workspace create + repo attach + gitStatus) before creating the remote workspace row.',
      clickable_checks: clickableChecks,
      local_agent_probe: localAgentProbe,
      local_agent_queue: localAgentQueue,
      local_agent_follow_up: localAgentFollowUp,
      local_agent_project_repo_defaults: localAgentProjectRepoDefaults
    },
    null,
    2,
  ),
);
