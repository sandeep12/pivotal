/**
 * Signs a sample `issue.status_changed` body the same way the remote server
 * does, then uses verifyWebhookSignature / parseVerifiedWebhook from the SDK.
 */
import { createHmac } from 'node:crypto';

import {
  parseVerifiedWebhook,
  verifyWebhookSignature,
} from '../dist/index.js';

const secret = 'example-hmac-secret';

const stubIssue = {
  id: '11111111-1111-4111-8111-111111111111',
  project_id: '22222222-2222-4222-8222-222222222222',
  issue_number: 42,
  simple_id: 'DEMO-42',
  status_id: '33333333-3333-4333-8333-333333333333',
  title: 'Demo issue',
  description: null,
  priority: null,
  start_date: null,
  target_date: null,
  completed_at: null,
  sort_order: 0,
  parent_issue_id: null,
  parent_issue_sort_order: null,
  extension_metadata: {},
  creator_user_id: null,
  created_at: '2026-04-01T12:00:00.000Z',
  updated_at: '2026-04-01T12:30:00.000Z',
};

const payload = {
  schema_version: 1,
  event: 'issue.status_changed',
  occurred_at: '2026-04-01T12:30:00.000Z',
  organization_id: '44444444-4444-4444-8444-444444444444',
  actor_user_id: '55555555-5555-4555-8555-555555555555',
  issue: stubIssue,
  previous_status_id: '66666666-6666-4666-8666-666666666666',
  previous_status_name: 'In progress',
  new_status_id: stubIssue.status_id,
  new_status_name: 'Done',
  postgres_txid: null,
};

const rawBody = Buffer.from(JSON.stringify(payload), 'utf8');
const signatureHeader =
  'sha256=' + createHmac('sha256', secret).update(rawBody).digest('hex');

console.log('verifyWebhookSignature:', verifyWebhookSignature(rawBody, signatureHeader, secret));
console.log('parseVerifiedWebhook.issue.title:', parseVerifiedWebhook(rawBody, signatureHeader, secret).issue.title);
