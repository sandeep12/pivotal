import type { LocalRepo } from "./types-local-agent.js";

/**
 * Picks a branch name for attaching a repo: explicit override, then server default fields,
 * then `main`.
 */
export function resolveTargetBranchForLocalRepo(
  repo: LocalRepo & { default_branch?: string | null },
  explicitTargetBranch?: string | null
): string {
  if (explicitTargetBranch?.trim()) {
    return explicitTargetBranch.trim();
  }
  if (
    typeof repo.default_target_branch === "string" &&
    repo.default_target_branch.trim()
  ) {
    return repo.default_target_branch.trim();
  }
  if (typeof repo.default_branch === "string" && repo.default_branch.trim()) {
    return repo.default_branch.trim();
  }
  return "main";
}
