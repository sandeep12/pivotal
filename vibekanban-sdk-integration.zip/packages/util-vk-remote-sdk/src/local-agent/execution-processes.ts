import type {
  LocalExecutionProcess,
  LocalExecutionProcessRepoState,
  Uuid,
} from "./types-local-agent.js";
import type { LocalAgentHttp } from "./client.js";

export class LocalAgentExecutionProcessesResource {
  constructor(
    private readonly http: LocalAgentHttp,
    private readonly baseUrl: string
  ) {}

  get(executionProcessId: Uuid): Promise<LocalExecutionProcess> {
    return this.http.request(
      "GET",
      `/execution-processes/${executionProcessId}`
    );
  }

  stop(executionProcessId: Uuid): Promise<void> {
    return this.http.request(
      "POST",
      `/execution-processes/${executionProcessId}/stop`
    );
  }

  repoStates(
    executionProcessId: Uuid
  ): Promise<LocalExecutionProcessRepoState[]> {
    return this.http.request(
      "GET",
      `/execution-processes/${executionProcessId}/repo-states`
    );
  }

  rawLogsWsUrl(executionProcessId: Uuid): string {
    return wsUrl(
      this.baseUrl,
      `/api/execution-processes/${executionProcessId}/raw-logs/ws`
    );
  }

  normalizedLogsWsUrl(executionProcessId: Uuid): string {
    return wsUrl(
      this.baseUrl,
      `/api/execution-processes/${executionProcessId}/normalized-logs/ws`
    );
  }

  sessionStreamWsUrl(sessionId: Uuid, showSoftDeleted?: boolean): string {
    const query =
      showSoftDeleted === undefined
        ? ""
        : `?show_soft_deleted=${showSoftDeleted}`;
    return wsUrl(
      this.baseUrl,
      `/api/execution-processes/stream/session/ws?session_id=${sessionId}${query}`
    );
  }
}

function wsUrl(baseUrl: string, pathAndQuery: string): string {
  const normalized = baseUrl.replace(/\/+$/, "");
  const url = new URL(`${normalized}${pathAndQuery}`);
  url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
  return url.toString();
}
