import type { LocalWorkspace } from "./types-local-agent.js";
import type { LocalAgentClientOptions } from "./client.js";
import { LocalAgentHttp } from "./client.js";
import { LocalAgentExecutionProcessesResource } from "./execution-processes.js";
import { LocalAgentReposResource } from "./repos.js";
import { LocalAgentScratchResource } from "./scratch.js";
import { LocalAgentSessionsResource } from "./sessions.js";
import { LocalAgentWorkspacesResource } from "./workspaces.js";

/**
 * Local desktop/agent API client (`/api/...`) for workspace execution workflows.
 *
 * This client is distinct from `VkRemoteClient`:
 * - `VkRemoteClient` targets remote `/v1` (or `/api/remote` proxy).
 * - `LocalAgentClient` targets local `/api` session/workspace/execution routes.
 */
export class LocalAgentClient {
  readonly sessions: LocalAgentSessionsResource;
  readonly workspaces: LocalAgentWorkspacesResource;
  readonly repos: LocalAgentReposResource;
  readonly scratch: LocalAgentScratchResource;
  readonly executionProcesses: LocalAgentExecutionProcessesResource;

  constructor(options: LocalAgentClientOptions) {
    const http = new LocalAgentHttp(options);
    this.sessions = new LocalAgentSessionsResource(http);
    this.workspaces = new LocalAgentWorkspacesResource(http);
    this.repos = new LocalAgentReposResource(http);
    this.scratch = new LocalAgentScratchResource(http);
    this.executionProcesses = new LocalAgentExecutionProcessesResource(
      http,
      options.baseUrl
    );
  }

  /**
   * First workspace from `GET /api/workspaces`, or `null` if the desktop has none.
   * Prefer this over hard-coding ids when scripting against a running local app.
   */
  async firstWorkspace(): Promise<LocalWorkspace | null> {
    const rows = await this.workspaces.list();
    return rows[0] ?? null;
  }
}

export type { LocalAgentClientOptions } from "./client.js";
