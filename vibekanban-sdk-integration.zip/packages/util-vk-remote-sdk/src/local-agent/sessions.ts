import type {
  LocalCreateSessionRequest,
  LocalExecutionProcess,
  LocalFollowUpRequest,
  LocalQueueMessageRequest,
  LocalQueueStatus,
  LocalResetProcessRequest,
  LocalStartReviewRequest,
  LocalSession,
  LocalUpdateSessionRequest,
  Uuid,
} from "./types-local-agent.js";
import type { LocalAgentHttp } from "./client.js";

export class LocalAgentSessionsResource {
  constructor(private readonly http: LocalAgentHttp) {}

  list(workspaceId: Uuid): Promise<LocalSession[]> {
    return this.http.request("GET", "/sessions", {
      query: { workspace_id: workspaceId },
    });
  }

  create(body: LocalCreateSessionRequest): Promise<LocalSession> {
    return this.http.request("POST", "/sessions", { body });
  }

  get(sessionId: Uuid): Promise<LocalSession> {
    return this.http.request("GET", `/sessions/${sessionId}`);
  }

  update(
    sessionId: Uuid,
    body: LocalUpdateSessionRequest
  ): Promise<LocalSession> {
    return this.http.request("PUT", `/sessions/${sessionId}`, { body });
  }

  followUp(
    sessionId: Uuid,
    body: LocalFollowUpRequest
  ): Promise<LocalExecutionProcess> {
    return this.http.request("POST", `/sessions/${sessionId}/follow-up`, {
      body,
    });
  }

  reset(sessionId: Uuid, body: LocalResetProcessRequest): Promise<void> {
    return this.http.request("POST", `/sessions/${sessionId}/reset`, { body });
  }

  setup(sessionId: Uuid): Promise<LocalExecutionProcess> {
    return this.http.request("POST", `/sessions/${sessionId}/setup`);
  }

  review(
    sessionId: Uuid,
    body: LocalStartReviewRequest
  ): Promise<LocalExecutionProcess> {
    return this.http.request("POST", `/sessions/${sessionId}/review`, { body });
  }

  queueStatus(sessionId: Uuid): Promise<LocalQueueStatus> {
    return this.http.request("GET", `/sessions/${sessionId}/queue`);
  }

  queue(
    sessionId: Uuid,
    body: LocalQueueMessageRequest
  ): Promise<LocalQueueStatus> {
    return this.http.request("POST", `/sessions/${sessionId}/queue`, { body });
  }

  cancelQueue(sessionId: Uuid): Promise<LocalQueueStatus> {
    return this.http.request("DELETE", `/sessions/${sessionId}/queue`);
  }
}
