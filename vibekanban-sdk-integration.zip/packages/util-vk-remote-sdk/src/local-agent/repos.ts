import type { LocalRepo } from "./types-local-agent.js";
import type { LocalAgentHttp } from "./client.js";

export class LocalAgentReposResource {
  constructor(private readonly http: LocalAgentHttp) {}

  list(): Promise<LocalRepo[]> {
    return this.http.request("GET", "/repos");
  }
}
