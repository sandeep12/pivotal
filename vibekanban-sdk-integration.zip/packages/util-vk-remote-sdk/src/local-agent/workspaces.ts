import type {
  LocalAddWorkspaceRepoResponse,
  LocalCreateAndStartWorkspaceRequest,
  LocalCreateAndStartWorkspaceResponse,
  LocalCreateWorkspaceRequest,
  LocalRepoBranchStatus,
  LocalRepoWithTargetBranch,
  LocalUpdateWorkspaceRequest,
  LocalWorkspace,
  LocalWorkspaceRepoInput,
  LocalWorkspaceSummaryRequest,
  LocalWorkspaceSummaryResponse,
  Uuid,
} from "./types-local-agent.js";
import type { LocalAgentHttp } from "./client.js";

export class LocalAgentWorkspacesResource {
  constructor(private readonly http: LocalAgentHttp) {}

  list(): Promise<LocalWorkspace[]> {
    return this.http.request("GET", "/workspaces");
  }

  create(body: LocalCreateWorkspaceRequest): Promise<LocalWorkspace> {
    return this.http.request("POST", "/workspaces", { body });
  }

  get(workspaceId: Uuid): Promise<LocalWorkspace> {
    return this.http.request("GET", `/workspaces/${workspaceId}`);
  }

  update(
    workspaceId: Uuid,
    body: LocalUpdateWorkspaceRequest
  ): Promise<LocalWorkspace> {
    return this.http.request("PUT", `/workspaces/${workspaceId}`, { body });
  }

  delete(
    workspaceId: Uuid,
    options?: { delete_remote?: boolean; delete_branches?: boolean }
  ): Promise<void> {
    return this.http.request("DELETE", `/workspaces/${workspaceId}`, {
      query: {
        delete_remote:
          options?.delete_remote === undefined
            ? undefined
            : String(options.delete_remote),
        delete_branches:
          options?.delete_branches === undefined
            ? undefined
            : String(options.delete_branches),
      },
    });
  }

  summaries(
    body: LocalWorkspaceSummaryRequest
  ): Promise<LocalWorkspaceSummaryResponse> {
    return this.http.request("POST", "/workspaces/summaries", { body });
  }

  start(
    body: LocalCreateAndStartWorkspaceRequest
  ): Promise<LocalCreateAndStartWorkspaceResponse> {
    return this.http.request("POST", "/workspaces/start", { body });
  }

  gitStatus(workspaceId: Uuid): Promise<LocalRepoBranchStatus[]> {
    return this.http.request("GET", `/workspaces/${workspaceId}/git/status`);
  }

  listWorkspaceRepos(workspaceId: Uuid): Promise<LocalRepoWithTargetBranch[]> {
    return this.http.request("GET", `/workspaces/${workspaceId}/repos`);
  }

  attachRepo(
    workspaceId: Uuid,
    body: LocalWorkspaceRepoInput
  ): Promise<LocalAddWorkspaceRepoResponse> {
    return this.http.request("POST", `/workspaces/${workspaceId}/repos`, {
      body,
    });
  }
}
