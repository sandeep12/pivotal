/** Strip trailing slashes and optional `/api` suffix from a local desktop / Vite origin. */
export function normalizeLocalAgentBaseUrl(url: string): string {
  let u = url.trim();
  u = u.replace(/\/+$/, "");
  u = u.replace(/\/api\/?$/, "");
  u = u.replace(/\/+$/, "");
  return u;
}
