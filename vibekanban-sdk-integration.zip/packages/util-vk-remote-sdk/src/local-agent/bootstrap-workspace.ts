import type { LocalRepo } from "./types-local-agent.js";
import type { LocalRepoBranchStatus } from "./types-local-agent.js";
import type { LocalWorkspace } from "./types-local-agent.js";
import type { LocalAgentClient } from "./index.js";
import { normalizeLocalAgentBaseUrl } from "./normalize-base-url.js";
import { resolveTargetBranchForLocalRepo } from "./repo-utils.js";

export interface BootstrapLocalWorkspaceWithRepoOptions {
  workspaceName: string;
  repoId?: string | null;
  targetBranch?: string | null;
}

export interface BootstrapLocalWorkspaceWithRepoResult {
  localBaseUrl: string;
  workspace: LocalWorkspace;
  gitStatus: LocalRepoBranchStatus[];
  selectedRepo: LocalRepo;
  targetBranch: string;
}

/**
 * Creates a local workspace, attaches a registered repo (first match or `repoId` filter),
 * verifies attached rows, and returns `gitStatus`.
 */
export async function bootstrapLocalWorkspaceWithRegisteredRepo(
  client: LocalAgentClient,
  localBaseUrl: string,
  options: BootstrapLocalWorkspaceWithRepoOptions
): Promise<BootstrapLocalWorkspaceWithRepoResult> {
  const normalizedBase = normalizeLocalAgentBaseUrl(localBaseUrl);
  const repos = await client.repos.list();
  if (!repos.length) {
    throw new Error(
      "No local repos found via LocalAgentClient.repos.list(). Add/register a repo first."
    );
  }

  const requestedRepoId = options.repoId?.trim() || null;
  const selectedRepo =
    (requestedRepoId
      ? repos.find((repo) => repo.id === requestedRepoId)
      : null) ?? repos[0];
  if (!selectedRepo) {
    throw new Error(`Repo not found for repo id filter=${requestedRepoId}`);
  }

  const localWorkspace = await client.workspaces.create({
    name: options.workspaceName,
  });
  const targetBranch = resolveTargetBranchForLocalRepo(
    selectedRepo,
    options.targetBranch ?? null
  );
  await client.workspaces.attachRepo(localWorkspace.id, {
    repo_id: selectedRepo.id,
    target_branch: targetBranch,
  });

  const workspaceRepos = await client.workspaces.listWorkspaceRepos(
    localWorkspace.id
  );
  if (!workspaceRepos.length) {
    throw new Error(
      `Local workspace ${localWorkspace.id} has no attached repos after attachRepo.`
    );
  }

  const gitStatus = await client.workspaces.gitStatus(localWorkspace.id);
  return {
    localBaseUrl: normalizedBase,
    workspace: localWorkspace,
    gitStatus,
    selectedRepo,
    targetBranch,
  };
}
