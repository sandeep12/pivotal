import type { LocalWorkspace } from "./types-local-agent.js";
import type { LocalAgentClient } from "./index.js";

export interface ResolveLocalAgentWorkspaceOptions {
  /** Used when creating a workspace if the registry is empty. */
  workspaceNameDefault: string;
  localWorkspaceId?: string | null;
  localWorkspaceName?: string | null;
}

/**
 * Picks an existing workspace (by optional id/name hints) or the first listed workspace, or creates
 * one — same selection rules as the `07-local-agent-mvp` example.
 */
export async function resolveLocalAgentWorkspace(
  client: LocalAgentClient,
  options: ResolveLocalAgentWorkspaceOptions
): Promise<LocalWorkspace> {
  const workspaces = await client.workspaces.list();
  const idHint = options.localWorkspaceId?.trim() || "";
  const nameHint = options.localWorkspaceName?.trim() || "";

  if (idHint) {
    const byId = workspaces.find((w) => w.id === idHint);
    if (byId) {
      return byId;
    }
    throw new Error(`No local workspace matched localWorkspaceId=${idHint}.`);
  }

  if (nameHint) {
    const byName = workspaces.find((w) => (w.name ?? "").trim() === nameHint);
    if (byName) {
      return byName;
    }
  }

  if (workspaces.length > 0) {
    return workspaces[0]!;
  }

  return client.workspaces.create({
    name: nameHint || options.workspaceNameDefault,
  });
}
