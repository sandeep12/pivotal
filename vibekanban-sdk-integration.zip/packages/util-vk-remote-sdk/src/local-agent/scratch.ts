import { VkApiError } from "../errors.js";
import type { LocalAgentHttp } from "./client.js";
import type {
  LocalCreateScratchRequest,
  LocalScratch,
  LocalScratchType,
  LocalUpdateScratchRequest,
  LocalWorkspaceRepoInput,
} from "./types-local-agent.js";

export class LocalAgentScratchResource {
  constructor(private readonly http: LocalAgentHttp) {}

  private path(scratchType: LocalScratchType, id: string): string {
    return `/scratch/${scratchType}/${encodeURIComponent(id)}`;
  }

  get(scratchType: LocalScratchType, id: string): Promise<LocalScratch> {
    return this.http.request("GET", this.path(scratchType, id));
  }

  update(
    scratchType: LocalScratchType,
    id: string,
    body: LocalUpdateScratchRequest
  ): Promise<LocalScratch> {
    return this.http.request("PUT", this.path(scratchType, id), { body });
  }

  create(
    scratchType: LocalScratchType,
    id: string,
    body: LocalCreateScratchRequest
  ): Promise<LocalScratch> {
    return this.http.request("POST", this.path(scratchType, id), { body });
  }

  delete(scratchType: LocalScratchType, id: string): Promise<void> {
    return this.http.request("DELETE", this.path(scratchType, id));
  }
}

export function isLocalScratchNotFoundError(error: unknown): boolean {
  return (
    error instanceof VkApiError &&
    error.status === 400 &&
    error.bodyText.includes("Scratch not found")
  );
}

/**
 * Read project repo defaults from scratch storage.
 * Returns null if no defaults have been saved for this project.
 */
export async function getProjectRepoDefaults(
  scratch: LocalAgentScratchResource,
  projectId: string
): Promise<LocalWorkspaceRepoInput[] | null> {
  try {
    const row = await scratch.get("PROJECT_REPO_DEFAULTS", projectId);
    const payload = row.payload;
    if (payload?.type === "PROJECT_REPO_DEFAULTS") {
      return payload.data.repos;
    }
    return null;
  } catch (error) {
    if (isLocalScratchNotFoundError(error)) {
      return null;
    }
    throw error;
  }
}

/**
 * Save project repo defaults to scratch storage (upsert via PUT).
 */
export async function saveProjectRepoDefaults(
  scratch: LocalAgentScratchResource,
  projectId: string,
  repos: LocalWorkspaceRepoInput[]
): Promise<void> {
  await scratch.update("PROJECT_REPO_DEFAULTS", projectId, {
    payload: {
      type: "PROJECT_REPO_DEFAULTS",
      data: { repos },
    },
  });
}
