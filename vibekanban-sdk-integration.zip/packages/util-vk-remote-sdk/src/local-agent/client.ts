import { VkApiError } from "../errors.js";

export type LocalAgentHttpMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";

export interface LocalAgentClientOptions {
  /** Local desktop server (or Vite dev origin), e.g. `http://localhost:3000`. */
  baseUrl: string;
  fetchImpl?: typeof fetch;
}

export interface LocalAgentRequestOptions {
  query?: Record<string, string | undefined>;
  body?: unknown;
}

interface LocalApiEnvelope {
  success: boolean;
  data?: unknown;
  message?: string | null;
}

export class LocalAgentHttp {
  private readonly base: string;
  private readonly fetchFn: typeof fetch;

  constructor(options: LocalAgentClientOptions) {
    this.base = options.baseUrl.replace(/\/+$/, "");
    this.fetchFn = options.fetchImpl ?? globalThis.fetch;
  }

  async request<T>(
    method: LocalAgentHttpMethod,
    path: string,
    init?: LocalAgentRequestOptions
  ): Promise<T> {
    const normalized = path.startsWith("/") ? path : `/${path}`;
    const url = new URL(`${this.base}/api${normalized}`);

    if (init?.query) {
      for (const [key, value] of Object.entries(init.query)) {
        if (value !== undefined) {
          url.searchParams.set(key, value);
        }
      }
    }

    const headers: Record<string, string> = {};
    let body: string | undefined;

    if (init?.body !== undefined) {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(init.body);
    }

    const response = await this.fetchFn(url.toString(), {
      method,
      headers,
      body,
    });

    const text = await response.text();
    if (!response.ok) {
      throw new VkApiError(response.status, text);
    }

    if (response.status === 204 || text.length === 0) {
      return undefined as T;
    }

    const parsed: unknown = JSON.parse(text);
    return unwrapLocalApiEnvelope<T>(parsed, response.status);
  }
}

function unwrapLocalApiEnvelope<T>(parsed: unknown, httpStatus: number): T {
  if (!parsed || typeof parsed !== "object" || !("success" in parsed)) {
    return parsed as T;
  }

  const envelope = parsed as LocalApiEnvelope;
  if (!envelope.success) {
    throw new VkApiError(
      httpStatus >= 400 ? httpStatus : 400,
      envelope.message ?? "Local API returned success: false"
    );
  }
  return envelope.data as T;
}
