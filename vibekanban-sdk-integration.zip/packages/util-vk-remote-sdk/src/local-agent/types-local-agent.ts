import type { IsoDateTime, Uuid } from "../types.js";
export type { IsoDateTime, Uuid } from "../types.js";

export interface LocalSession {
  id: Uuid;
  workspace_id: Uuid;
  name: string | null;
  executor: string | null;
  agent_working_dir: string | null;
  created_at: IsoDateTime;
  updated_at: IsoDateTime;
}

export interface LocalCreateSessionRequest {
  workspace_id: Uuid;
  executor?: string | null;
  name?: string | null;
}

export interface LocalUpdateSessionRequest {
  name?: string | null;
}

export interface LocalExecutorConfig {
  executor: string;
  variant?: string | null;
  model_id?: string | null;
  agent_id?: string | null;
  reasoning_id?: string | null;
  permission_policy?: string | null;
}

export interface LocalFollowUpRequest {
  prompt: string;
  executor_config: LocalExecutorConfig;
  retry_process_id?: Uuid | null;
  force_when_dirty?: boolean | null;
  perform_git_reset?: boolean | null;
}

export interface LocalResetProcessRequest {
  process_id: Uuid;
  force_when_dirty?: boolean | null;
  perform_git_reset?: boolean | null;
}

export type LocalRunScriptError =
  | "no_script_configured"
  | "process_already_running";
export type LocalReviewError = "process_already_running";

export interface LocalStartReviewRequest {
  executor_config: LocalExecutorConfig;
  additional_prompt?: string | null;
  use_all_workspace_commits?: boolean;
}

export interface LocalQueuedMessageData {
  message: string;
  executor_config: LocalExecutorConfig;
}

export interface LocalQueuedMessage {
  session_id: Uuid;
  data: LocalQueuedMessageData;
  queued_at: IsoDateTime;
}

export type LocalQueueStatus =
  | { status: "empty" }
  | { status: "queued"; message: LocalQueuedMessage };

export interface LocalQueueMessageRequest {
  message: string;
  executor_config: LocalExecutorConfig;
}

export type LocalExecutionProcessStatus =
  | "running"
  | "completed"
  | "failed"
  | "killed";

export type LocalExecutionProcessRunReason =
  | "setupscript"
  | "cleanupscript"
  | "archivescript"
  | "codingagent"
  | "devserver";

/** `executor_action` is opaque to this SDK for now. */
export interface LocalExecutionProcess {
  id: Uuid;
  session_id: Uuid;
  run_reason: LocalExecutionProcessRunReason;
  executor_action: unknown;
  status: LocalExecutionProcessStatus;
  exit_code: number | null;
  dropped: boolean;
  started_at: IsoDateTime;
  completed_at: IsoDateTime | null;
  created_at: IsoDateTime;
  updated_at: IsoDateTime;
}

export interface LocalExecutionProcessRepoState {
  execution_process_id: Uuid;
  repo_id: Uuid;
  before_head_commit: string | null;
  after_head_commit: string | null;
  merge_commit: string | null;
}

export interface LocalWorkspaceSummaryRequest {
  archived: boolean;
}

export interface LocalWorkspaceSummary {
  workspace_id: Uuid;
  latest_session_id: Uuid | null;
  has_pending_approval: boolean;
  files_changed: number | null;
  lines_added: number | null;
  lines_removed: number | null;
  latest_process_completed_at: IsoDateTime | null;
  latest_process_status: LocalExecutionProcessStatus | null;
  has_running_dev_server: boolean;
  has_unseen_turns: boolean;
  pr_status: string | null;
  pr_number: number | null;
  pr_url: string | null;
}

export interface LocalWorkspaceSummaryResponse {
  summaries: LocalWorkspaceSummary[];
}

export interface LocalWorkspaceRepoInput {
  repo_id: Uuid;
  target_branch: string;
}

/** Scratch kind stored under `/api/scratch/{scratch_type}/{id}` (local desktop). */
export type LocalScratchType = "PROJECT_REPO_DEFAULTS";

export interface LocalProjectRepoDefaultsPayloadData {
  repos: LocalWorkspaceRepoInput[];
}

export type LocalScratchPayloadProjectRepoDefaults = {
  type: "PROJECT_REPO_DEFAULTS";
  data: LocalProjectRepoDefaultsPayloadData;
};

export type LocalScratchPayload = LocalScratchPayloadProjectRepoDefaults;

export interface LocalScratch {
  id: Uuid;
  payload: LocalScratchPayload;
  created_at: IsoDateTime;
  updated_at: IsoDateTime;
}

export interface LocalUpdateScratchRequest {
  payload: LocalScratchPayload;
}

export interface LocalCreateScratchRequest {
  payload: LocalScratchPayload;
}

/** Registered git repository from `GET /api/repos` (desktop repo registry). */
export interface LocalRepo {
  id: Uuid;
  path: string;
  name: string;
  display_name: string;
  setup_script: string | null;
  cleanup_script: string | null;
  archive_script: string | null;
  copy_files: string | null;
  parallel_setup_script: boolean;
  dev_server_script: string | null;
  default_target_branch: string | null;
  default_working_dir: string | null;
  created_at: IsoDateTime;
  updated_at: IsoDateTime;
}

/** Repo attached to a workspace, from `GET /api/workspaces/{id}/repos`. */
export type LocalRepoWithTargetBranch = LocalRepo & {
  target_branch: string;
};

export interface LocalAddWorkspaceRepoResponse {
  workspace: LocalWorkspace;
  repo: LocalRepoWithTargetBranch;
}

export interface LocalLinkedIssueInfo {
  remote_project_id: Uuid;
  issue_id: Uuid;
}

export interface LocalCreateAndStartWorkspaceRequest {
  name?: string | null;
  repos: LocalWorkspaceRepoInput[];
  linked_issue?: LocalLinkedIssueInfo | null;
  executor_config: LocalExecutorConfig;
  prompt: string;
  attachment_ids?: Uuid[] | null;
}

export interface LocalCreateWorkspaceRequest {
  name?: string | null;
}

export interface LocalUpdateWorkspaceRequest {
  archived?: boolean | null;
  pinned?: boolean | null;
  name?: string | null;
}

export interface LocalWorkspace {
  id: Uuid;
  task_id: Uuid | null;
  container_ref: string | null;
  branch: string;
  setup_completed_at: IsoDateTime | null;
  created_at: IsoDateTime;
  updated_at: IsoDateTime;
  archived: boolean;
  pinned: boolean;
  name: string | null;
  worktree_deleted: boolean;
}

export interface LocalCreateAndStartWorkspaceResponse {
  workspace: LocalWorkspace;
  execution_process: LocalExecutionProcess;
}

export interface LocalBranchStatus {
  commits_behind: number | null;
  commits_ahead: number | null;
  has_uncommitted_changes: boolean | null;
  head_oid: string | null;
  uncommitted_count: number | null;
  untracked_count: number | null;
  target_branch_name: string;
  remote_commits_behind: number | null;
  remote_commits_ahead: number | null;
  merges: unknown[];
  is_rebase_in_progress: boolean;
  conflict_op: string | null;
  conflicted_files: string[];
  is_target_remote: boolean;
}

export interface LocalRepoBranchStatus {
  repo_id: Uuid;
  repo_name: string;
  status: LocalBranchStatus;
}
