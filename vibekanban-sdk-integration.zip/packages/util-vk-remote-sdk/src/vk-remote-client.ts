import { postRemoteLocalAuthLogin } from "./auth/remote-local-login.js";
import { VkRemoteClient } from "./client.js";
import {
  readVkRemoteSdkConfigFromEnv,
  type VkRemoteSdkConfig,
} from "./sdk-env-config.js";

export interface CreateVkRemoteClientOptions {
  /**
   * SDK settings from env (or built manually for the browser).
   * When omitted, reads once via {@link readVkRemoteSdkConfigFromEnv}.
   */
  config?: VkRemoteSdkConfig;
  onStep?: (label: string, detail?: string) => void;
  /**
   * When true (default), after email/password login the token is written to `process.env`
   * when available (Node). Set false to avoid mutating the environment.
   */
  persistRemoteAccessTokenToEnv?: boolean;
}

/**
 * Builds {@link VkRemoteClient} from {@link VkRemoteSdkConfig} (typically from
 * {@link readVkRemoteSdkConfigFromEnv} at process start).
 */
export async function createVkRemoteClient(
  options?: CreateVkRemoteClientOptions
): Promise<VkRemoteClient> {
  const step = options?.onStep;
  const cfg = options?.config ?? readVkRemoteSdkConfigFromEnv();
  const persistToken =
    options?.persistRemoteAccessTokenToEnv !== false &&
    typeof process !== "undefined";

  if (cfg.transport === "localDesktop") {
    const baseUrl = cfg.localApiBase;
    if (!baseUrl) {
      throw new Error(
        "Set VK_LOCAL_API_BASE to your browser origin (e.g. http://localhost:3000)."
      );
    }
    step?.("API client ready", `localDesktop → ${baseUrl}`);
    return new VkRemoteClient({
      baseUrl,
      accessToken: "",
      transport: "localDesktop",
    });
  }

  const baseUrl = cfg.remoteBaseUrl;
  if (!baseUrl) {
    throw new Error("Set VK_REMOTE_BASE_URL (e.g. http://localhost:3100).");
  }

  let accessToken = cfg.remoteAccessToken;
  const email = cfg.remoteEmail;
  const password = cfg.remotePassword;

  if (!accessToken && email && password) {
    accessToken = await postRemoteLocalAuthLogin(baseUrl, email, password);
    if (persistToken) {
      process.env.VK_REMOTE_ACCESS_TOKEN = accessToken;
    }
    step?.("Remote login", `/v1/auth/local/login as ${email}`);
  }

  if (!accessToken) {
    throw new Error(
      "Set VK_REMOTE_ACCESS_TOKEN, or VK_REMOTE_EMAIL + VK_REMOTE_PASSWORD for /v1/auth/local/login."
    );
  }

  step?.("API client ready", `remote → ${baseUrl}`);
  return new VkRemoteClient({ baseUrl, accessToken, transport: "remote" });
}
