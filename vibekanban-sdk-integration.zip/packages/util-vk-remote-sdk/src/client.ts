import { AttachmentsResource } from "./attachments.js";
import type { VkRemoteClientOptions } from "./http.js";
import { RemoteHttp } from "./http.js";
import { IssuesResource } from "./issues.js";
import { OrganizationsResource } from "./organizations.js";
import { ProjectStatusesResource } from "./project-statuses/project_statuses.js";
import { ProjectsResource } from "./projects.js";
import { WorkspacesResource } from "./workspaces.js";

/** Typed entrypoint for remote `/v1` or local desktop `/api` (see `VkRemoteClientOptions.transport`). */
export class VkRemoteClient {
  readonly organizations: OrganizationsResource;
  readonly projects: ProjectsResource;
  readonly projectStatuses: ProjectStatusesResource;
  readonly issues: IssuesResource;
  readonly workspaces: WorkspacesResource;
  readonly attachments: AttachmentsResource;

  constructor(options: VkRemoteClientOptions) {
    const http = new RemoteHttp(options);
    this.organizations = new OrganizationsResource(http);
    this.projects = new ProjectsResource(http);
    this.projectStatuses = new ProjectStatusesResource(http);
    this.issues = new IssuesResource(http);
    this.workspaces = new WorkspacesResource(http);
    this.attachments = new AttachmentsResource(http);
  }
}
