import { VkApiError } from "./errors.js";

export type HttpMethod = "GET" | "POST" | "PATCH" | "DELETE";

/**
 * - **`remote`** — call the remote HTTP API (`{baseUrl}/v1/...`) with `Authorization: Bearer`.
 * - **`localDesktop`** — call the local **desktop** HTTP API (`/api/organizations`,
 *   `/api/remote/...`). In **`pnpm run dev`**, set `baseUrl` to the **Vite dev origin** (same as the
 *   browser, e.g. `http://localhost:3000`) so `/api` hits the Vite proxy to Rust; you can also use
 *   the Rust listen URL if you call it directly. Uses the app’s stored remote session; responses
 *   use `{ success, data, message }` and are unwrapped. Pass `accessToken: ''` (no Bearer).
 *   The desktop process must have been started with **`VK_SHARED_API_BASE`** set to the remote
 *   origin (see `crates/local-deployment`), and you must be signed in in the UI.
 */
export type RemoteTransport = "remote" | "localDesktop";

export interface VkRemoteClientOptions {
  /** Remote host (no `/v1`), or local dev **browser/Vite origin** e.g. `http://localhost:3000`. */
  baseUrl: string;
  /**
   * JWT when `transport` is `remote`. For `localDesktop`, use `''` — the desktop server uses its
   * own stored credentials.
   */
  accessToken: string;
  fetchImpl?: typeof fetch;
  transport?: RemoteTransport;
}

export interface RequestOptions {
  query?: Record<string, string | undefined>;
  body?: unknown;
}

/** Value accepted as `fetch` `body` for binary uploads (no `DOM` lib required). */
export type FetchBinaryBody = ArrayBuffer | Uint8Array | Blob;

/** Low-level JSON client for remote `/v1` or local desktop `/api` + `/api/remote`. */
export class RemoteHttp {
  private readonly base: string;
  private readonly token: string;
  private readonly fetchFn: typeof fetch;
  private readonly transport: RemoteTransport;

  constructor(options: VkRemoteClientOptions) {
    this.base = options.baseUrl.replace(/\/+$/, "");
    this.token = options.accessToken;
    this.fetchFn = options.fetchImpl ?? globalThis.fetch;
    this.transport = options.transport ?? "remote";
  }

  /**
   * @param path — logical path, e.g. `/issues` (becomes `/v1/issues` or `/api/remote/issues`
   *   depending on `transport`).
   */
  async request<T>(
    method: HttpMethod,
    path: string,
    init?: RequestOptions
  ): Promise<T> {
    const normalized = path.startsWith("/") ? path : `/${path}`;
    const url = this.buildJsonUrl(normalized);
    if (init?.query) {
      for (const [key, value] of Object.entries(init.query)) {
        if (value !== undefined) {
          url.searchParams.set(key, value);
        }
      }
    }

    const headers: Record<string, string> = {};
    if (this.transport === "remote" || this.token.length > 0) {
      headers.Authorization = `Bearer ${this.token}`;
    }

    let body: string | undefined;
    if (init?.body !== undefined) {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(init.body);
    }

    const response = await this.fetchFn(url.toString(), {
      method,
      headers,
      body,
    });

    const text = await response.text();
    if (!response.ok) {
      throw new VkApiError(response.status, text);
    }

    if (response.status === 204 || text.length === 0) {
      return undefined as T;
    }

    const parsed: unknown = JSON.parse(text);
    if (this.transport === "localDesktop") {
      return unwrapLocalApiEnvelope<T>(parsed, response.status);
    }
    return parsed as T;
  }

  /**
   * `HEAD` on the logical path. For `localDesktop`, not all routes exist (e.g. workspace exists
   * may be remote-only).
   */
  async headOk(path: string): Promise<boolean> {
    const normalized = path.startsWith("/") ? path : `/${path}`;
    const url = this.buildJsonUrl(normalized);
    const headers: Record<string, string> = {};
    if (this.transport === "remote" || this.token.length > 0) {
      headers.Authorization = `Bearer ${this.token}`;
    }
    const response = await this.fetchFn(url.toString(), {
      method: "HEAD",
      headers,
    });
    if (response.status === 200) {
      return true;
    }
    if (response.status === 404) {
      return false;
    }
    const text = await response.text().catch(() => "");
    throw new VkApiError(response.status, text);
  }

  /**
   * `PUT` to an absolute URL (e.g. Azure Blob SAS from `POST /v1/attachments/init`). Does not send
   * `Authorization` — the URL must include credentials (SAS).
   */
  async putExternal(
    absoluteUrl: string,
    body: FetchBinaryBody,
    headers: Record<string, string>
  ): Promise<void> {
    const response = await this.fetchFn(absoluteUrl, {
      method: "PUT",
      headers,
      body,
    });
    // Azure Put Blob is usually 201; treat any 2xx as success (proxies or API revisions may differ).
    if (!response.ok) {
      const text = await response.text().catch(() => "");
      throw new VkApiError(response.status, text || response.statusText);
    }
  }

  private buildJsonUrl(normalizedPath: string): URL {
    if (this.transport === "remote") {
      return new URL(`${this.base}/v1${normalizedPath}`);
    }
    const prefix = normalizedPath.startsWith("/organizations")
      ? `${this.base}/api`
      : `${this.base}/api/remote`;
    return new URL(`${prefix}${normalizedPath}`);
  }
}

interface LocalApiEnvelope {
  success: boolean;
  data?: unknown;
  message?: string | null;
}

function unwrapLocalApiEnvelope<T>(parsed: unknown, httpStatus: number): T {
  if (!parsed || typeof parsed !== "object" || !("success" in parsed)) {
    return parsed as T;
  }
  const envelope = parsed as LocalApiEnvelope;
  if (!envelope.success) {
    throw new VkApiError(
      httpStatus >= 400 ? httpStatus : 400,
      envelope.message ?? "Desktop API returned success: false"
    );
  }
  return envelope.data as T;
}
