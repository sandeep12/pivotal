import type { RemoteHttp } from "../http.js";
import type {
  BulkUpdateProjectStatusesRequest,
  BulkUpdateProjectStatusesResponse,
  CreateProjectStatusRequest,
  DeleteResponse,
  ListProjectStatusesQuery,
  ListProjectStatusesResponse,
  MutationResponse,
  ProjectStatus,
  UpdateProjectStatusRequest,
  Uuid,
} from "../types.js";

export class ProjectStatusesResource {
  constructor(private readonly http: RemoteHttp) {}

  list(query: ListProjectStatusesQuery): Promise<ListProjectStatusesResponse> {
    return this.http.request("GET", "/project_statuses", {
      query: { project_id: query.project_id },
    });
  }

  get(id: Uuid): Promise<ProjectStatus> {
    return this.http.request("GET", `/project_statuses/${id}`);
  }

  create(
    body: CreateProjectStatusRequest
  ): Promise<MutationResponse<ProjectStatus>> {
    return this.http.request("POST", "/project_statuses", { body });
  }

  update(
    id: Uuid,
    body: UpdateProjectStatusRequest
  ): Promise<MutationResponse<ProjectStatus>> {
    return this.http.request("PATCH", `/project_statuses/${id}`, { body });
  }

  delete(id: Uuid): Promise<DeleteResponse> {
    return this.http.request("DELETE", `/project_statuses/${id}`);
  }

  bulkUpdate(
    body: BulkUpdateProjectStatusesRequest
  ): Promise<BulkUpdateProjectStatusesResponse> {
    return this.http.request("POST", "/project_statuses/bulk", { body });
  }
}
