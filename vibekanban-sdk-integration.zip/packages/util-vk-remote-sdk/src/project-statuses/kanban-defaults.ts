import type { ProjectStatus } from "../types.js";

function findProjectStatusByLowerName(
  statuses: ProjectStatus[],
  name: string
): ProjectStatus | null {
  const needle = name.toLowerCase();
  return statuses.find((s) => s.name.trim().toLowerCase() === needle) ?? null;
}

function firstProjectStatusBySortOrder(
  statuses: ProjectStatus[]
): ProjectStatus | null {
  if (!statuses.length) {
    return null;
  }
  return [...statuses].sort((a, b) => a.sort_order - b.sort_order)[0] ?? null;
}

/**
 * Resolves common Kanban columns for scripts: TODO-like and In Progress-like, with sensible
 * fallbacks when naming differs.
 */
export function resolveDefaultKanbanTodoAndInProgressStatuses(
  project_statuses: ProjectStatus[]
): { todo: ProjectStatus; inProgress: ProjectStatus } {
  const todo =
    findProjectStatusByLowerName(project_statuses, "to do") ??
    findProjectStatusByLowerName(project_statuses, "todo") ??
    firstProjectStatusBySortOrder(project_statuses);
  const inProgress =
    findProjectStatusByLowerName(project_statuses, "in progress") ??
    findProjectStatusByLowerName(project_statuses, "in-progress") ??
    findProjectStatusByLowerName(project_statuses, "doing") ??
    todo;

  if (!todo || !inProgress) {
    throw new Error("Could not resolve TODO/In Progress statuses.");
  }
  return { todo, inProgress };
}
