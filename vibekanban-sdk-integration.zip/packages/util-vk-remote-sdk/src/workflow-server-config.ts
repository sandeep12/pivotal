/**
 * Build environment variable key/value pairs for the **remote** server so it
 * POSTs `issue.status_changed` to your URL. Apply via docker-compose, K8s, etc.
 *
 * There is no REST "register webhook" API; the server reads these at startup.
 */

export interface WorkflowCallbackInput {
  url: string;
  secret?: string;
  timeoutMs?: number;
}

export function buildWorkflowCallback(
  input: WorkflowCallbackInput
): Record<string, string> {
  const out: Record<string, string> = {
    VK_WORKFLOW_CALLBACK_URL: input.url,
  };
  if (input.secret !== undefined && input.secret.length > 0) {
    out.VK_WORKFLOW_CALLBACK_SECRET = input.secret;
  }
  if (input.timeoutMs !== undefined) {
    out.VK_WORKFLOW_CALLBACK_TIMEOUT_MS = String(input.timeoutMs);
  }
  return out;
}

/** Single-line `.env` style (no trailing newline). Useful for logs / copy-paste. */
export function formatWorkflowCallback(input: WorkflowCallbackInput): string {
  return Object.entries(buildWorkflowCallback(input))
    .map(([k, v]) => `${k}=${escapeEnvValue(v)}`)
    .join("\n");
}

function escapeEnvValue(value: string): string {
  if (/[\s#"']/.test(value)) {
    return `"${value.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
  }
  return value;
}
