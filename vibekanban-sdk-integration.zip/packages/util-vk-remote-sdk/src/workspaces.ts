import type { RemoteHttp } from "./http.js";
import { WorkspaceOwnershipMismatchError } from "./errors.js";
import type {
  CreateWorkspaceRequest,
  Issue,
  DeleteWorkspaceRequest,
  UpdateWorkspaceRequest,
  Uuid,
  Workspace,
} from "./types.js";

export type WorkspaceOwnershipMode = "none" | "issueCreator" | "explicitUser";

export interface WorkspaceOwnershipPolicy {
  /**
   * - `none`: do not validate ownership (default)
   * - `issueCreator`: owner must match `issue.creator_user_id`
   * - `explicitUser`: owner must match `expected_owner_user_id`
   */
  mode?: WorkspaceOwnershipMode;
  /** Required only when `mode` is `explicitUser`. */
  expected_owner_user_id?: Uuid;
}

export interface CreateIssueAttachedWorkspaceRequest extends Omit<
  CreateWorkspaceRequest,
  "issue_id" | "local_workspace_id"
> {
  issue_id: Uuid;
  local_workspace_id: Uuid;
  ownership?: WorkspaceOwnershipPolicy;
}

export class WorkspacesResource {
  constructor(private readonly http: RemoteHttp) {}

  create(body: CreateWorkspaceRequest): Promise<Workspace> {
    return this.http.request("POST", "/workspaces", { body });
  }

  /**
   * Create a workspace attached to an issue and optionally enforce ownership.
   *
   * This is useful when UI behavior depends on workspace ownership and your
   * automation can run under different auth contexts.
   */
  async createAttachedToIssue(
    body: CreateIssueAttachedWorkspaceRequest
  ): Promise<Workspace> {
    const workspace = await this.create(body);
    const mode = body.ownership?.mode ?? "none";
    if (mode === "none") {
      return workspace;
    }

    if (mode === "issueCreator") {
      const issue = await this.http.request<Issue>(
        "GET",
        `/issues/${body.issue_id}`
      );
      if (!issue.creator_user_id) {
        throw new Error(
          `Issue ${body.issue_id} has no creator_user_id; cannot enforce issueCreator ownership.`
        );
      }
      this.assertExpectedOwner(
        workspace,
        issue.creator_user_id,
        "issueCreator"
      );
      return workspace;
    }

    const expectedOwner = body.ownership?.expected_owner_user_id;
    if (!expectedOwner) {
      throw new Error(
        'ownership.expected_owner_user_id is required when ownership.mode is "explicitUser".'
      );
    }
    this.assertExpectedOwner(workspace, expectedOwner, "explicitUser");
    return workspace;
  }

  update(body: UpdateWorkspaceRequest): Promise<Workspace> {
    return this.http.request("PATCH", "/workspaces", { body });
  }

  delete(body: DeleteWorkspaceRequest): Promise<void> {
    return this.http.request("DELETE", "/workspaces", { body });
  }

  unlink(workspaceId: Uuid): Promise<void> {
    return this.http.request("DELETE", `/workspaces/${workspaceId}`);
  }

  getByLocalId(localWorkspaceId: Uuid): Promise<Workspace> {
    return this.http.request(
      "GET",
      `/workspaces/by-local-id/${localWorkspaceId}`
    );
  }

  /** `HEAD /v1/workspaces/exists/{local_workspace_id}` — 200 vs 404. */
  exists(localWorkspaceId: Uuid): Promise<boolean> {
    return this.http.headOk(`/workspaces/exists/${localWorkspaceId}`);
  }

  syncIssueStatusFromLocalMerge(localWorkspaceId: Uuid): Promise<void> {
    return this.http.request(
      "POST",
      `/workspaces/${localWorkspaceId}/sync_issue_status_from_local_merge`
    );
  }

  private assertExpectedOwner(
    workspace: Workspace,
    expectedOwnerUserId: Uuid,
    context: "issueCreator" | "explicitUser"
  ): void {
    if (workspace.owner_user_id !== expectedOwnerUserId) {
      throw new WorkspaceOwnershipMismatchError({
        workspaceId: workspace.id,
        actualOwnerUserId: workspace.owner_user_id,
        expectedOwnerUserId,
        context,
      });
    }
  }
}
