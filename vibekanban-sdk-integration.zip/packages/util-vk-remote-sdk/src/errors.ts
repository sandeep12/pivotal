/** Thrown when the remote API returns a non-success HTTP status. */
export class VkApiError extends Error {
  readonly status: number;
  readonly bodyText: string;

  constructor(status: number, bodyText: string) {
    super(`VK remote API error HTTP ${status}: ${truncate(bodyText, 200)}`);
    this.name = "VkApiError";
    this.status = status;
    this.bodyText = bodyText;
  }
}

/** Thrown when a created workspace owner does not match the expected policy. */
export class WorkspaceOwnershipMismatchError extends Error {
  readonly workspaceId: string;
  readonly actualOwnerUserId: string;
  readonly expectedOwnerUserId: string;

  constructor(params: {
    workspaceId: string;
    actualOwnerUserId: string;
    expectedOwnerUserId: string;
    context: "issueCreator" | "explicitUser";
  }) {
    super(
      `Workspace ${params.workspaceId} owner mismatch (${params.context}): ` +
        `expected ${params.expectedOwnerUserId}, got ${params.actualOwnerUserId}. ` +
        "Use the correct authenticated user/session when creating linked workspaces."
    );
    this.name = "WorkspaceOwnershipMismatchError";
    this.workspaceId = params.workspaceId;
    this.actualOwnerUserId = params.actualOwnerUserId;
    this.expectedOwnerUserId = params.expectedOwnerUserId;
  }
}

function truncate(s: string, max: number): string {
  if (s.length <= max) {
    return s;
  }
  return `${s.slice(0, max)}…`;
}
