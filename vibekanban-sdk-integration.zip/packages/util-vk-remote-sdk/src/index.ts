export { VkApiError, WorkspaceOwnershipMismatchError } from "./errors.js";
export { VkRemoteClient } from "./client.js";
export { LocalAgentClient } from "./local-agent/index.js";
export type { LocalAgentClientOptions } from "./local-agent/index.js";
export {
  LocalAgentScratchResource,
  getProjectRepoDefaults,
  saveProjectRepoDefaults,
  isLocalScratchNotFoundError,
} from "./local-agent/scratch.js";
export type {
  VkRemoteClientOptions,
  RequestOptions,
  HttpMethod,
  RemoteTransport,
  FetchBinaryBody,
} from "./http.js";
export { RemoteHttp } from "./http.js";

export { OrganizationsResource } from "./organizations.js";
export { ProjectsResource } from "./projects.js";
export { ProjectStatusesResource } from "./project-statuses/project_statuses.js";
export { IssuesResource } from "./issues.js";
export { WorkspacesResource } from "./workspaces.js";
export type {
  WorkspaceOwnershipMode,
  WorkspaceOwnershipPolicy,
  CreateIssueAttachedWorkspaceRequest,
} from "./workspaces.js";
export {
  AttachmentsResource,
  computeAttachmentHashSha256,
  putPresignedBlobUpload,
} from "./attachments.js";
export type { UploadAndConfirmAttachmentInput } from "./attachments.js";

export { verifyWebhookSignature, parseVerifiedWebhook } from "./webhooks.js";

export {
  buildWorkflowCallback,
  formatWorkflowCallback,
} from "./workflow-server-config.js";
export type { WorkflowCallbackInput } from "./workflow-server-config.js";

export * from "./types.js";
export * from "./local-agent/types-local-agent.js";

export { createStepLogger } from "./utils/create-step-logger.js";

export { postRemoteLocalAuthLogin } from "./auth/remote-local-login.js";

export { normalizeLocalAgentBaseUrl } from "./local-agent/normalize-base-url.js";
export { resolveTargetBranchForLocalRepo } from "./local-agent/repo-utils.js";
export { bootstrapLocalWorkspaceWithRegisteredRepo } from "./local-agent/bootstrap-workspace.js";
export type {
  BootstrapLocalWorkspaceWithRepoOptions,
  BootstrapLocalWorkspaceWithRepoResult,
} from "./local-agent/bootstrap-workspace.js";
export { resolveLocalAgentWorkspace } from "./local-agent/resolve-workspace.js";
export type { ResolveLocalAgentWorkspaceOptions } from "./local-agent/resolve-workspace.js";

export {
  escapeMarkdownLabelForAttachment,
  formatIssueAttachmentMarkdownLine,
  buildSmokeTestJsModuleContent,
} from "./utils/issue-attachments.js";

export { getFileMimeType } from "./utils/file-mime-type.js";

export { resolveDefaultKanbanTodoAndInProgressStatuses } from "./project-statuses/kanban-defaults.js";

export { createVkRemoteClient } from "./vk-remote-client.js";
export type { CreateVkRemoteClientOptions } from "./vk-remote-client.js";
export {
  readVkRemoteSdkConfigFromEnv,
  readVkE2eWorkspaceFlowEnvOptions,
} from "./sdk-env-config.js";
export type {
  VkRemoteSdkConfig,
  VkE2eWorkspaceFlowEnvOptions,
} from "./sdk-env-config.js";
