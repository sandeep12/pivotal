import { createHash } from "node:crypto";

import { VkApiError } from "./errors.js";
import type { FetchBinaryBody, RemoteHttp } from "./http.js";
import type {
  AttachmentUrlResponse,
  AttachmentWithBlob,
  CommitAttachmentsRequest,
  CommitAttachmentsResponse,
  ConfirmUploadRequest,
  InitUploadRequest,
  InitUploadResponse,
  ListAttachmentsResponse,
  Uuid,
} from "./types.js";

export function computeAttachmentHashSha256(
  data: Uint8Array | ArrayBuffer
): string {
  const bytes = data instanceof ArrayBuffer ? new Uint8Array(data) : data;
  return createHash("sha256").update(bytes).digest("hex");
}

/**
 * `PUT` bytes to an Azure Blob **write** SAS URL (same contract as the web app’s Azure upload).
 * Does not use the VK API `Authorization` header.
 */
export async function putPresignedBlobUpload(
  uploadUrl: string,
  body: FetchBinaryBody,
  contentType: string,
  fetchImpl: typeof fetch = globalThis.fetch
): Promise<void> {
  const response = await fetchImpl(uploadUrl, {
    method: "PUT",
    headers: {
      "x-ms-blob-type": "BlockBlob",
      "Content-Type": contentType,
    },
    body,
  });
  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new VkApiError(response.status, text || response.statusText);
  }
}

function normalizeUploadBytes(data: Uint8Array | ArrayBuffer): {
  bytes: Uint8Array;
  body: FetchBinaryBody;
} {
  const bytes = data instanceof ArrayBuffer ? new Uint8Array(data) : data;
  return { bytes, body: bytes };
}

export interface UploadAndConfirmAttachmentInput {
  projectId: Uuid;
  filename: string;
  /** Defaults to `application/octet-stream` */
  contentType?: string;
  data: Uint8Array | ArrayBuffer;
  /**
   * If set, confirm creates an attachment row already bound to that target (with no expiry).
   * {@link AttachmentsResource.commitToIssue} / {@link AttachmentsResource.commitToComment} then
   * become no-ops for those rows (they only update staged rows where `issue_id`/`comment_id` are null).
   *
   * For the same flow as the web app (init → PUT → confirm staged → commit), omit both `issueId`
   * and `commentId`, then call `commitToIssue` / `commitToComment`.
   */
  issueId?: Uuid | null;
  commentId?: Uuid | null;
}

/**
 * Remote `/v1/attachments/*` — init → optional PUT to object storage → confirm.
 *
 * Blob/object keys are server-defined and commonly look like `attachments/{project_id}/...`.
 * The SDK treats storage as opaque and only uses the API responses (`init` URL + headers).
 *
 * **Kanban UI:** issue/comment bodies render uploads only when markdown includes
 * `![label](attachment://<attachment_id>)` or `[label](attachment://<attachment_id>)`. Rows in
 * Postgres alone are not shown in the description editor until that markdown exists (or the app
 * loads them from a list endpoint you wire up). Remote workspaces do not have a separate
 * attachment store — files belong to **issues** or **comments**.
 *
 * To **link** staged drafts to an issue after creation, call {@link AttachmentsResource.commitToIssue}.
 */
export class AttachmentsResource {
  constructor(private readonly http: RemoteHttp) {}

  init(body: InitUploadRequest): Promise<InitUploadResponse> {
    return this.http.request("POST", "/attachments/init", { body });
  }

  confirm(body: ConfirmUploadRequest): Promise<AttachmentWithBlob> {
    return this.http.request("POST", "/attachments/confirm", { body });
  }

  listForIssue(issueId: Uuid): Promise<ListAttachmentsResponse> {
    return this.http.request("GET", `/issues/${issueId}/attachments`);
  }

  listForComment(commentId: Uuid): Promise<ListAttachmentsResponse> {
    return this.http.request("GET", `/comments/${commentId}/attachments`);
  }

  commitToIssue(
    issueId: Uuid,
    body: CommitAttachmentsRequest
  ): Promise<CommitAttachmentsResponse> {
    return this.http.request("POST", `/issues/${issueId}/attachments/commit`, {
      body,
    });
  }

  commitToComment(
    commentId: Uuid,
    body: CommitAttachmentsRequest
  ): Promise<CommitAttachmentsResponse> {
    return this.http.request(
      "POST",
      `/comments/${commentId}/attachments/commit`,
      {
        body,
      }
    );
  }

  getFileSas(attachmentId: Uuid): Promise<AttachmentUrlResponse> {
    return this.http.request("GET", `/attachments/${attachmentId}/file`);
  }

  getThumbnailSas(attachmentId: Uuid): Promise<AttachmentUrlResponse> {
    return this.http.request("GET", `/attachments/${attachmentId}/thumbnail`);
  }

  delete(attachmentId: Uuid): Promise<void> {
    return this.http.request("DELETE", `/attachments/${attachmentId}`);
  }

  /**
   * Hash → `init` → `PUT` to `upload_url` when `skip_upload` is false → `confirm`.
   * See {@link UploadAndConfirmAttachmentInput} for staged vs bound `issueId`/`commentId`.
   */
  async uploadAndConfirm(
    input: UploadAndConfirmAttachmentInput
  ): Promise<AttachmentWithBlob> {
    const { bytes, body } = normalizeUploadBytes(input.data);
    const hash = computeAttachmentHashSha256(bytes);
    const size_bytes = bytes.byteLength;
    const contentType = input.contentType ?? "application/octet-stream";

    const init = await this.init({
      project_id: input.projectId,
      filename: input.filename,
      size_bytes,
      hash,
    });

    if (!init.skip_upload) {
      await this.http.putExternal(init.upload_url, body, {
        "x-ms-blob-type": "BlockBlob",
        "Content-Type": contentType,
      });
    }

    return this.confirm({
      project_id: input.projectId,
      upload_id: init.upload_id,
      filename: input.filename,
      content_type: contentType,
      size_bytes,
      hash,
      issue_id: input.issueId ?? undefined,
      comment_id: input.commentId ?? undefined,
    });
  }
}
