/**
 * Hand-maintained shapes aligned with `api-types` / remote `/v1` JSON.
 * Expand fields as your automation needs them.
 */

export type Uuid = string;

/** ISO-8601 timestamps as returned by the API */
export type IsoDateTime = string;

export type MemberRole = string;

export interface Organization {
  id: Uuid;
  name: string;
  slug: string;
  is_personal: boolean;
  issue_prefix: string;
  created_at: IsoDateTime;
  updated_at: IsoDateTime;
}

export interface OrganizationWithRole extends Organization {
  user_role: MemberRole;
}

export interface ListOrganizationsResponse {
  organizations: OrganizationWithRole[];
}

export interface GetOrganizationResponse {
  organization: Organization;
  user_role: string;
}

export interface CreateOrganizationRequest {
  name: string;
  slug: string;
}

export interface CreateOrganizationResponse {
  organization: OrganizationWithRole;
}

export interface UpdateOrganizationRequest {
  name: string;
}

export interface Project {
  id: Uuid;
  organization_id: Uuid;
  name: string;
  color: string;
  sort_order: number;
  created_at: IsoDateTime;
  updated_at: IsoDateTime;
}

export interface ListProjectsQuery {
  organization_id: Uuid;
}

export interface ListProjectsResponse {
  projects: Project[];
}

export interface CreateProjectRequest {
  id?: Uuid;
  organization_id: Uuid;
  name: string;
  color: string;
}

export interface UpdateProjectRequest {
  name?: string;
  color?: string;
  sort_order?: number;
}

/** Kanban column for a project (`crates/api-types/src/project_status.rs`). */
export interface ProjectStatus {
  id: Uuid;
  project_id: Uuid;
  name: string;
  /** Server expects HSL, e.g. `"220 14% 96%"`. */
  color: string;
  sort_order: number;
  hidden: boolean;
  created_at: IsoDateTime;
}

export interface ListProjectStatusesQuery {
  project_id: Uuid;
}

export interface ListProjectStatusesResponse {
  project_statuses: ProjectStatus[];
}

export interface CreateProjectStatusRequest {
  id?: Uuid;
  project_id: Uuid;
  name: string;
  color: string;
  sort_order: number;
  hidden: boolean;
}

/** PATCH body; omit fields you do not want to change. */
export interface UpdateProjectStatusRequest {
  name?: string;
  color?: string;
  sort_order?: number;
  hidden?: boolean;
}

/** One row in `POST /v1/project_statuses/bulk` (`id` + flattened change fields). */
export interface BulkUpdateProjectStatusItem {
  id: Uuid;
  name?: string;
  color?: string;
  sort_order?: number;
  hidden?: boolean;
}

export interface BulkUpdateProjectStatusesRequest {
  updates: BulkUpdateProjectStatusItem[];
}

export interface BulkUpdateProjectStatusesResponse {
  data: ProjectStatus[];
  txid: number;
}

/** Returned by `DELETE /v1/project_statuses/{id}` and other deletes on remote. */
export interface DeleteResponse {
  txid: number;
}

export interface Issue {
  id: Uuid;
  project_id: Uuid;
  issue_number: number;
  simple_id: string;
  status_id: Uuid;
  title: string;
  description: string | null;
  priority: string | null;
  start_date: IsoDateTime | null;
  target_date: IsoDateTime | null;
  completed_at: IsoDateTime | null;
  sort_order: number;
  parent_issue_id: Uuid | null;
  parent_issue_sort_order: number | null;
  extension_metadata: Record<string, unknown>;
  creator_user_id: Uuid | null;
  created_at: IsoDateTime;
  updated_at: IsoDateTime;
}

export interface ListIssuesQuery {
  project_id: Uuid;
}

export interface ListIssuesResponse {
  issues: Issue[];
}

export interface CreateIssueRequest {
  id?: Uuid;
  project_id: Uuid;
  status_id: Uuid;
  title: string;
  description?: string | null;
  priority?: string | null;
  start_date?: IsoDateTime | null;
  target_date?: IsoDateTime | null;
  completed_at?: IsoDateTime | null;
  sort_order: number;
  parent_issue_id?: Uuid | null;
  parent_issue_sort_order?: number | null;
  extension_metadata: Record<string, unknown>;
}

export interface UpdateIssueRequest {
  status_id?: Uuid;
  title?: string;
  description?: string | null;
  priority?: string | null;
  start_date?: IsoDateTime | null;
  target_date?: IsoDateTime | null;
  completed_at?: IsoDateTime | null;
  sort_order?: number;
  parent_issue_id?: Uuid | null;
  parent_issue_sort_order?: number | null;
  extension_metadata?: Record<string, unknown>;
}

export interface MutationResponse<T> {
  data: T;
  txid: number;
}

export interface Workspace {
  id: Uuid;
  project_id: Uuid;
  owner_user_id: Uuid;
  issue_id: Uuid | null;
  local_workspace_id: Uuid | null;
  name: string;
  archived: boolean;
  files_changed: number;
  lines_added: number;
  lines_removed: number;
  created_at: IsoDateTime;
  updated_at: IsoDateTime;
}

/** Body for `POST /v1/workspaces` (remote route shape; optional fields per server). */
export interface CreateWorkspaceRequest {
  project_id: Uuid;
  local_workspace_id?: Uuid;
  issue_id?: Uuid;
  name?: string;
  archived?: boolean;
  files_changed?: number;
  lines_added?: number;
  lines_removed?: number;
}

export interface UpdateWorkspaceRequest {
  local_workspace_id: Uuid;
  name?: string | null;
  archived?: boolean;
  files_changed?: number | null;
  lines_added?: number | null;
  lines_removed?: number | null;
}

export interface DeleteWorkspaceRequest {
  local_workspace_id: Uuid;
}

// --- Remote attachments (`/v1/attachments/...`, Azure-backed) ---

export interface InitUploadRequest {
  project_id: Uuid;
  filename: string;
  /** Byte length; max 20MB on server */
  size_bytes: number;
  /** Lowercase hex SHA-256 of file bytes */
  hash: string;
}

export interface InitUploadResponse {
  upload_url: string;
  upload_id: Uuid;
  expires_at: IsoDateTime;
  skip_upload: boolean;
  existing_blob_id: Uuid | null;
}

export interface ConfirmUploadRequest {
  project_id: Uuid;
  upload_id: Uuid;
  filename: string;
  content_type?: string | null;
  size_bytes: number;
  hash: string;
  issue_id?: Uuid | null;
  comment_id?: Uuid | null;
}

/** Attachment row + blob metadata (flattened in list responses with `file_url`). */
export interface AttachmentWithBlob {
  id: Uuid;
  blob_id: Uuid;
  issue_id: Uuid | null;
  comment_id: Uuid | null;
  created_at: IsoDateTime;
  expires_at: IsoDateTime | null;
  blob_path: string;
  thumbnail_blob_path: string | null;
  original_name: string;
  mime_type: string | null;
  size_bytes: number;
  hash: string;
  width: number | null;
  height: number | null;
}

export interface AttachmentWithUrl extends AttachmentWithBlob {
  file_url?: string | null;
}

export interface ListAttachmentsResponse {
  attachments: AttachmentWithUrl[];
}

export interface CommitAttachmentsRequest {
  attachment_ids: Uuid[];
}

export interface CommitAttachmentsResponse {
  attachments: AttachmentWithBlob[];
}

export interface AttachmentUrlResponse {
  url: string;
}

/** Payload for workflow callback `issue.status_changed` (see WORKFLOW_CALLBACKS_PLAN.md). */
export interface IssueStatusChangedEvent {
  schema_version: number;
  event: "issue.status_changed";
  occurred_at: string;
  organization_id: Uuid;
  actor_user_id: Uuid;
  issue: Issue;
  previous_status_id: Uuid;
  previous_status_name: string | null;
  new_status_id: Uuid;
  new_status_name: string | null;
  postgres_txid?: number | null;
}
