export async function postRemoteLocalAuthLogin(
  baseUrl: string,
  email: string,
  password: string,
  fetchImpl: typeof fetch = globalThis.fetch
): Promise<string> {
  const origin = baseUrl.replace(/\/+$/, "");
  const url = `${origin}/v1/auth/local/login`;
  const response = await fetchImpl(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });
  const text = await response.text();
  if (!response.ok) {
    throw new Error(
      `POST /v1/auth/local/login failed: ${response.status} ${text}`
    );
  }
  const parsed = JSON.parse(text) as { access_token?: string };
  if (!parsed.access_token) {
    throw new Error("Local login response missing access_token");
  }
  return parsed.access_token;
}
