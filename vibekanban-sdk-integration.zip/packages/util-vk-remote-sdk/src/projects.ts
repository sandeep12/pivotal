import type { RemoteHttp } from "./http.js";
import type {
  CreateProjectRequest,
  ListProjectsQuery,
  ListProjectsResponse,
  MutationResponse,
  Project,
  UpdateProjectRequest,
  Uuid,
} from "./types.js";

export class ProjectsResource {
  constructor(private readonly http: RemoteHttp) {}

  list(query: ListProjectsQuery): Promise<ListProjectsResponse> {
    return this.http.request("GET", "/projects", {
      query: { organization_id: query.organization_id },
    });
  }

  get(id: Uuid): Promise<Project> {
    return this.http.request("GET", `/projects/${id}`);
  }

  create(body: CreateProjectRequest): Promise<MutationResponse<Project>> {
    return this.http.request("POST", "/projects", { body });
  }

  update(
    id: Uuid,
    body: UpdateProjectRequest
  ): Promise<MutationResponse<Project>> {
    return this.http.request("PATCH", `/projects/${id}`, { body });
  }

  delete(id: Uuid): Promise<void> {
    return this.http.request("DELETE", `/projects/${id}`);
  }
}
