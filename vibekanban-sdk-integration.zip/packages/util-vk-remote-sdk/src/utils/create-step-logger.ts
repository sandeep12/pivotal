/** Progress on stderr so stdout can stay machine-readable (e.g. final JSON). */
export function createStepLogger(prefix: string) {
  return (label: string, detail = "") => {
    const suffix = detail ? ` ${detail}` : "";
    console.error(`[${prefix}] ✓ ${label}${suffix}`);
  };
}
