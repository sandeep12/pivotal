/** Matches `buildAttachmentMarkdown` in web-core (issue description / comments). */
export function escapeMarkdownLabelForAttachment(value: string): string {
  return value.replace(/[[\]\\]/g, "\\$&");
}

export function formatIssueAttachmentMarkdownLine(
  row: { id: string; original_name: string },
  contentType: string
): string {
  const label = escapeMarkdownLabelForAttachment(row.original_name);
  const src = `attachment://${row.id}`;
  if (contentType.startsWith("image/")) {
    return `![${label}](${src})`;
  }
  return `[${label}](${src})`;
}

export function buildSmokeTestJsModuleContent(tag: string): string {
  return `export function smokeTest() {\n  return 'e2e:${tag}';\n}\n`;
}
