import type { RemoteHttp } from "./http.js";
import type {
  CreateIssueRequest,
  Issue,
  ListIssuesQuery,
  ListIssuesResponse,
  MutationResponse,
  UpdateIssueRequest,
  Uuid,
} from "./types.js";

export class IssuesResource {
  constructor(private readonly http: RemoteHttp) {}

  list(query: ListIssuesQuery): Promise<ListIssuesResponse> {
    return this.http.request("GET", "/issues", {
      query: { project_id: query.project_id },
    });
  }

  get(issueId: Uuid): Promise<Issue> {
    return this.http.request("GET", `/issues/${issueId}`);
  }

  create(body: CreateIssueRequest): Promise<MutationResponse<Issue>> {
    return this.http.request("POST", "/issues", { body });
  }

  update(
    issueId: Uuid,
    body: UpdateIssueRequest
  ): Promise<MutationResponse<Issue>> {
    return this.http.request("PATCH", `/issues/${issueId}`, { body });
  }

  delete(issueId: Uuid): Promise<void> {
    return this.http.request("DELETE", `/issues/${issueId}`);
  }
}
