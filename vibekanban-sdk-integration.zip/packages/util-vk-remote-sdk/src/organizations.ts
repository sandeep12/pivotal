import type { RemoteHttp } from "./http.js";
import type {
  CreateOrganizationRequest,
  CreateOrganizationResponse,
  GetOrganizationResponse,
  ListOrganizationsResponse,
  UpdateOrganizationRequest,
  Uuid,
} from "./types.js";

export class OrganizationsResource {
  constructor(private readonly http: RemoteHttp) {}

  list(): Promise<ListOrganizationsResponse> {
    return this.http.request("GET", "/organizations");
  }

  create(body: CreateOrganizationRequest): Promise<CreateOrganizationResponse> {
    return this.http.request("POST", "/organizations", { body });
  }

  get(orgId: Uuid): Promise<GetOrganizationResponse> {
    return this.http.request("GET", `/organizations/${orgId}`);
  }

  update(orgId: Uuid, body: UpdateOrganizationRequest): Promise<unknown> {
    return this.http.request("PATCH", `/organizations/${orgId}`, { body });
  }

  delete(orgId: Uuid): Promise<void> {
    return this.http.request("DELETE", `/organizations/${orgId}`);
  }
}
