import { createHmac, timingSafeEqual } from "node:crypto";

import type { IssueStatusChangedEvent } from "./types.js";

const SIG_PREFIX = "sha256=";

/**
 * Verify `X-VK-Signature: sha256=<hex>` where the HMAC key is `secret` and the
 * message is the **raw** request body (same bytes the remote server signed).
 */
export function verifyWebhookSignature(
  rawBody: Buffer,
  signatureHeader: string | undefined,
  secret: string
): boolean {
  if (!signatureHeader || !secret) {
    return false;
  }

  const trimmed = signatureHeader.trim();
  if (!trimmed.startsWith(SIG_PREFIX)) {
    return false;
  }

  const receivedHex = trimmed.slice(SIG_PREFIX.length);
  if (!/^[0-9a-f]+$/i.test(receivedHex) || receivedHex.length % 2 !== 0) {
    return false;
  }

  const received = Buffer.from(receivedHex, "hex");
  const expected = createHmac("sha256", secret).update(rawBody).digest();

  if (received.length !== expected.length) {
    return false;
  }

  return timingSafeEqual(received, expected);
}

/** Verify signature then `JSON.parse` the body into `IssueStatusChangedEvent`. */
export function parseVerifiedWebhook(
  rawBody: Buffer,
  signatureHeader: string | undefined,
  secret: string
): IssueStatusChangedEvent {
  if (!verifyWebhookSignature(rawBody, signatureHeader, secret)) {
    throw new Error("Invalid or missing webhook signature");
  }
  const parsed: unknown = JSON.parse(rawBody.toString("utf8"));
  return parsed as IssueStatusChangedEvent;
}
