import type { RemoteTransport } from "./http.js";

/** Env keys consumed by {@link readVkRemoteSdkConfigFromEnv} / {@link createVkRemoteClient}. */
export interface VkRemoteSdkConfig {
  transport: RemoteTransport;
  /** When `transport` is `localDesktop`, base URL of the desktop / Vite origin. */
  localApiBase: string | undefined;
  /** When `transport` is `remote`, remote API origin (no `/v1` suffix in env). */
  remoteBaseUrl: string | undefined;
  remoteAccessToken: string | undefined;
  remoteEmail: string | undefined;
  remotePassword: string | undefined;
}

/**
 * Reads SDK client settings from a map (defaults to `process.env` in Node).
 * Use this once at app startup, then pass the result to {@link createVkRemoteClient}.
 *
 * In the browser, pass a plain object (for example values merged from `import.meta.env`).
 */
export function readVkRemoteSdkConfigFromEnv(
  env: Record<string, string | undefined> = typeof process !== "undefined"
    ? process.env
    : {}
): VkRemoteSdkConfig {
  const transport: RemoteTransport =
    env.VK_SDK_TRANSPORT === "local" ? "localDesktop" : "remote";
  return {
    transport,
    localApiBase: env.VK_LOCAL_API_BASE?.trim() || undefined,
    remoteBaseUrl: env.VK_REMOTE_BASE_URL?.trim() || undefined,
    remoteAccessToken: env.VK_REMOTE_ACCESS_TOKEN?.trim() || undefined,
    remoteEmail: env.VK_REMOTE_EMAIL?.trim() || undefined,
    remotePassword: env.VK_REMOTE_PASSWORD?.trim() || undefined,
  };
}

function envFlagTrue(
  env: Record<string, string | undefined>,
  key: string
): boolean {
  const v = env[key]?.trim().toLowerCase();
  return v === "1" || v === "true" || v === "yes";
}

/** Optional knobs for {@link examples/end-to-end-workspace-flow.mjs} (and similar scripts). */
export interface VkE2eWorkspaceFlowEnvOptions {
  /**
   * When true, the E2E script ignores `VK_LOCAL_API_BASE` (no bootstrap, no local agent queue).
   * Use for remote-only runs while keeping a local URL in `.env.e2e` for later.
   */
  skipLocalDesktopSections: boolean;
  localApiBase: string | null;
  localRepoId: string | null;
  localTargetBranch: string | null;
  extraFilePath: string | null;
  localFollowUpExecutor: string | null;
  localQueueMessage: string | null;
  localFollowUpPrompt: string | null;
  /** True when `VK_E2E_PROJECT_REPO_DEFAULTS` is the string `"1"`. */
  projectRepoDefaultsEnabled: boolean;
}

/**
 * Reads E2E script–specific env vars (optional local bootstrap, attachments, session queue, etc.).
 * Does not include remote auth fields; use {@link readVkRemoteSdkConfigFromEnv} for those.
 */
export function readVkE2eWorkspaceFlowEnvOptions(
  env: Record<string, string | undefined> = typeof process !== "undefined"
    ? process.env
    : {}
): VkE2eWorkspaceFlowEnvOptions {
  const t = (k: string) => env[k]?.trim() || null;
  const skipLocal = envFlagTrue(env, "VK_E2E_SKIP_LOCAL_DESKTOP");
  return {
    skipLocalDesktopSections: skipLocal,
    localApiBase: skipLocal ? null : t("VK_LOCAL_API_BASE"),
    localRepoId: t("VK_E2E_LOCAL_REPO_ID"),
    localTargetBranch: t("VK_E2E_LOCAL_TARGET_BRANCH"),
    extraFilePath: t("VK_E2E_FILE_PATH"),
    localFollowUpExecutor: t("VK_E2E_LOCAL_FOLLOW_UP_EXECUTOR"),
    localQueueMessage: t("VK_E2E_LOCAL_QUEUE_MESSAGE"),
    localFollowUpPrompt: t("VK_E2E_LOCAL_FOLLOW_UP_PROMPT"),
    projectRepoDefaultsEnabled:
      env.VK_E2E_PROJECT_REPO_DEFAULTS?.trim() === "1",
  };
}
