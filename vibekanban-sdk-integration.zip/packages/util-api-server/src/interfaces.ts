import type { Server as HttpServer } from "node:http";

import type { Application } from "./types.js";

interface ApiServerContract {
  readonly expressApp: Application;
  /**
   * Node HTTP server; set after `start()` completes. `null` before listen or after `stop()`.
   */
  readonly httpServer: HttpServer | null;
  readonly port: number;
  start: () => Promise<void>;
  stop: () => Promise<void>;
}

export type { ApiServerContract };
