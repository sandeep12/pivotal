# Future Roadmap — @util/jwt-tokens

- **OAuth integration:** Not in scope; future `@util/auth-orchestrator` package will layer on top.
- **Permission-based checks:** Optional `resolvePermissions`, `hasPermission` for handler-level checks.
- **ABAC types:** Extensible policy evaluation types for attribute-based access.
- **Cookie parsing:** Consumer handles; getToken supports custom extraction.
