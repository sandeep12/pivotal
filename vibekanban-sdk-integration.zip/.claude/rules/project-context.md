# Claude Rule Adapter

Adapter notice: source-of-truth for this file is in `agent-system/rules/project-context.md`.
