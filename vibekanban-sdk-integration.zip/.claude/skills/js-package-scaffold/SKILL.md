# Claude Skill Adapter

Adapter notice: source-of-truth for this file is in `agent-system/skills/js-package-scaffold/SKILL.md`.
