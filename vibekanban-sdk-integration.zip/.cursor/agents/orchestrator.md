# Cursor Agent Adapter

Adapter notice: source-of-truth for this file is in `agent-system/subagents/orchestrator.md`.
