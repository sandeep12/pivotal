---
name: skill-adapter
description: Cursor skill adapter
---

Adapter notice: source-of-truth for this file is in `agent-system/skills/js-code-style/SKILL.md`.
