import type { Server as HttpServer } from "node:http";
import type { Logger } from "@util/logger";

import { attachWebSocketRoute } from "@util/websocket";

import type { AgVidurServicePort } from "../../ag-vidur/ports/interfaces.js";

/**
 * Attach Vidur PCM bridge on the same HTTP server (WebSocket upgrade on `path`).
 */
export function vidurBridgeWebSocket(options: {
  httpServer: HttpServer;
  path: string;
  logger: Logger;
  agVidurService: AgVidurServicePort;
}): { close: () => Promise<void> } {
  const { httpServer, path, logger, agVidurService } = options;

  return attachWebSocketRoute({
    httpServer,
    path,
    name: "Vidur bridge",
    onSession: (session) =>
      agVidurService.registerVidurBridgeSession(session, logger),
    onAttached: ({ name: routeName, path: routePath }) => {
      logger.info(`${routeName} WebSocket attached to HTTP server`, {
        path: routePath,
      });
    },
  });
}
