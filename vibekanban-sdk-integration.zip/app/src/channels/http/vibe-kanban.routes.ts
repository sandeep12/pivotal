import type { RouteDefinition } from "@util/api-server";
import { ValidationError } from "@util/error-normalizer";
import { z } from "zod";

// import { createRequireRolesMiddleware } from "../../shared/auth/require-roles.middleware.js";
// import { getJwtSecret } from "../../shared/auth-config.js";
import { parseInput } from "../../shared/http/parse-input.util.js";
import type { VibeKanbanTaskBatchInput } from "../../vibe-kanban/ports/vibe-kanban-client.port.js";
import type { VibeKanbanService } from "../../vibe-kanban/service/vibe-kanban.service.js";

// const requireAuth = createRequireRolesMiddleware({
//   requiredRoles: ["user", "admin", "manager"],
//   secret: getJwtSecret(),
// });

const CreateProjectInputSchema = z.object({
  organizationId: z.string().min(1, "organizationId is required"),
  name: z.string().min(1, "name is required"),
  color: z.string().min(1, "color is required"),
});

const GetProjectStatusesInputSchema = z.object({
  projectId: z.string().min(1, "projectId is required"),
});

const ListProjectIssuesInputSchema = z.object({
  projectId: z.string().min(1, "projectId is required"),
});

const GetProjectRepoDefaultsInputSchema = z.object({
  projectId: z.string().min(1, "projectId is required"),
});

const SaveProjectRepoDefaultsInputSchema = z.object({
  projectId: z.string().min(1, "projectId is required"),
  repos: z.array(
    z.object({
      repo_id: z.string().min(1, "repo_id is required"),
      target_branch: z.string().min(1, "target_branch is required"),
    })
  ),
});

const RegisterRepoInputSchema = z.object({
  path: z.string().min(1, "path is required"),
  displayName: z.string().optional(),
});

const CreateTasksInputSchema = z.object({
  projectId: z.string().min(1, "projectId is required"),
  statusId: z.string().min(1, "statusId is required"),
  tasks: z
    .array(
      z.object({
        title: z.string().min(1, "title is required"),
        description: z.string().nullable().optional(),
        sortOrder: z.number().int().nonnegative().optional(),
        extensionMetadata: z.record(z.string(), z.unknown()).optional(),
      })
    )
    .min(1, "At least one task is required"),
});

function createVibeKanbanRoutes(deps: {
  vibeKanbanService: VibeKanbanService;
}): RouteDefinition[] {
  const { vibeKanbanService } = deps;
  return [
    {
      path: "/vibe-kanban/organizations",
      version: "v1",
      method: "GET",
      //middleware: [requireAuth],
      handler: async () => {
        const organizations = await vibeKanbanService.listOrganizations();
        return { organizations };
      },
    },
    {
      path: "/vibe-kanban/projects",
      version: "v1",
      method: "POST",
      // middleware: [requireAuth],
      handler: async (input) => {
        const payload = parseInput(CreateProjectInputSchema, input);
        const created = await vibeKanbanService.createProject({
          organization_id: payload.organizationId,
          name: payload.name,
          color: payload.color,
        });
        if (!created.ok) {
          throw new ValidationError(created.error);
        }
        return { project: created.project };
      },
    },
    {
      path: "/vibe-kanban/project-statuses",
      version: "v1",
      method: "GET",
      // middleware: [requireAuth],
      handler: async (input) => {
        const { projectId } = parseInput(GetProjectStatusesInputSchema, input);
        const result = await vibeKanbanService.getProjectStatuses(projectId);
        if (!result.ok) {
          throw new ValidationError(result.error);
        }
        return { statuses: result.statuses };
      },
    },
    {
      path: "/vibe-kanban/project-repo-defaults",
      version: "v1",
      method: "GET",
      handler: async (input) => {
        const { projectId } = parseInput(
          GetProjectRepoDefaultsInputSchema,
          input
        );
        const result =
          await vibeKanbanService.getProjectRepoDefaults(projectId);
        if (!result.ok) {
          throw new ValidationError(result.error);
        }
        return { repos: result.repos };
      },
    },
    {
      path: "/vibe-kanban/project-repo-defaults",
      version: "v1",
      method: "PUT",
      handler: async (input) => {
        const payload = parseInput(SaveProjectRepoDefaultsInputSchema, input);
        const result = await vibeKanbanService.saveProjectRepoDefaults(
          payload.projectId,
          payload.repos
        );
        if (!result.ok) {
          throw new ValidationError(result.error);
        }
        return { ok: true };
      },
    },
    {
      path: "/vibe-kanban/repos",
      version: "v1",
      method: "GET",
      handler: async () => {
        const result = await vibeKanbanService.listRepos();
        if (!result.ok) {
          throw new ValidationError(result.error);
        }
        return { repos: result.repos };
      },
    },
    {
      path: "/vibe-kanban/repos/register",
      version: "v1",
      method: "POST",
      handler: async (input) => {
        const { path, displayName } = parseInput(
          RegisterRepoInputSchema,
          input
        );
        const result = await vibeKanbanService.registerRepo(path, displayName);
        if (!result.ok) {
          throw new ValidationError(result.error);
        }
        return { repo: result.repo };
      },
    },
    {
      path: "/vibe-kanban/tasks/batch",
      version: "v1",
      method: "POST",
      // middleware: [requireAuth],
      handler: async (input) => {
        const payload = parseInput(CreateTasksInputSchema, input);
        const tasks: VibeKanbanTaskBatchInput["tasks"] = payload.tasks.map(
          (task) => ({
            title: task.title,
            description: task.description,
            sort_order: task.sortOrder,
            extension_metadata: task.extensionMetadata,
          })
        );
        const result = await vibeKanbanService.createTasks({
          project_id: payload.projectId,
          status_id: payload.statusId,
          tasks,
        });
        if (!result.ok) {
          throw new ValidationError(result.error);
        }
        return { tasks: result.tasks };
      },
    },
    /** Pivotel Kanban sync: list issues for a project (id, status_id, updated_at). */
    {
      path: "/vibe-kanban/issues/search",
      version: "v1",
      method: "POST",
      handler: async (input) => {
        const { projectId } = parseInput(ListProjectIssuesInputSchema, input);
        const result = await vibeKanbanService.listProjectIssues(projectId);
        if (!result.ok) {
          throw new ValidationError(result.error);
        }
        return { issues: result.issues };
      },
    },
  ];
}

export { createVibeKanbanRoutes };
