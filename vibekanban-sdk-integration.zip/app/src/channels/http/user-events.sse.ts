import type { Router } from "express";

import { createSseEndpoint } from "@util/api-server";

import { userService } from "../../user/index.js";
import { sseRedisHistoryStore } from "../../infrastructure/sse-redis-history-store.js";

const userTestEvents = createSseEndpoint({
  heartbeatMs: 15_000,
  eventHistoryStore: sseRedisHistoryStore,
  openApi: {
    path: "/events/users/test",
    version: "v1",
    summary: "SSE test stream from user service",
  },
  onConnect: ({ send, abortSignal }) => {
    userService.startTestSseStream({ send, abortSignal });
  },
});

/**
 * Mounts user SSE endpoints under the API router.
 */
const mountUserSseRoutes = (router: Router): void => {
  router.get("/v1/events/users/test", userTestEvents.handler);
};

export { mountUserSseRoutes, userTestEvents };
