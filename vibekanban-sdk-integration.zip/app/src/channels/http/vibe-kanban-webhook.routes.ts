import type { RouteDefinition } from "@util/api-server";
import { UnauthorizedError, ValidationError } from "@util/error-normalizer";
import type { Request } from "express";

import { verifyIssueStatusWebhook } from "../../vibe-kanban/infrastructure/vk-webhook.verifier.js";
import type { VibeKanbanService } from "../../vibe-kanban/service/vibe-kanban.service.js";

function readRawBody(req: Request | undefined): Buffer | undefined {
  if (!req) return undefined;
  const extended = req as Request & { rawBody?: Buffer };
  return Buffer.isBuffer(extended.rawBody) ? extended.rawBody : undefined;
}

function createVibeKanbanWebhookRoutes(deps: {
  vibeKanbanService: VibeKanbanService;
  webhookSecret: string;
}): RouteDefinition[] {
  const { vibeKanbanService, webhookSecret } = deps;
  return [
    {
      path: "/vibe-kanban/webhooks/issue-status",
      version: "v1",
      method: "POST",
      handler: async (_input, { logger, req }) => {
        const raw = readRawBody(req);
        if (!raw || raw.length === 0) {
          throw new ValidationError("JSON body required for webhook");
        }
        const sig = req?.headers["x-vk-signature"];
        const signatureHeader = Array.isArray(sig) ? sig[0] : sig;
        let payload;
        try {
          payload = verifyIssueStatusWebhook(
            raw,
            signatureHeader,
            webhookSecret
          );
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          if (msg.includes("signature")) {
            logger.warn("Vibe Kanban webhook rejected", {
              reason: "signature",
            });
            throw new UnauthorizedError("Invalid webhook signature");
          }
          logger.warn("Vibe Kanban webhook rejected", { reason: "parse", msg });
          throw new ValidationError("Invalid webhook body");
        }
        await vibeKanbanService.handleIssueStatusChanged(payload);
        return { accepted: true };
      },
    },
  ];
}

export { createVibeKanbanWebhookRoutes };
