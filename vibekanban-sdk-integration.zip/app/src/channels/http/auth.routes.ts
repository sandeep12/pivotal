import type { RouteDefinition } from "@util/api-server";
import type { Request } from "express";
import { UnauthorizedError } from "@util/error-normalizer";
import { createRequireRolesMiddleware } from "../../shared/auth/require-roles.middleware.js";
import { parseInput } from "../../shared/http/parse-input.util.js";

import { authService } from "../../auth/index.js";
import { getJwtSecret } from "../../shared/auth-config.js";
import {
  LoginInputSchema,
  RefreshInputSchema,
  LogoutInputSchema,
  RegisterInputSchema,
} from "../../auth/schemas/auth.schema.js";

type AuthRequest = Request & { auth?: { sub: string; role: string } };

const requireAuth = createRequireRolesMiddleware({
  requiredRoles: ["user", "admin", "manager"],
  secret: getJwtSecret(),
});

const authRoutes: RouteDefinition[] = [
  {
    path: "/auth/register",
    version: "v1",
    method: "POST",
    handler: async (input, { logger }) => {
      const { name, email, password } = parseInput(RegisterInputSchema, input);
      logger.info("Register attempt", { email });
      const result = await authService.register(name, email, password);
      return {
        user: {
          id: result.user.id,
          name: result.user.name,
          email: result.user.email,
          role: result.user.role,
        },
        accessToken: result.accessToken,
        refreshToken: result.refreshToken,
        expiresIn: 900,
      };
    },
  },
  {
    path: "/auth/login",
    version: "v1",
    method: "POST",
    handler: async (input, { logger }) => {
      const { email, password } = parseInput(LoginInputSchema, input);
      logger.info("Login attempt", { email });
      const pair = await authService.login(email, password);
      return {
        accessToken: pair.accessToken,
        refreshToken: pair.refreshToken,
        expiresIn: 900,
      };
    },
  },
  {
    path: "/auth/refresh",
    version: "v1",
    method: "POST",
    handler: async (input, { logger }) => {
      const { refreshToken } = parseInput(RefreshInputSchema, input);
      logger.info("Refresh attempt");
      const pair = await authService.refresh(refreshToken);
      return {
        accessToken: pair.accessToken,
        refreshToken: pair.refreshToken,
        expiresIn: 900,
      };
    },
  },
  {
    path: "/auth/logout",
    version: "v1",
    method: "POST",
    handler: async (input, { logger }) => {
      const { refreshToken } = parseInput(LogoutInputSchema, input);
      logger.info("Logout");
      await authService.logout(refreshToken);
      return { success: true };
    },
  },
  {
    path: "/auth/logout-all",
    version: "v1",
    method: "POST",
    middleware: [requireAuth],
    handler: async (_input, { logger, req }) => {
      const authReq = req as AuthRequest;
      const sub = authReq.auth?.sub;
      if (!sub) {
        throw new UnauthorizedError("Not authenticated");
      }
      logger.info("Logout all", { sub });
      const count = await authService.logoutAll(sub);
      return { revokedCount: count };
    },
  },
  {
    path: "/auth/me",
    version: "v1",
    method: "GET",
    middleware: [requireAuth],
    handler: async (_input, { req }) => {
      const authReq = req as AuthRequest;
      const auth = authReq.auth;
      if (!auth) {
        throw new UnauthorizedError("Not authenticated");
      }
      return { sub: auth.sub, role: auth.role };
    },
  },
];

export { authRoutes };
