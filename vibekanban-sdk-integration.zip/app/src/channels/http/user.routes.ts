import type { RouteDefinition } from "@util/api-server";
import { z } from "zod";
import { createRequireRolesMiddleware } from "../../shared/auth/require-roles.middleware.js";
import { getJwtSecret } from "../../shared/auth-config.js";
import { parseInput } from "../../shared/http/parse-input.util.js";

import { userService } from "../../user/index.js";

const requireAuth = createRequireRolesMiddleware({
  requiredRoles: ["user", "admin", "manager"],
  secret: getJwtSecret(),
});

const GetUserInput = z.object({ id: z.string().min(1) });
const userRoutes: RouteDefinition[] = [
  // this route is used to get a user by id
  {
    path: "/users/get",
    version: "v1",
    method: "GET",
    middleware: [requireAuth],
    handler: async (input, { logger }) => {
      const { id } = parseInput(GetUserInput, input);
      logger.info("Fetching user", { id });
      const user = await userService.getById(id);
      return user;
    },
  },
];

export { userRoutes };
