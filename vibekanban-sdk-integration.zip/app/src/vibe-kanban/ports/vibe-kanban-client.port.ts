import type {
  CreateIssueRequest,
  CreateProjectRequest,
  Issue,
  LocalRepo,
  LocalWorkspaceRepoInput,
  OrganizationWithRole,
  Project,
  ProjectStatus,
} from "@util/vk-remote-sdk";

type VibeKanbanCreatedTicketSummary = {
  id: string;
  simpleId: string;
  issueNumber: number;
  title: string;
};

type VibeKanbanCreateProjectResult =
  | { ok: true; project: Project }
  | { ok: false; error: string };

type VibeKanbanGetProjectStatusesResult =
  | { ok: true; statuses: ProjectStatus[] }
  | { ok: false; error: string };

type VibeKanbanTaskBatchInput = {
  project_id: string;
  status_id: string;
  tasks: Array<
    Omit<
      CreateIssueRequest,
      "project_id" | "status_id" | "sort_order" | "extension_metadata"
    > &
      Partial<Pick<CreateIssueRequest, "sort_order" | "extension_metadata">>
  >;
};

type VibeKanbanCreateTasksResult =
  | { ok: true; tasks: Issue[] }
  | { ok: false; error: string };

type VibeKanbanCreateTicketInput = Omit<CreateIssueRequest, "id">;

type VibeKanbanCreateTicketResult =
  | { ok: true; ticket: VibeKanbanCreatedTicketSummary }
  | { ok: false; error: string };

type VibeKanbanGetProjectRepoDefaultsResult =
  | { ok: true; repos: LocalWorkspaceRepoInput[] | null }
  | { ok: false; error: string };

type VibeKanbanSaveProjectRepoDefaultsResult =
  | { ok: true }
  | { ok: false; error: string };

type VibeKanbanListReposResult =
  | { ok: true; repos: LocalRepo[] }
  | { ok: false; error: string };

type VibeKanbanRegisterRepoResult =
  | { ok: true; repo: LocalRepo }
  | { ok: false; error: string };

/** Minimal projection used by status-sync consumers. */
type VibeKanbanIssueSummary = {
  id: string;
  status_id: string;
  updated_at: string;
};

type VibeKanbanListIssuesResult =
  | { ok: true; issues: VibeKanbanIssueSummary[] }
  | { ok: false; error: string };

type VibeKanbanClientPort = {
  listOrganizations(): Promise<OrganizationWithRole[]>;
  createProject(
    input: CreateProjectRequest
  ): Promise<VibeKanbanCreateProjectResult>;
  getProjectStatuses(
    projectId: string
  ): Promise<VibeKanbanGetProjectStatusesResult>;
  createTasks(
    input: VibeKanbanTaskBatchInput
  ): Promise<VibeKanbanCreateTasksResult>;
  createKanbanTicket(
    input: VibeKanbanCreateTicketInput
  ): Promise<VibeKanbanCreateTicketResult>;
  getProjectRepoDefaults(
    projectId: string
  ): Promise<VibeKanbanGetProjectRepoDefaultsResult>;
  saveProjectRepoDefaults(
    projectId: string,
    repos: LocalWorkspaceRepoInput[]
  ): Promise<VibeKanbanSaveProjectRepoDefaultsResult>;
  listRepos(): Promise<VibeKanbanListReposResult>;
  registerRepo(
    path: string,
    displayName?: string
  ): Promise<VibeKanbanRegisterRepoResult>;
  listProjectIssues(projectId: string): Promise<VibeKanbanListIssuesResult>;
};

export type {
  VibeKanbanClientPort,
  VibeKanbanCreateProjectResult,
  VibeKanbanGetProjectStatusesResult,
  VibeKanbanTaskBatchInput,
  VibeKanbanCreateTasksResult,
  VibeKanbanCreateTicketInput,
  VibeKanbanCreatedTicketSummary,
  VibeKanbanCreateTicketResult,
  VibeKanbanGetProjectRepoDefaultsResult,
  VibeKanbanSaveProjectRepoDefaultsResult,
  VibeKanbanListReposResult,
  VibeKanbanRegisterRepoResult,
  VibeKanbanIssueSummary,
  VibeKanbanListIssuesResult,
};
