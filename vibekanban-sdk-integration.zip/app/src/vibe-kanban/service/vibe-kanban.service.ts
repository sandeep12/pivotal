import type { ILogger } from "@util/logger";
import type {
  CreateProjectRequest,
  LocalWorkspaceRepoInput,
} from "@util/vk-remote-sdk";
import {
  LocalAgentClient,
  VkApiError,
  getProjectRepoDefaults,
  saveProjectRepoDefaults,
} from "@util/vk-remote-sdk";
import type { IssueStatusChangedPayload } from "../entities/issue-status-payload.js";
import type {
  VibeKanbanClientPort,
  VibeKanbanCreateTicketInput,
  VibeKanbanCreateProjectResult,
  VibeKanbanCreateTicketResult,
  VibeKanbanCreateTasksResult,
  VibeKanbanGetProjectRepoDefaultsResult,
  VibeKanbanGetProjectStatusesResult,
  VibeKanbanListIssuesResult,
  VibeKanbanListReposResult,
  VibeKanbanRegisterRepoResult,
  VibeKanbanSaveProjectRepoDefaultsResult,
  VibeKanbanTaskBatchInput,
} from "../ports/vibe-kanban-client.port.js";

class VibeKanbanService {
  constructor(
    private readonly outbound: VibeKanbanClientPort,
    private readonly localAgent: LocalAgentClient | null,
    private readonly logger: ILogger
  ) {}

  listOrganizations() {
    return this.outbound.listOrganizations();
  }

  async createProject(
    input: CreateProjectRequest
  ): Promise<VibeKanbanCreateProjectResult> {
    const orgs = await this.outbound.listOrganizations();
    const hasOrganization = orgs.some(
      (org) => org.id === input.organization_id
    );
    if (!hasOrganization) {
      return { ok: false, error: "Organization not found for current token" };
    }
    return this.outbound.createProject(input);
  }

  getProjectStatuses(
    projectId: string
  ): Promise<VibeKanbanGetProjectStatusesResult> {
    return this.outbound.getProjectStatuses(projectId);
  }

  createTasks(
    input: VibeKanbanTaskBatchInput
  ): Promise<VibeKanbanCreateTasksResult> {
    if (!input.tasks.length) {
      return Promise.resolve({
        ok: false,
        error: "At least one task is required",
      });
    }
    return this.outbound.createTasks(input);
  }

  createKanbanTicket(
    input: VibeKanbanCreateTicketInput
  ): Promise<VibeKanbanCreateTicketResult> {
    return this.outbound.createKanbanTicket(input);
  }

  getProjectRepoDefaults(
    projectId: string
  ): Promise<VibeKanbanGetProjectRepoDefaultsResult> {
    if (!this.localAgent) {
      return Promise.resolve({
        ok: false,
        error:
          "Project repo defaults require VK_LOCAL_API_BASE (local agent /api).",
      });
    }
    return getProjectRepoDefaults(this.localAgent.scratch, projectId)
      .then(
        (repos): VibeKanbanGetProjectRepoDefaultsResult => ({ ok: true, repos })
      )
      .catch((err: unknown) => ({
        ok: false,
        error:
          err instanceof VkApiError || err instanceof Error
            ? err.message
            : String(err),
      }));
  }

  saveProjectRepoDefaults(
    projectId: string,
    repos: LocalWorkspaceRepoInput[]
  ): Promise<VibeKanbanSaveProjectRepoDefaultsResult> {
    if (!this.localAgent) {
      return Promise.resolve({
        ok: false,
        error:
          "Project repo defaults require VK_LOCAL_API_BASE (local agent /api).",
      });
    }
    return saveProjectRepoDefaults(this.localAgent.scratch, projectId, repos)
      .then(
        (): VibeKanbanSaveProjectRepoDefaultsResult => ({
          ok: true,
        })
      )
      .catch((err: unknown) => ({
        ok: false,
        error:
          err instanceof VkApiError || err instanceof Error
            ? err.message
            : String(err),
      }));
  }

  listRepos(): Promise<VibeKanbanListReposResult> {
    return this.outbound.listRepos();
  }

  registerRepo(
    path: string,
    displayName?: string
  ): Promise<VibeKanbanRegisterRepoResult> {
    return this.outbound.registerRepo(path, displayName);
  }

  async listProjectIssues(
    projectId: string
  ): Promise<VibeKanbanListIssuesResult> {
    return this.outbound.listProjectIssues(projectId);
  }

  async handleIssueStatusChanged(
    payload: IssueStatusChangedPayload
  ): Promise<void> {
    this.logger.info("Vibe Kanban issue.status_changed", {
      organizationId: payload.organizationId,
      issueSimpleId: payload.issue.simpleId,
      newStatusName: payload.newStatusName,
    });
  }
}

export { VibeKanbanService };
