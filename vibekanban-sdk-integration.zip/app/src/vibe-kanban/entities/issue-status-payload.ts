/** Nexus-side shape for `issue.status_changed` workflow callbacks (no SDK import). */
type IssueStatusChangedPayload = {
  schemaVersion: number;
  event: "issue.status_changed";
  occurredAt: string;
  organizationId: string;
  actorUserId: string;
  issue: {
    id: string;
    projectId: string;
    simpleId: string;
    title: string;
  };
  previousStatusId: string;
  previousStatusName: string | null;
  newStatusId: string;
  newStatusName: string | null;
};

export type { IssueStatusChangedPayload };
