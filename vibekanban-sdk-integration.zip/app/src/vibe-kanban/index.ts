import type { ILogger } from "@util/logger";
import {
  LocalAgentClient,
  normalizeLocalAgentBaseUrl,
} from "@util/vk-remote-sdk";

import { loadVibeKanbanConfigFromEnv } from "./config.js";
import { createVibeKanbanClient } from "./infrastructure/vk-remote.client.js";
import type { VibeKanbanClientPort } from "./ports/vibe-kanban-client.port.js";
import { VibeKanbanService } from "./service/vibe-kanban.service.js";

type VibeKanbanModule = {
  service: VibeKanbanService;
  outbound: VibeKanbanClientPort;
  client: VibeKanbanClientPort;
  remoteConfigured: boolean;
  webhooksConfigured: boolean;
};

async function createVibeKanbanModule(
  logger: ILogger,
  env: ReturnType<
    typeof loadVibeKanbanConfigFromEnv
  > = loadVibeKanbanConfigFromEnv()
): Promise<VibeKanbanModule> {
  const localAgentBase = env.agentBaseUrl
    ? normalizeLocalAgentBaseUrl(env.agentBaseUrl)
    : null;
  const localAgent = localAgentBase
    ? new LocalAgentClient({ baseUrl: localAgentBase })
    : null;
  const client = await createVibeKanbanClient({
    remoteBaseUrl: env.remoteBaseUrl,
    localApiBase: env.localApiBase,
    agentBaseUrl: env.agentBaseUrl,
    remoteAccessToken: env.remoteAccessToken,
    remoteEmail: env.remoteEmail,
    remotePassword: env.remotePassword,
    remoteTransport: env.remoteTransport,
    logger,
  });
  const service = new VibeKanbanService(client, localAgent, logger);
  const remoteConfigured = Boolean(env.remoteBaseUrl?.trim());
  const webhooksConfigured = Boolean(env.webhookSecret?.trim());
  return {
    service,
    outbound: client,
    client,
    remoteConfigured,
    webhooksConfigured,
  };
}

export {
  createVibeKanbanModule,
  loadVibeKanbanConfigFromEnv,
  createVibeKanbanClient,
};
export type { VibeKanbanModule };
export type {
  VibeKanbanClientPort,
  VibeKanbanCreateProjectResult,
  VibeKanbanCreateTasksResult,
  VibeKanbanCreateTicketResult,
  VibeKanbanGetProjectStatusesResult,
  VibeKanbanListReposResult,
  VibeKanbanRegisterRepoResult,
  VibeKanbanTaskBatchInput,
} from "./ports/vibe-kanban-client.port.js";
export type { IssueStatusChangedPayload } from "./entities/issue-status-payload.js";
export { VibeKanbanService };
