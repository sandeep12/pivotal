import type { RemoteTransport } from "@util/vk-remote-sdk";

type VibeKanbanEnvConfig = {
  remoteBaseUrl: string | undefined;
  localApiBase: string | undefined;
  /** VK desktop app local agent base URL. Prefers VK_AGENT_URL, falls back to VK_LOCAL_API_BASE. */
  agentBaseUrl: string | undefined;
  remoteAccessToken: string | undefined;
  remoteEmail: string | undefined;
  remotePassword: string | undefined;
  remoteTransport: RemoteTransport;
  webhookSecret: string | undefined;
};

function parseRemoteTransport(raw: string | undefined): RemoteTransport {
  return raw === "localDesktop" || raw === "local" ? "localDesktop" : "remote";
}

/** Reads `VK_*` env (no I/O). Call from bootstrap only. */
function loadVibeKanbanConfigFromEnv(): VibeKanbanEnvConfig {
  const localApiBase = process.env.VK_LOCAL_API_BASE?.trim() || undefined;
  return {
    remoteBaseUrl: process.env.VK_REMOTE_BASE_URL?.trim() || undefined,
    localApiBase,
    agentBaseUrl: process.env.VK_AGENT_URL?.trim() || localApiBase,
    remoteAccessToken: process.env.VK_REMOTE_ACCESS_TOKEN?.trim() || undefined,
    remoteEmail: process.env.VK_REMOTE_EMAIL?.trim() || undefined,
    remotePassword: process.env.VK_REMOTE_PASSWORD?.trim() || undefined,
    remoteTransport: parseRemoteTransport(
      process.env.VK_REMOTE_TRANSPORT ?? process.env.VK_SDK_TRANSPORT
    ),
    webhookSecret: process.env.VK_WEBHOOK_SECRET?.trim() || undefined,
  };
}

export { loadVibeKanbanConfigFromEnv };
export type { VibeKanbanEnvConfig };
