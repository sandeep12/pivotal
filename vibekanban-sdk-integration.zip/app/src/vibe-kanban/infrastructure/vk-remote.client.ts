import type { ILogger } from "@util/logger";
import type {
  CreateVkRemoteClientOptions,
  CreateProjectRequest,
  LocalWorkspaceRepoInput,
  RemoteTransport,
} from "@util/vk-remote-sdk";
import {
  LocalAgentClient,
  VkApiError,
  VkRemoteClient,
  createVkRemoteClient,
  getProjectRepoDefaults,
  normalizeLocalAgentBaseUrl,
  saveProjectRepoDefaults,
} from "@util/vk-remote-sdk";
import type { LocalRepo } from "@util/vk-remote-sdk";
import type {
  VibeKanbanClientPort,
  VibeKanbanCreateProjectResult,
  VibeKanbanGetProjectRepoDefaultsResult,
  VibeKanbanCreateTasksResult,
  VibeKanbanCreateTicketInput,
  VibeKanbanCreateTicketResult,
  VibeKanbanGetProjectStatusesResult,
  VibeKanbanListIssuesResult,
  VibeKanbanListReposResult,
  VibeKanbanRegisterRepoResult,
  VibeKanbanSaveProjectRepoDefaultsResult,
  VibeKanbanTaskBatchInput,
} from "../ports/vibe-kanban-client.port.js";

type VibeKanbanClientConfig = {
  remoteBaseUrl: string | undefined;
  localApiBase: string | undefined;
  /** VK desktop app local agent base URL (VK_AGENT_URL preferred over localApiBase). */
  agentBaseUrl: string | undefined;
  remoteAccessToken: string | undefined;
  remoteEmail: string | undefined;
  remotePassword: string | undefined;
  remoteTransport: RemoteTransport;
  logger: ILogger;
};

function normalizeAccessToken(raw: string | undefined): string | undefined {
  const token = raw?.trim();
  if (!token) return undefined;
  return token.replace(/^Bearer\s+/i, "").trim();
}

function normalizeRemoteBaseUrl(raw: string | undefined): string | undefined {
  const base = raw?.trim();
  if (!base) return undefined;
  return base.replace(/\/v1\/?$/, "");
}

function mapVkError(err: unknown): string {
  if (err instanceof VkApiError && err.status === 401) {
    return "VK remote API unauthorized (401). Check VK_REMOTE_ACCESS_TOKEN (raw JWT only, no 'Bearer ' prefix) and VK_REMOTE_BASE_URL (origin only, no /v1).";
  }
  if (err instanceof VkApiError) return err.message;
  return err instanceof Error ? err.message : String(err);
}

class VkRemoteVibeKanbanClient implements VibeKanbanClientPort {
  readonly #client: VkRemoteClient;
  readonly #localAgent: LocalAgentClient | null;
  readonly #localApiBase: string | null;

  constructor(config: {
    client: VkRemoteClient;
    localAgent: LocalAgentClient | null;
    localApiBase: string | null;
  }) {
    this.#client = config.client;
    this.#localAgent = config.localAgent;
    this.#localApiBase = config.localApiBase ?? null;
  }

  async listOrganizations() {
    const { organizations } = await this.#client.organizations.list();
    return organizations;
  }

  async createProject(
    input: CreateProjectRequest
  ): Promise<VibeKanbanCreateProjectResult> {
    try {
      const { data } = await this.#client.projects.create(input);
      return { ok: true, project: data };
    } catch (err: unknown) {
      return { ok: false, error: mapVkError(err) };
    }
  }

  async getProjectStatuses(
    projectId: string
  ): Promise<VibeKanbanGetProjectStatusesResult> {
    try {
      const { project_statuses } = await this.#client.projectStatuses.list({
        project_id: projectId,
      });
      return { ok: true, statuses: project_statuses };
    } catch (err: unknown) {
      return { ok: false, error: mapVkError(err) };
    }
  }

  async createTasks(
    input: VibeKanbanTaskBatchInput
  ): Promise<VibeKanbanCreateTasksResult> {
    const createdTasks: import("@util/vk-remote-sdk").Issue[] = [];
    for (let index = 0; index < input.tasks.length; index++) {
      const task = input.tasks[index]!;
      let lastErr: unknown;
      // Retry up to 3 times with backoff — the org-level issue_number trigger
      // uses row-level locking; under concurrent inserts some may hit a lock
      // timeout (→ VK 500). Sequential + retry avoids the contention.
      for (let attempt = 1; attempt <= 3; attempt++) {
        try {
          const { data } = await this.#client.issues.create({
            project_id: input.project_id,
            status_id: input.status_id,
            title: task.title,
            description: task.description ?? null,
            sort_order: task.sort_order ?? index,
            extension_metadata: task.extension_metadata ?? {},
          });
          createdTasks.push(data);
          lastErr = undefined;
          break;
        } catch (err: unknown) {
          lastErr = err;
          if (attempt < 3) {
            await new Promise((r) => setTimeout(r, attempt * 300));
          }
        }
      }
      if (lastErr !== undefined) {
        return { ok: false, error: mapVkError(lastErr) };
      }
    }
    return { ok: true, tasks: createdTasks };
  }

  async createKanbanTicket(
    input: VibeKanbanCreateTicketInput
  ): Promise<VibeKanbanCreateTicketResult> {
    try {
      const { data } = await this.#client.issues.create(input);
      return {
        ok: true,
        ticket: {
          id: data.id,
          simpleId: data.simple_id,
          issueNumber: data.issue_number,
          title: data.title,
        },
      };
    } catch (err: unknown) {
      return { ok: false, error: mapVkError(err) };
    }
  }

  async getProjectRepoDefaults(
    projectId: string
  ): Promise<VibeKanbanGetProjectRepoDefaultsResult> {
    if (!this.#localAgent) {
      return {
        ok: false,
        error:
          "Project repo defaults are only available with localDesktop transport.",
      };
    }
    try {
      const repos = await getProjectRepoDefaults(
        this.#localAgent.scratch,
        projectId
      );
      return { ok: true, repos };
    } catch (err: unknown) {
      return { ok: false, error: mapVkError(err) };
    }
  }

  async saveProjectRepoDefaults(
    projectId: string,
    repos: LocalWorkspaceRepoInput[]
  ): Promise<VibeKanbanSaveProjectRepoDefaultsResult> {
    if (!this.#localAgent) {
      return {
        ok: false,
        error:
          "Project repo defaults are only available with localDesktop transport.",
      };
    }
    try {
      await saveProjectRepoDefaults(this.#localAgent.scratch, projectId, repos);
      return { ok: true };
    } catch (err: unknown) {
      return { ok: false, error: mapVkError(err) };
    }
  }

  async listRepos(): Promise<VibeKanbanListReposResult> {
    if (!this.#localAgent) {
      return {
        ok: false,
        error: "listRepos requires localDesktop transport (VK_LOCAL_API_BASE).",
      };
    }
    try {
      const repos = await this.#localAgent.repos.list();
      return { ok: true, repos };
    } catch (err: unknown) {
      return { ok: false, error: mapVkError(err) };
    }
  }

  async registerRepo(
    path: string,
    displayName?: string
  ): Promise<VibeKanbanRegisterRepoResult> {
    if (!this.#localApiBase) {
      return {
        ok: false,
        error:
          "registerRepo requires localDesktop transport (VK_LOCAL_API_BASE).",
      };
    }
    try {
      const body: Record<string, string> = { path };
      if (displayName) body["display_name"] = displayName;
      const res = await fetch(`${this.#localApiBase}/api/repos`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const text = await res.text();
      if (!res.ok) {
        return {
          ok: false,
          error: `VK register repo failed (${res.status}): ${text}`,
        };
      }
      const json = JSON.parse(text) as { data?: LocalRepo; repo?: LocalRepo };
      const repo = json.data ?? json.repo;
      if (!repo) {
        return {
          ok: false,
          error: `VK register repo: unexpected response shape: ${text}`,
        };
      }
      return { ok: true, repo };
    } catch (err: unknown) {
      return { ok: false, error: mapVkError(err) };
    }
  }

  async listProjectIssues(
    projectId: string
  ): Promise<VibeKanbanListIssuesResult> {
    try {
      const { issues } = await this.#client.issues.list({
        project_id: projectId,
      });
      return {
        ok: true,
        issues: issues.map((i) => ({
          id: i.id,
          status_id: i.status_id,
          updated_at: i.updated_at,
        })),
      };
    } catch (err: unknown) {
      return { ok: false, error: mapVkError(err) };
    }
  }
}

class DisabledVibeKanbanClient implements VibeKanbanClientPort {
  private unavailableError(): string {
    return "Vibe Kanban client is not configured (set VK_SDK_TRANSPORT and matching VK_LOCAL_API_BASE or VK_REMOTE_BASE_URL/token).";
  }

  async listOrganizations() {
    return [];
  }
  async createProject(): Promise<VibeKanbanCreateProjectResult> {
    return {
      ok: false,
      error: this.unavailableError(),
    };
  }
  async getProjectStatuses(): Promise<VibeKanbanGetProjectStatusesResult> {
    return {
      ok: false,
      error: this.unavailableError(),
    };
  }
  async createTasks(): Promise<VibeKanbanCreateTasksResult> {
    return {
      ok: false,
      error: this.unavailableError(),
    };
  }
  async createKanbanTicket(
    _input: VibeKanbanCreateTicketInput
  ): Promise<VibeKanbanCreateTicketResult> {
    return {
      ok: false,
      error: this.unavailableError(),
    };
  }
  async getProjectRepoDefaults(): Promise<VibeKanbanGetProjectRepoDefaultsResult> {
    return {
      ok: false,
      error: this.unavailableError(),
    };
  }
  async saveProjectRepoDefaults(): Promise<VibeKanbanSaveProjectRepoDefaultsResult> {
    return {
      ok: false,
      error: this.unavailableError(),
    };
  }

  async listRepos(): Promise<VibeKanbanListReposResult> {
    return {
      ok: false,
      error: this.unavailableError(),
    };
  }

  async registerRepo(): Promise<VibeKanbanRegisterRepoResult> {
    return {
      ok: false,
      error: this.unavailableError(),
    };
  }

  async listProjectIssues(): Promise<VibeKanbanListIssuesResult> {
    return {
      ok: false,
      error: this.unavailableError(),
    };
  }
}

async function createVibeKanbanClient(
  config: VibeKanbanClientConfig
): Promise<VibeKanbanClientPort> {
  const base = normalizeRemoteBaseUrl(config.remoteBaseUrl);
  const localApiBase = config.localApiBase
    ? normalizeLocalAgentBaseUrl(config.localApiBase)
    : undefined;
  // Prefer VK_AGENT_URL (agentBaseUrl) over localApiBase for local agent operations.
  const agentBase = config.agentBaseUrl
    ? normalizeLocalAgentBaseUrl(config.agentBaseUrl)
    : localApiBase;
  if (config.remoteTransport === "remote" && !base) {
    return new DisabledVibeKanbanClient();
  }
  if (config.remoteTransport === "localDesktop" && !agentBase) {
    return new DisabledVibeKanbanClient();
  }

  const sdkClientOptions: CreateVkRemoteClientOptions = {
    config: {
      transport: config.remoteTransport,
      localApiBase: agentBase,
      remoteBaseUrl: base,
      remoteAccessToken: normalizeAccessToken(config.remoteAccessToken),
      remoteEmail: config.remoteEmail,
      remotePassword: config.remotePassword,
    },
    onStep: (label, detail) => {
      config.logger.info("Vibe Kanban SDK bootstrap", { label, detail });
    },
  };
  const sdkClient = await createVkRemoteClient({
    ...sdkClientOptions,
  });

  const localAgent = agentBase
    ? new LocalAgentClient({
        baseUrl: agentBase,
      })
    : null;

  return new VkRemoteVibeKanbanClient({
    client: sdkClient,
    localAgent,
    localApiBase: agentBase ?? null,
  });
}

export { createVibeKanbanClient };
