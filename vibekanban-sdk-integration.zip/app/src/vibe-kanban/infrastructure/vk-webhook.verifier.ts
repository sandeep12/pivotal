import { parseVerifiedWebhook } from "@util/vk-remote-sdk";
import type { IssueStatusChangedEvent } from "@util/vk-remote-sdk";

import type { IssueStatusChangedPayload } from "../entities/issue-status-payload.js";

function assertIssueStatusEvent(
  ev: IssueStatusChangedEvent
): asserts ev is IssueStatusChangedEvent & { event: "issue.status_changed" } {
  if (ev.event !== "issue.status_changed") {
    throw new Error(`Unsupported webhook event: ${String(ev.event)}`);
  }
}

function toPayload(ev: IssueStatusChangedEvent): IssueStatusChangedPayload {
  assertIssueStatusEvent(ev);
  return {
    schemaVersion: ev.schema_version,
    event: "issue.status_changed",
    occurredAt: ev.occurred_at,
    organizationId: ev.organization_id,
    actorUserId: ev.actor_user_id,
    issue: {
      id: ev.issue.id,
      projectId: ev.issue.project_id,
      simpleId: ev.issue.simple_id,
      title: ev.issue.title,
    },
    previousStatusId: ev.previous_status_id,
    previousStatusName: ev.previous_status_name,
    newStatusId: ev.new_status_id,
    newStatusName: ev.new_status_name,
  };
}

/**
 * Verifies `X-VK-Signature` and maps the remote payload to {@link IssueStatusChangedPayload}.
 */
function verifyIssueStatusWebhook(
  rawBody: Buffer,
  signatureHeader: string | undefined,
  secret: string
): IssueStatusChangedPayload {
  const ev = parseVerifiedWebhook(rawBody, signatureHeader, secret);
  return toPayload(ev);
}

export { verifyIssueStatusWebhook };
