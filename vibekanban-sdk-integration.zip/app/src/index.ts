import "dotenv/config";

import { ApiServer, type ServerConfig } from "@util/api-server";

import express from "express";
import type { Request, Response } from "express";

import { createVibeKanbanRoutes } from "./channels/http/vibe-kanban.routes.js";
import { createVibeKanbanWebhookRoutes } from "./channels/http/vibe-kanban-webhook.routes.js";
import { logger, initLogger } from "./shared/logger/logger.js";
import { secrets, initSecrets } from "./shared/secrets/secret.js";
import { userRoutes } from "./channels/http/user.routes.js";
import { authRoutes } from "./channels/http/auth.routes.js";
import { mountUserSseRoutes } from "./channels/http/user-events.sse.js";
import { createAgVidurService } from "./ag-vidur/index.js";
import { vidurBridgeWebSocket } from "./channels/ws/vidur-bridge-ws.js";
import { connectDb, getDb } from "./infrastructure/database.js";
import { connectRedis, getRedis } from "./infrastructure/redis.js";
import {
  createVibeKanbanModule,
  loadVibeKanbanConfigFromEnv,
} from "./vibe-kanban/index.js";

await initLogger();
await initSecrets();

const PORT = Number(process.env.PORT ?? "3001");
const vidurWsPath = process.env.VIDUR_WS_PATH ?? "/api/v1/ws/vidur";
const vidurWsEnabled = process.env.VIDUR_WS_ENABLED !== "0";

let vidurVoiceWsClose: (() => Promise<void>) | null = null;

const vkEnv = loadVibeKanbanConfigFromEnv();
const vibeKanban = await createVibeKanbanModule(logger, vkEnv);
const agVidurService = createAgVidurService(vibeKanban.outbound);

const captureJsonRawBody: NonNullable<ServerConfig["onJsonBodyVerify"]> = (
  req: Request,
  _res: Response,
  buf: Buffer
) => {
  (req as Request & { rawBody?: Buffer }).rawBody = buf;
};

const vkWebhookRoutes =
  vibeKanban.webhooksConfigured && vkEnv.webhookSecret
    ? createVibeKanbanWebhookRoutes({
        vibeKanbanService: vibeKanban.service,
        webhookSecret: vkEnv.webhookSecret,
      })
    : [];
const vkRoutes = createVibeKanbanRoutes({
  vibeKanbanService: vibeKanban.service,
});

const server = ApiServer.create({
  config: {
    PORT,
    SWAGGER_ENABLED: true,
    SWAGGER_TITLE: "Nexus API",
    SWAGGER_DESCRIPTION: "Nexus application API",
    ...(vkWebhookRoutes.length > 0
      ? { onJsonBodyVerify: captureJsonRawBody }
      : {}),
  },
  logger,
  onHttpServerCreated: (httpServer) => {
    if (!vidurWsEnabled) return;
    vidurVoiceWsClose = vidurBridgeWebSocket({
      httpServer,
      path: vidurWsPath,
      logger,
      agVidurService,
    }).close;
  },
  onAppStart: async () => {
    await connectDb();
    await connectRedis();
    logger.info("App bootstrap complete");
  },
  onAppStop: async () => {
    if (vidurVoiceWsClose) {
      try {
        await vidurVoiceWsClose();
      } catch (err) {
        logger.warn("Vidur voice WebSocket close failed", {
          error: String(err),
        });
      }
      vidurVoiceWsClose = null;
    }
    try {
      await getDb().close();
    } catch (err) {
      logger.warn("Database close skipped or failed", { error: String(err) });
    }
    try {
      await getRedis().close();
    } catch (err) {
      logger.warn("Redis close skipped or failed", { error: String(err) });
    }
    await secrets.close();
    logger.info("App shutting down");
  },
  routes: [...userRoutes, ...authRoutes, ...vkRoutes, ...vkWebhookRoutes],
});
logger.info("Server created");
if (vibeKanban.remoteConfigured) {
  logger.info("Vibe Kanban remote client configured", {
    transport: vkEnv.remoteTransport,
  });
}
if (vkWebhookRoutes.length > 0) {
  logger.info("Vibe Kanban webhook route mounted", {
    path: "/api/v1/vibe-kanban/webhooks/issue-status",
  });
}
if (vkRoutes.length > 0) {
  logger.info("Vibe Kanban API routes mounted", {
    paths: [
      "/api/v1/vibe-kanban/organizations",
      "/api/v1/vibe-kanban/projects",
      "/api/v1/vibe-kanban/project-statuses",
      "/api/v1/vibe-kanban/project-repo-defaults",
      "/api/v1/vibe-kanban/tasks/batch",
    ],
  });
}

const router = express.Router();
server.expressApp.use("/api", router);
mountUserSseRoutes(router);

await server.start();

if (vidurWsEnabled && vidurVoiceWsClose) {
  logger.info("Vidur voice WebSocket ready on same port as API", {
    path: vidurWsPath,
    port: server.port,
  });
}
