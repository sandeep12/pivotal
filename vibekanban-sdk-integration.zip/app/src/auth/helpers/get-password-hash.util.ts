import type { AuthMethod, User } from "../../user/entities/user.entity.js";

/** Returns the user's local password hash from auth methods. */
const getPasswordHash = (user: User): string | undefined => {
  const local = user.authMethods?.find((m: AuthMethod) => m.type === "local");
  return local?.passwordHash;
};

export { getPasswordHash };
