/** Builds Redis key for refresh token allowlist entry. */
const buildAllowlistKey = (sub: string, jti: string): string =>
  `user:${sub}:refresh:${jti}`;

/** Builds Redis key prefix to match all session keys for a given user (used for logoutAll). */
const buildUserKeyPrefix = (sub: string): string => `user:${sub}:`;

/** Builds Redis key for revoked token blacklist entry. */
const buildRevokedKey = (jti: string): string => `revoked:${jti}`;

export { buildAllowlistKey, buildUserKeyPrefix, buildRevokedKey };
