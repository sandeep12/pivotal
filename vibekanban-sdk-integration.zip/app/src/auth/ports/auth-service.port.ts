import type { User } from "../../user/entities/user.entity.js";
import type { TokenPair } from "../entities/index.js";

type AuthServicePort = {
  login: (email: string, password: string) => Promise<TokenPair>;
  refresh: (refreshToken: string) => Promise<TokenPair>;
  logout: (refreshToken: string) => Promise<void>;
  logoutAll: (sub: string) => Promise<number>;
  register: (
    name: string,
    email: string,
    password: string
  ) => Promise<{ user: User; accessToken: string; refreshToken: string }>;
};

export type { AuthServicePort, TokenPair };
