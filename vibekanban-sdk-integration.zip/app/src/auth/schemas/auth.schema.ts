import { z } from "zod";

const LoginInputSchema = z.object({
  email: z.string().min(1, "Email is required").email("Invalid email"),
  password: z.string().min(1, "Password is required"),
});

const RefreshInputSchema = z.object({
  refreshToken: z.string().min(1, "Refresh token is required"),
});

const LogoutInputSchema = z.object({
  refreshToken: z.string().min(1, "Refresh token is required"),
});

const RegisterInputSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().min(1, "Email is required").email("Invalid email"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

type LoginInput = z.infer<typeof LoginInputSchema>;
type RefreshInput = z.infer<typeof RefreshInputSchema>;
type LogoutInput = z.infer<typeof LogoutInputSchema>;
type RegisterInput = z.infer<typeof RegisterInputSchema>;

export {
  LoginInputSchema,
  RefreshInputSchema,
  LogoutInputSchema,
  RegisterInputSchema,
};
export type { LoginInput, RefreshInput, LogoutInput, RegisterInput };
