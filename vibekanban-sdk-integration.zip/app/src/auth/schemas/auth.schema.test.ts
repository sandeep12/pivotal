import {
  LoginInputSchema,
  RefreshInputSchema,
  LogoutInputSchema,
  RegisterInputSchema,
} from "./auth.schema.js";

describe("auth schemas", () => {
  describe("LoginInputSchema", () => {
    it("should accept valid email and password", () => {
      const result = LoginInputSchema.safeParse({
        email: "user@example.com",
        password: "secret123",
      });
      expect(result.success).toBe(true);
    });

    it("should reject invalid email", () => {
      const result = LoginInputSchema.safeParse({
        email: "not-an-email",
        password: "secret",
      });
      expect(result.success).toBe(false);
    });

    it("should reject empty password", () => {
      const result = LoginInputSchema.safeParse({
        email: "user@example.com",
        password: "",
      });
      expect(result.success).toBe(false);
    });
  });

  describe("RefreshInputSchema", () => {
    it("should accept valid refresh token", () => {
      const result = RefreshInputSchema.safeParse({
        refreshToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
      });
      expect(result.success).toBe(true);
    });

    it("should reject empty refresh token", () => {
      const result = RefreshInputSchema.safeParse({
        refreshToken: "",
      });
      expect(result.success).toBe(false);
    });
  });

  describe("RegisterInputSchema", () => {
    it("should accept valid name, email, and password", () => {
      const result = RegisterInputSchema.safeParse({
        name: "Test User",
        email: "user@example.com",
        password: "SecurePass123!",
      });
      expect(result.success).toBe(true);
    });

    it("should reject empty name", () => {
      const result = RegisterInputSchema.safeParse({
        name: "",
        email: "user@example.com",
        password: "password123",
      });
      expect(result.success).toBe(false);
    });

    it("should reject invalid email", () => {
      const result = RegisterInputSchema.safeParse({
        name: "Test",
        email: "not-an-email",
        password: "password123",
      });
      expect(result.success).toBe(false);
    });

    it("should reject password shorter than 8 characters", () => {
      const result = RegisterInputSchema.safeParse({
        name: "Test",
        email: "user@example.com",
        password: "short",
      });
      expect(result.success).toBe(false);
    });
  });

  describe("LogoutInputSchema", () => {
    it("should accept valid refresh token", () => {
      const result = LogoutInputSchema.safeParse({
        refreshToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
      });
      expect(result.success).toBe(true);
    });

    it("should reject empty refresh token", () => {
      const result = LogoutInputSchema.safeParse({
        refreshToken: "",
      });
      expect(result.success).toBe(false);
    });
  });
});
