import { randomUUID } from "node:crypto";

import { JwtTokens } from "@util/jwt-tokens";
import { RecordStore } from "@util/redis";
import { UnauthorizedError, ConflictError } from "@util/error-normalizer";

import type { AuthServicePort, TokenPair } from "../ports/auth-service.port.js";
import type { User } from "../../user/entities/user.entity.js";
import { userService } from "../../user/index.js";
import { getPasswordHash } from "../helpers/get-password-hash.util.js";
import {
  buildAllowlistKey,
  buildUserKeyPrefix,
  buildRevokedKey,
} from "../helpers/build-session-keys.util.js";
import {
  getJwtSecret,
  ACCESS_EXPIRES_IN,
  REFRESH_EXPIRES_IN,
  ACCESS_TTL_MS,
  REFRESH_TTL_MS,
} from "../../shared/auth-config.js";

/**
 * Issues an access/refresh token pair and stores the refresh token allowlist entry.
 */
const issueTokenPairForUser = async (user: User): Promise<TokenPair> => {
  const role = user.role ?? "user";
  const jti = randomUUID();
  const secret = getJwtSecret();

  const [accessToken, refreshToken] = await Promise.all([
    JwtTokens.signAccessToken({ sub: user.id, role }, secret, {
      expiresIn: ACCESS_EXPIRES_IN,
    }),
    JwtTokens.signRefreshToken({ sub: user.id, jti, role }, secret, {
      expiresIn: REFRESH_EXPIRES_IN,
    }),
  ]);

  await RecordStore.setRecord({
    key: buildAllowlistKey(user.id, jti),
    record: { value: { role, createdAt: Date.now() } },
    ttlMs: REFRESH_TTL_MS,
  });

  return { accessToken, refreshToken };
};

class AuthService implements AuthServicePort {
  /** Authenticates user and returns new access + refresh token pair. */
  login = async (email: string, password: string): Promise<TokenPair> => {
    const user = await userService.getByEmail(email);
    if (!user) {
      throw new UnauthorizedError("Invalid email or password");
    }

    const passwordHash = getPasswordHash(user);
    if (!passwordHash) {
      throw new UnauthorizedError("Invalid email or password");
    }

    const ok = await JwtTokens.verifyPassword(password, passwordHash);
    if (!ok) {
      throw new UnauthorizedError("Invalid email or password");
    }

    return issueTokenPairForUser(user);
  };

  /** Rotates refresh token into new pair; revokes old token. */
  refresh = async (refreshToken: string): Promise<TokenPair> => {
    const secret = getJwtSecret();
    const payload = await JwtTokens.verifyRefreshToken(refreshToken, secret);
    const allowlistKey = buildAllowlistKey(payload.sub, payload.jti);

    const raw = await RecordStore.consumeRecord(allowlistKey);
    if (raw === null) {
      throw new UnauthorizedError("Token revoked or expired");
    }

    const pair = await JwtTokens.rotateTokens(refreshToken, secret);
    const newJti = JwtTokens.extractTokenId(pair.refreshToken);
    if (!newJti) {
      throw new UnauthorizedError("Invalid token");
    }

    const newAllowlistKey = buildAllowlistKey(payload.sub, newJti);
    await RecordStore.setRecord({
      key: newAllowlistKey,
      record: {
        value: { role: payload.role ?? "user", createdAt: Date.now() },
      },
      ttlMs: REFRESH_TTL_MS,
    });

    const revokedKey = buildRevokedKey(payload.jti);
    await RecordStore.setRecord({
      key: revokedKey,
      record: { value: 1 },
      ttlMs: ACCESS_TTL_MS,
    });

    return pair;
  };

  /** Revokes the given refresh token. */
  logout = async (refreshToken: string): Promise<void> => {
    const jti = JwtTokens.extractTokenId(refreshToken);
    if (!jti) {
      return;
    }

    let payload: { sub: string; jti: string; role?: string };
    try {
      payload = await JwtTokens.verifyRefreshToken(
        refreshToken,
        getJwtSecret()
      );
    } catch {
      return;
    }

    const allowlistKey = buildAllowlistKey(payload.sub, jti);
    await RecordStore.revokeRecord(allowlistKey);
    await RecordStore.setRecord({
      key: buildRevokedKey(jti),
      record: { value: 1 },
      ttlMs: ACCESS_TTL_MS,
    });
  };

  /** Revokes all refresh tokens for the given user. */
  logoutAll = async (sub: string): Promise<number> => {
    const count = await RecordStore.revokeByPrefix({
      keyPrefix: buildUserKeyPrefix(sub),
    });
    return count;
  };

  /** Registers a new user with email and password. */
  register = async (
    name: string,
    email: string,
    password: string
  ): Promise<{ user: User; accessToken: string; refreshToken: string }> => {
    const strength = JwtTokens.validatePasswordStrength(password);
    if (!strength.valid) {
      const issues = strength.issues?.join(", ") ?? "Password too weak";
      throw new UnauthorizedError(issues);
    }

    const existing = await userService.getByEmail(email);
    if (existing) {
      throw new ConflictError("Email already registered");
    }

    const passwordHash = await JwtTokens.hashPassword(password);
    const user = await userService.create({
      name,
      email,
      role: "user",
      authMethods: [
        {
          type: "local",
          passwordHash,
          linkedAt: Date.now(),
        },
      ],
    });

    const pair = await issueTokenPairForUser(user);
    return {
      user,
      accessToken: pair.accessToken,
      refreshToken: pair.refreshToken,
    };
  };
}

export { AuthService };
