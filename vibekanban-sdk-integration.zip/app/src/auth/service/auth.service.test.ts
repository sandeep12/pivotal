import { AuthService } from "./auth.service.js";

describe("AuthService", () => {
  const service = new AuthService();

  describe("register", () => {
    it("should throw for weak password", async () => {
      await expect(
        service.register("Test", "test@example.com", "123")
      ).rejects.toThrow();
    });
  });

  describe("logout", () => {
    it("should not throw when given invalid or malformed refresh token", async () => {
      await expect(service.logout("invalid.jwt.token")).resolves.not.toThrow();
    });

    it("should not throw when given empty string", async () => {
      await expect(service.logout("")).resolves.not.toThrow();
    });
  });
});
