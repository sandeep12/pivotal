import { AuthService } from "./service/auth.service.js";

const authService = new AuthService();

export { authService };
export type {
  LoginInput,
  RefreshInput,
  LogoutInput,
  RegisterInput,
} from "./schemas/auth.schema.js";
