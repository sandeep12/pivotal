import { MongoDb } from "@util/mongodb";

import { logger } from "../shared/logger/logger.js";
import { secrets } from "../shared/secrets/secret.js";

const getDbUri = async (): Promise<string | undefined> => {
  const secretId = process.env.DB_SECRET_ID;
  if (secretId) {
    const secretsMap = await secrets.getSecrets([secretId]);
    return secretsMap[secretId];
  }
  return process.env.MONGODB_URI ?? process.env.MONGO_URI;
};

const connectDb = async (): Promise<void> => {
  const uri = await getDbUri();
  if (!uri) {
    logger.warn(
      "No MONGODB_URI, MONGO_URI, or DB_SECRET_ID configured — skipping database connection"
    );
    return;
  }
  const database = process.env.MONGODB_DATABASE ?? "app";
  const db = MongoDb.create({ uri, database, logger });
  await db.connect();
};

const getDb = (): MongoDb => {
  return MongoDb.getInstance();
};

export { connectDb, getDb };
