import type {
  SseEvent,
  SseEventHistoryStore,
  SseReplayStoreReadParams,
  SseReplayStoreWriteParams,
} from "@util/api-server";

import { getRedis } from "./redis.js";

const STREAM_KEY_PREFIX = "sse:stream";

const buildStreamKey = (
  context: SseReplayStoreWriteParams["context"]
): string => {
  const { tenantId, userId } = context.identity;
  const tenantPart = tenantId ?? "global";
  const userPart = userId ?? "anonymous";

  return `${STREAM_KEY_PREFIX}:tenant:${tenantPart}:user:${userPart}`;
};

const appendEvent = async (
  params: SseReplayStoreWriteParams
): Promise<void> => {
  const { event, context } = params;
  const redis = getRedis();
  const key = buildStreamKey(context);

  await redis.withOperation(async () => {
    const client = await redis.getClient();
    const fields: string[] = [];

    if (event.event) {
      fields.push("event", event.event);
    }

    fields.push("data", JSON.stringify(event.data ?? null));

    if (event.id) {
      fields.push("id", event.id);
    }

    await client.xAdd(key, "*", fields);
  });
};

const getEventsAfter = async (
  params: SseReplayStoreReadParams
): Promise<SseEvent[]> => {
  const { afterEventId, context } = params;
  if (!afterEventId) {
    return [];
  }

  const redis = getRedis();
  const key = buildStreamKey(context);

  return redis.withOperation(async () => {
    const client = await redis.getClient();
    const redisRangeStart = `(${afterEventId}`;
    const entries = await client.xRange(key, redisRangeStart, "+");

    const events: SseEvent[] = [];

    for (const [entryId, rawFields] of entries) {
      const tupleFields = rawFields as unknown as [string, string][];
      const fieldMap = new Map<string, string>(tupleFields);
      const name = fieldMap.get("event") ?? undefined;
      const dataJson = fieldMap.get("data") ?? "null";

      events.push({
        id: entryId,
        event: name,
        data: JSON.parse(dataJson),
      });
    }

    return events;
  });
};

const sseRedisHistoryStore: SseEventHistoryStore = {
  appendEvent,
  getEventsAfter,
};

export { sseRedisHistoryStore };
