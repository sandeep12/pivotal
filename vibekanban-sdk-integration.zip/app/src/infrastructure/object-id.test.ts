import { ObjectId } from "mongodb";
import { ValidationError } from "@util/error-normalizer";
import { toObjectId } from "./object-id.js";

describe("toObjectId", () => {
  it("should return an ObjectId for a valid 24-char hex string", () => {
    const hex = new ObjectId().toHexString();
    const result = toObjectId(hex);
    expect(result).toBeInstanceOf(ObjectId);
    expect(result.toHexString()).toBe(hex);
  });

  it("should throw ValidationError for an empty string", () => {
    expect(() => toObjectId("")).toThrow(ValidationError);
  });

  it("should throw ValidationError for a random non-hex string", () => {
    expect(() => toObjectId("not-a-valid-id")).toThrow(ValidationError);
  });

  it("should include the label in the error details", () => {
    let error: ValidationError | null = null;
    try {
      toObjectId("bad", "userId");
    } catch (err) {
      error = err as ValidationError;
    }
    expect(error).toBeInstanceOf(ValidationError);
    expect(error!.details).toEqual({ userId: "bad" });
  });
});
