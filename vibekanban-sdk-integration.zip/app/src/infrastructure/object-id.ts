import { ObjectId } from "mongodb";
import { ValidationError } from "@util/error-normalizer";

const toObjectId = (id: string, label = "id"): ObjectId => {
  if (!ObjectId.isValid(id)) {
    throw new ValidationError(`Invalid ${label}`, { [label]: id });
  }
  return new ObjectId(id);
};

export { toObjectId };
