import { Redis, type IRedis } from "@util/redis";

import { logger } from "../shared/logger/logger.js";

const REDIS_URL = process.env.REDIS_URL ?? "redis://localhost:6379";

const connectRedis = async (): Promise<void> => {
  Redis.create({
    url: REDIS_URL,
    keyPrefix: "nexus:",
    recordNamespace: "session",
  });
  const redis = Redis.getInstance();
  try {
    await redis.connect();
    logger.info("Redis connected");
  } catch (err) {
    logger.error("Redis connection failed", { error: String(err) });
    throw err;
  }
};

const getRedis = (): IRedis => {
  return Redis.getInstance();
};

export { connectRedis, getRedis };
