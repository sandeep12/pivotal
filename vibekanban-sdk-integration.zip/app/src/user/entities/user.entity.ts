type AuthMethod = {
  type: "local" | "google" | "microsoft" | "github";
  providerUserId?: string;
  passwordHash?: string;
  linkedAt: number;
};

type User = {
  id: string;
  name: string;
  email?: string;
  role?: string;
  authMethods?: AuthMethod[];
};

export type { User, AuthMethod };
