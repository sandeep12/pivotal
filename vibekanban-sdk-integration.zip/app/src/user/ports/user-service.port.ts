import type { User } from "../entities/user.entity.js";

type CreateUserParams = {
  name: string;
  email: string;
  role?: string;
  authMethods: Array<{
    type: "local" | "google" | "microsoft" | "github";
    passwordHash?: string;
    linkedAt: number;
  }>;
};

type UserSseEvent = {
  event: string;
  data: unknown;
};

type StartTestSseStreamParams = {
  send: (event: UserSseEvent) => void;
  abortSignal: AbortSignal;
};

type UserServicePort = {
  getById: (id: string) => Promise<User>;
  getByEmail: (email: string) => Promise<User | null>;
  create: (params: CreateUserParams) => Promise<User>;
  startTestSseStream: (params: StartTestSseStreamParams) => void;
};

export type {
  UserServicePort,
  CreateUserParams,
  UserSseEvent,
  StartTestSseStreamParams,
};
