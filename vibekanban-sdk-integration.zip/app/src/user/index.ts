import { UserService } from "./service/user.service.js";

const userService = new UserService();

export { userService, UserService };
