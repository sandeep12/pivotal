import { ObjectId } from "mongodb";
import { MongoDb } from "@util/mongodb";
import { ValidationError, NotFoundError } from "@util/error-normalizer";
import { UserService } from "./user.service.js";

const uri = process.env.MONGODB_URI ?? "";
const database = process.env.MONGODB_DATABASE ?? "aatmix_app_test";
const TEST_COLLECTION = "users";

let db: MongoDb | undefined;
let connected = false;
let testUserId: string;

beforeAll(async () => {
  if (
    !uri ||
    (!uri.startsWith("mongodb://") && !uri.startsWith("mongodb+srv://"))
  ) {
    connected = false;
    return;
  }
  db = MongoDb.create({ uri, database });
  try {
    await db.connect();
    connected = true;

    const col = db.collection(TEST_COLLECTION);
    await col.deleteMany({ _testMarker: "user-service-test" });

    const insertResult = await col.insertOne({
      name: "TestUser",
      email: "test@example.com",
      status: 1,
      createdAt: new Date(),
      updatedAt: new Date(),
      _testMarker: "user-service-test",
    });
    testUserId = insertResult.insertedId.toHexString();
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes("ECONNREFUSED") || msg.includes("Server selection")) {
      connected = false;
      return;
    }
    throw err;
  }
}, 20000);

afterAll(async () => {
  if (connected && db) {
    const col = db.collection(TEST_COLLECTION);
    await col.deleteMany({ _testMarker: "user-service-test" });
    await db.close();
  }
}, 10000);

const skipIfNotConnected = () => !connected;

describe("UserService.getById", () => {
  const service = new UserService();

  it("should return a user for a valid existing ID", async () => {
    if (skipIfNotConnected()) return;

    const user = await service.getById(testUserId);

    expect(user.id).toBe(testUserId);
    expect(user.name).toBe("TestUser");
  });

  it("should throw ValidationError for an invalid ObjectId", async () => {
    if (skipIfNotConnected()) return;

    await expect(service.getById("bad-id")).rejects.toThrow(ValidationError);
  });

  it("should throw NotFoundError for a valid but non-existent ObjectId", async () => {
    if (skipIfNotConnected()) return;

    const fakeId = new ObjectId().toHexString();
    await expect(service.getById(fakeId)).rejects.toThrow(NotFoundError);
  });
});

describe("UserService.getByEmail", () => {
  const service = new UserService();

  it("should return a user for an existing email", async () => {
    if (skipIfNotConnected()) return;

    const user = await service.getByEmail("test@example.com");
    expect(user).not.toBeNull();
    expect(user!.email).toBe("test@example.com");
    expect(user!.name).toBe("TestUser");
  });

  it("should return null for a non-existent email", async () => {
    if (skipIfNotConnected()) return;

    const user = await service.getByEmail("nonexistent@example.com");
    expect(user).toBeNull();
  });
});
