import type { AuthMethod, User } from "../entities/user.entity.js";
import type {
  UserServicePort,
  CreateUserParams,
  StartTestSseStreamParams,
} from "../ports/user-service.port.js";

import { NotFoundError } from "@util/error-normalizer";
import { getDb } from "../../infrastructure/database.js";
import { toObjectId } from "../../infrastructure/object-id.js";
import type { UserDoc } from "../schemas/user.schema.js";
import { UserDocSchema } from "../schemas/user.schema.js";

/**
 * Maps a MongoDB user document to the public domain `User` shape.
 */
const mapUserDocToDomain = (doc: UserDoc): User => {
  const user: User = {
    id: String(doc._id),
    name: doc.name,
    email: doc.email,
    role: doc.role,
  };
  if (doc.authMethods && doc.authMethods.length > 0) {
    user.authMethods = doc.authMethods as AuthMethod[];
  }
  return user;
};

class UserService implements UserServicePort {
  startTestSseStream = (params: StartTestSseStreamParams): void => {
    const TOTAL_SECONDS = 10;
    const INTERVAL_MS = 1_000;

    let tick = 0;
    params.send({
      event: "user.sse.started",
      data: {
        totalSeconds: TOTAL_SECONDS,
        intervalMs: INTERVAL_MS,
      },
    });

    const timer = setInterval(() => {
      if (params.abortSignal.aborted) {
        clearInterval(timer);
        return;
      }

      tick += 1;
      params.send({
        event: "user.sse.tick",
        data: {
          second: tick,
          totalSeconds: TOTAL_SECONDS,
          emittedAt: new Date().toISOString(),
        },
      });

      if (tick >= TOTAL_SECONDS) {
        clearInterval(timer);
        params.send({
          event: "user.sse.completed",
          data: { totalSeconds: TOTAL_SECONDS },
        });
      }
    }, INTERVAL_MS);

    params.abortSignal.addEventListener(
      "abort",
      () => {
        clearInterval(timer);
      },
      { once: true }
    );
  };

  getById = async (id: string): Promise<User> => {
    const objectId = toObjectId(id, "user id");

    const db = getDb();
    const doc = await db.findOne({
      collection: "users",
      filter: { _id: objectId },
      schema: UserDocSchema,
    });

    if (doc == null) {
      throw new NotFoundError("User not found", { id });
    }

    return mapUserDocToDomain(doc);
  };

  getByEmail = async (email: string): Promise<User | null> => {
    const db = getDb();
    const doc = await db.findOne({
      collection: "users",
      filter: { email },
      schema: UserDocSchema,
    });
    if (doc == null) {
      return null;
    }
    return mapUserDocToDomain(doc);
  };

  /** Creates a new user document and returns the mapped domain entity. */
  create = async (params: CreateUserParams): Promise<User> => {
    const db = getDb();
    const result = await db.createOne({
      collection: "users",
      doc: {
        name: params.name,
        email: params.email,
        role: params.role ?? "user",
        authMethods: params.authMethods,
      },
      schema: UserDocSchema,
    });
    const objectId = toObjectId(result.insertedId, "inserted id");
    const doc = await db.findOne({
      collection: "users",
      filter: { _id: objectId },
      schema: UserDocSchema,
    });
    if (doc == null) {
      throw new Error("User created but not found");
    }
    return mapUserDocToDomain(doc);
  };
}

export { UserService };
