import { z } from "zod";

const AuthMethodSchema = z.object({
  type: z.enum(["local", "google", "microsoft", "github"]),
  providerUserId: z.string().optional(),
  passwordHash: z.string().optional(),
  linkedAt: z.number(),
});

const UserDocSchema = z.object({
  _id: z.unknown(),
  name: z.string(),
  email: z.string().optional(),
  role: z.string().optional(),
  authMethods: z.array(AuthMethodSchema).optional(),
});

type UserDoc = z.infer<typeof UserDocSchema>;

export { UserDocSchema, AuthMethodSchema };
export type { UserDoc };
