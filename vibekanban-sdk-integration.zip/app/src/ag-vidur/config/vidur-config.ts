import type {
  AgentMode,
  GeminiLiveSdkConfig,
  OpenAIRealtimeAdapterConfig,
} from "@util/realtime";

import {
  vidurGeminiLiveTools,
  vidurOpenAiRealtimeTools,
} from "../tools/vidur-bridge-tools.js";

/**
 * Runtime options for the Vidur voice bridge, built from application env.
 * `@util/realtime` stays env-free; only the app reads `process.env`.
 */
export interface BridgeRuntimeConfig {
  agentMode: AgentMode;
  /** Present when `GEMINI_API_KEY` or `GOOGLE_API_KEY` is set. */
  gemini: GeminiLiveSdkConfig | null;
  /** Present when `OPENAI_API_KEY` is set. */
  openai: OpenAIRealtimeAdapterConfig | null;
}

function normalizeOptionalEnvString(
  raw: string | undefined | null
): string | undefined {
  if (raw === undefined || raw === null) {
    return undefined;
  }
  const trimmed = String(raw).trim();
  if (trimmed.length === 0) {
    return undefined;
  }
  const unquoted = trimmed.replace(/^['"]/, "").replace(/['"]$/, "").trim();
  return unquoted.length > 0 ? unquoted : undefined;
}

function readGeminiOutputVoiceFromEnv(): string | undefined {
  return (
    normalizeOptionalEnvString(process.env.GEMINI_LIVE_SDK_VOICE) ??
    normalizeOptionalEnvString(process.env.GEMINI_LIVE_VOICE) ??
    normalizeOptionalEnvString(process.env.GEMINI_VOICE_NAME)
  );
}

function resolveAgentMode(): AgentMode {
  const rawMode = process.env.VIDUR_AGENT_MODE;
  return rawMode === "echo" || rawMode === "openai" || rawMode === "gemini"
    ? rawMode
    : "echo";
}

function buildGeminiConfigFromEnv(): GeminiLiveSdkConfig | null {
  const apiKey =
    normalizeOptionalEnvString(process.env.GEMINI_API_KEY) ??
    normalizeOptionalEnvString(process.env.GOOGLE_API_KEY);
  if (!apiKey) {
    return null;
  }
  const model = normalizeOptionalEnvString(process.env.GEMINI_LIVE_SDK_MODEL);
  const systemInstruction = normalizeOptionalEnvString(
    process.env.GEMINI_LIVE_SDK_SYSTEM_INSTRUCTION
  );
  const inputAudioMimeType = normalizeOptionalEnvString(
    process.env.GEMINI_LIVE_SDK_INPUT_AUDIO_MIME_TYPE
  );
  const voiceName = readGeminiOutputVoiceFromEnv();
  return {
    apiKey,
    ...(model ? { model } : {}),
    ...(systemInstruction ? { systemInstruction } : {}),
    ...(voiceName ? { voiceName } : {}),
    ...(inputAudioMimeType ? { inputAudioMimeType } : {}),
  };
}

function buildOpenAiConfigFromEnv(): OpenAIRealtimeAdapterConfig | null {
  const apiKey = normalizeOptionalEnvString(process.env.OPENAI_API_KEY);
  if (!apiKey) {
    return null;
  }
  const model = normalizeOptionalEnvString(process.env.OPENAI_REALTIME_MODEL);
  const sampleRateRaw = normalizeOptionalEnvString(
    process.env.OPENAI_REALTIME_SAMPLE_RATE
  );
  return {
    apiKey,
    ...(model ? { model } : {}),
    ...(sampleRateRaw ? { sampleRate: Number(sampleRateRaw) } : {}),
  };
}

/**
 * Load Vidur bridge settings from `process.env` (after app `dotenv/config`).
 */
export function loadVidurBridgeConfigFromEnv(): BridgeRuntimeConfig {
  const gemini = buildGeminiConfigFromEnv();
  const openai = buildOpenAiConfigFromEnv();
  return {
    agentMode: resolveAgentMode(),
    gemini: gemini ? { ...gemini, tools: vidurGeminiLiveTools } : null,
    openai: openai ? { ...openai, tools: vidurOpenAiRealtimeTools } : null,
  };
}
