import type { VibeKanbanClientPort } from "../vibe-kanban/ports/vibe-kanban-client.port.js";
import {
  loadVidurBridgeConfigFromEnv,
  type BridgeRuntimeConfig,
} from "./config/vidur-config.js";
import { AgVidurService } from "./services/ag-vidur.service.js";

/**
 * @param vibeKanbanClient — Vibe Kanban client for tool-triggered API calls.
 * @param bridgeConfig — defaults to env-backed {@link loadVidurBridgeConfigFromEnv}.
 */
export function createAgVidurService(
  vibeKanbanClient: Pick<VibeKanbanClientPort, "createKanbanTicket">,
  bridgeConfig: BridgeRuntimeConfig = loadVidurBridgeConfigFromEnv()
): AgVidurService {
  return new AgVidurService(bridgeConfig, vibeKanbanClient);
}

export { AgVidurService };

export type { AgVidurServicePort } from "./ports/interfaces.js";
export type { BridgeRuntimeConfig } from "./config/vidur-config.js";
