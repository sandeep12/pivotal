import type { Logger } from "@util/logger";
import type { Session } from "@util/websocket";
import type { CreateIssueRequest } from "@util/vk-remote-sdk";

import type { VibeKanbanClientPort } from "../../vibe-kanban/ports/vibe-kanban-client.port.js";
import type { BridgeRuntimeConfig } from "../config/vidur-config.js";
import { handleEchoMode } from "../helpers/handle-echo-mode.js";
import { handleGeminiMode } from "../helpers/handle-gemini-mode.js";
import { handleOpenAiMode } from "../helpers/handle-openai-mode.js";
import type { AgVidurServicePort } from "../ports/interfaces.js";
import type { VidurBridgeToolContext } from "../tools/vidur-bridge-tool-batch.js";

/**
 * PCM in / PCM or JSON control out bridge to OpenAI Realtime (or echo).
 * Provider options are supplied via {@link VidurBridgeRuntimeConfig} (typically
 * built from env in the app layer).
 */
class AgVidurService implements AgVidurServicePort {
  constructor(
    private readonly bridgeConfig: BridgeRuntimeConfig,
    private readonly vibeKanbanClient: Pick<
      VibeKanbanClientPort,
      "createKanbanTicket"
    >
  ) {}

  registerVidurBridgeSession(session: Session, logger: Logger): void {
    const mode = this.bridgeConfig.agentMode;
    logger.info("Vidur bridge session connected", {
      sessionId: session.id,
      mode,
    });

    const toolCtx: VidurBridgeToolContext = {
      now: () => new Date(),
      createKanbanTicket: (input: CreateIssueRequest) =>
        this.vibeKanbanClient.createKanbanTicket(input),
    };

    switch (mode) {
      case "gemini":
        handleGeminiMode(session, logger, this.bridgeConfig.gemini, toolCtx);
        break;
      case "openai":
        handleOpenAiMode(
          session,
          logger,
          mode,
          this.bridgeConfig.openai,
          toolCtx
        );
        break;
      case "echo":
      default:
        handleEchoMode(session, logger);
        break;
    }
  }
}

export { AgVidurService };
