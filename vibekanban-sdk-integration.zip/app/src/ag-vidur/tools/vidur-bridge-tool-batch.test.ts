import {
  VIDUR_CREATE_KANBAN_TICKET_TOOL_NAME,
  VIDUR_SAMPLE_DATE_TOOL_NAME,
} from "./vidur-bridge-tools.js";
import { resolveVidurBridgeToolBatch } from "./vidur-bridge-tool-batch.js";

describe("resolveVidurBridgeToolBatch", () => {
  const fixed = new Date("2026-04-15T14:30:00.000Z");

  const unusedKanban = async () =>
    ({ ok: false as const, error: "unused" }) as const;

  const ctx = {
    now: () => fixed,
    createKanbanTicket: unusedKanban,
  };

  it("returns null for an empty batch", async () => {
    await expect(resolveVidurBridgeToolBatch([], ctx)).resolves.toBeNull();
  });

  it("returns null for unknown tool names", async () => {
    await expect(
      resolveVidurBridgeToolBatch(
        [{ name: "unknown_tool", args: {}, callId: "c1" }],
        ctx
      )
    ).resolves.toBeNull();
  });

  it("resolves get_current_date with default iso format", async () => {
    const results = await resolveVidurBridgeToolBatch(
      [{ name: VIDUR_SAMPLE_DATE_TOOL_NAME, args: {}, callId: "fc-1" }],
      ctx
    );
    expect(results).toEqual([
      {
        callId: "fc-1",
        name: VIDUR_SAMPLE_DATE_TOOL_NAME,
        output: { iso: "2026-04-15T14:30:00.000Z" },
      },
    ]);
  });

  it("includes unix_ms when format is unix_ms", async () => {
    const results = await resolveVidurBridgeToolBatch(
      [
        {
          name: VIDUR_SAMPLE_DATE_TOOL_NAME,
          args: { format: "unix_ms" },
          callId: "x",
        },
      ],
      ctx
    );
    expect(results).toEqual([
      {
        callId: "x",
        name: VIDUR_SAMPLE_DATE_TOOL_NAME,
        output: {
          unix_ms: fixed.getTime(),
          iso: "2026-04-15T14:30:00.000Z",
        },
      },
    ]);
  });

  it("resolves multiple date calls in one batch", async () => {
    const results = await resolveVidurBridgeToolBatch(
      [
        { name: VIDUR_SAMPLE_DATE_TOOL_NAME, args: {}, callId: "a" },
        {
          name: VIDUR_SAMPLE_DATE_TOOL_NAME,
          args: { format: "iso" },
          callId: "b",
        },
      ],
      ctx
    );
    expect(results).toHaveLength(2);
    expect(results?.[0].callId).toBe("a");
    expect(results?.[1].callId).toBe("b");
  });

  it("resolves create_kanban_ticket on success", async () => {
    const results = await resolveVidurBridgeToolBatch(
      [
        {
          name: VIDUR_CREATE_KANBAN_TICKET_TOOL_NAME,
          args: {
            project_id: "project-uuid",
            status_id: "status-uuid",
            title: "Ship feature",
          },
          callId: "k1",
        },
      ],
      {
        now: () => fixed,
        createKanbanTicket: async () => ({
          ok: true,
          ticket: {
            id: "issue-uuid",
            simpleId: "DEMO-42",
            issueNumber: 42,
            title: "Hardcoded",
          },
        }),
      }
    );
    expect(results).toEqual([
      {
        callId: "k1",
        name: VIDUR_CREATE_KANBAN_TICKET_TOOL_NAME,
        output: {
          ok: true,
          issue_id: "issue-uuid",
          simple_id: "DEMO-42",
          issue_number: 42,
          title: "Hardcoded",
        },
      },
    ]);
  });

  it("marks create_kanban_ticket failure as tool error", async () => {
    const results = await resolveVidurBridgeToolBatch(
      [
        {
          name: VIDUR_CREATE_KANBAN_TICKET_TOOL_NAME,
          args: {
            project_id: "project-uuid",
            status_id: "status-uuid",
            title: "Ship feature",
          },
          callId: "k2",
        },
      ],
      {
        now: () => fixed,
        createKanbanTicket: async () => ({
          ok: false,
          error: "VK remote API error HTTP 403: …",
        }),
      }
    );
    expect(results).toEqual([
      {
        callId: "k2",
        name: VIDUR_CREATE_KANBAN_TICKET_TOOL_NAME,
        output: { ok: false, error: "VK remote API error HTTP 403: …" },
        isError: true,
      },
    ]);
  });

  it("returns tool error when required args are missing", async () => {
    const results = await resolveVidurBridgeToolBatch(
      [{ name: VIDUR_CREATE_KANBAN_TICKET_TOOL_NAME, args: {}, callId: "k3" }],
      ctx
    );
    expect(results).toEqual([
      {
        callId: "k3",
        name: VIDUR_CREATE_KANBAN_TICKET_TOOL_NAME,
        output: {
          ok: false,
          error:
            "Missing required arguments: project_id, status_id, and title are required.",
        },
        isError: true,
      },
    ]);
  });
});
