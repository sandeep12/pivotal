import type { OpenAiRealtimeSessionTool, Tool } from "@util/realtime";

/** Built-in bridge tool name; resolved by `resolveVidurBridgeToolBatch` in `vidur-bridge-tool-batch.ts`. */
export const VIDUR_SAMPLE_DATE_TOOL_NAME = "get_current_date" as const;

/** Kanban ticket tool (explicit project/status/title input); resolved server-side via VK remote SDK. */
export const VIDUR_CREATE_KANBAN_TICKET_TOOL_NAME =
  "create_kanban_ticket" as const;

const dateToolDescription =
  "Returns the current server date and time. Use when the user asks what day or time it is.";

const dateToolParametersJsonSchema = {
  type: "object",
  properties: {
    format: {
      type: "string",
      enum: ["iso", "unix_ms"],
      description:
        'Optional. "iso" (default) returns ISO-8601 string; "unix_ms" also includes Unix epoch milliseconds.',
    },
  },
  additionalProperties: false,
} as const;

const kanbanTicketToolDescription =
  "Creates a Kanban board issue using explicit project/status/title inputs. " +
  "Use when the user asks to create a Kanban ticket from Vidur.";

const kanbanTicketToolParametersJsonSchema = {
  type: "object",
  properties: {
    project_id: {
      type: "string",
      description: "Target Kanban project UUID.",
    },
    status_id: {
      type: "string",
      description: "Target project status UUID (column).",
    },
    title: {
      type: "string",
      description: "Issue title.",
    },
    description: {
      type: "string",
      description: "Optional issue description.",
    },
    sort_order: {
      type: "number",
      description: "Optional sort order (default 0).",
    },
  },
  required: ["project_id", "status_id", "title"],
  additionalProperties: false,
} as const;

/**
 * Gemini Live `config.tools` entries (SDK-native `Tool` shape).
 * Keep declaration aligned with {@link vidurOpenAiRealtimeTools} for the same logical tool.
 */
export const vidurGeminiLiveTools: Tool[] = [
  {
    functionDeclarations: [
      {
        name: VIDUR_SAMPLE_DATE_TOOL_NAME,
        description: dateToolDescription,
        parametersJsonSchema: { ...dateToolParametersJsonSchema },
      },
      {
        name: VIDUR_CREATE_KANBAN_TICKET_TOOL_NAME,
        description: kanbanTicketToolDescription,
        parametersJsonSchema: { ...kanbanTicketToolParametersJsonSchema },
      },
    ],
  },
];

/**
 * OpenAI Realtime `session.tools` entries.
 * Same logical tool as {@link vidurGeminiLiveTools}; parameters mirror Gemini JSON schema.
 */
export const vidurOpenAiRealtimeTools: OpenAiRealtimeSessionTool[] = [
  {
    type: "function",
    name: VIDUR_SAMPLE_DATE_TOOL_NAME,
    description: dateToolDescription,
    parameters: { ...dateToolParametersJsonSchema },
  },
  {
    type: "function",
    name: VIDUR_CREATE_KANBAN_TICKET_TOOL_NAME,
    description: kanbanTicketToolDescription,
    parameters: { ...kanbanTicketToolParametersJsonSchema },
  },
];
