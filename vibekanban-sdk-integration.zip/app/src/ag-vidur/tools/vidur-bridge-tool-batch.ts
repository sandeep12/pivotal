import type {
  RealtimeToolCallPayload,
  RealtimeToolResult,
} from "@util/realtime";
import type { CreateIssueRequest } from "@util/vk-remote-sdk";

import type { VibeKanbanCreateTicketResult } from "../../vibe-kanban/ports/vibe-kanban-client.port.js";
import {
  VIDUR_CREATE_KANBAN_TICKET_TOOL_NAME,
  VIDUR_SAMPLE_DATE_TOOL_NAME,
} from "./vidur-bridge-tools.js";

export interface VidurBridgeToolContext {
  now: () => Date;
  createKanbanTicket: (
    input: CreateIssueRequest
  ) => Promise<VibeKanbanCreateTicketResult>;
}

/**
 * If every call in the batch is a built-in Vidur bridge tool, resolves and returns
 * results to send to the provider; otherwise `null` (caller should wait for client
 * `vidur_tool_results` or other handling).
 */
export async function resolveVidurBridgeToolBatch(
  calls: RealtimeToolCallPayload[],
  ctx: VidurBridgeToolContext
): Promise<RealtimeToolResult[] | null> {
  if (calls.length === 0) {
    return null;
  }
  const results: RealtimeToolResult[] = [];
  for (const call of calls) {
    if (call.name === VIDUR_SAMPLE_DATE_TOOL_NAME) {
      const formatRaw = call.args?.format;
      const format =
        formatRaw === "unix_ms" || formatRaw === "iso" ? formatRaw : "iso";
      const d = ctx.now();
      const payload =
        format === "unix_ms"
          ? { unix_ms: d.getTime(), iso: d.toISOString() }
          : { iso: d.toISOString() };
      results.push({
        callId: call.callId,
        name: call.name,
        output: payload,
      });
      continue;
    }
    if (call.name === VIDUR_CREATE_KANBAN_TICKET_TOOL_NAME) {
      const projectId = String(call.args?.project_id ?? "").trim();
      const statusId = String(call.args?.status_id ?? "").trim();
      const title = String(call.args?.title ?? "").trim();
      if (!projectId || !statusId || !title) {
        results.push({
          callId: call.callId,
          name: call.name,
          output: {
            ok: false,
            error:
              "Missing required arguments: project_id, status_id, and title are required.",
          },
          isError: true,
        });
        continue;
      }
      const created = await ctx.createKanbanTicket({
        project_id: projectId,
        status_id: statusId,
        title,
        description:
          typeof call.args?.description === "string"
            ? call.args.description
            : undefined,
        sort_order:
          typeof call.args?.sort_order === "number" ? call.args.sort_order : 0,
        extension_metadata: { source: "vidur-bridge" },
      });
      if (created.ok) {
        results.push({
          callId: call.callId,
          name: call.name,
          output: {
            ok: true,
            issue_id: created.ticket.id,
            simple_id: created.ticket.simpleId,
            issue_number: created.ticket.issueNumber,
            title: created.ticket.title,
          },
        });
      } else {
        results.push({
          callId: call.callId,
          name: call.name,
          output: { ok: false, error: created.error },
          isError: true,
        });
      }
      continue;
    }
    return null;
  }
  return results;
}
