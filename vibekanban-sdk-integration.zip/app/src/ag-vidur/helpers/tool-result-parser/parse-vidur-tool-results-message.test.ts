import { parseVidurToolResultsMessage } from "./parse-vidur-tool-results-message.js";

describe("parseVidurToolResultsMessage", () => {
  it("returns null for non-JSON buffers", () => {
    expect(parseVidurToolResultsMessage(Buffer.from([0, 1, 2]))).toBeNull();
  });

  it("returns null for JSON without vidur_tool_results type", () => {
    expect(
      parseVidurToolResultsMessage(
        Buffer.from(JSON.stringify({ type: "other" }), "utf8")
      )
    ).toBeNull();
  });

  it("parses valid tool results", () => {
    const payload = {
      type: "vidur_tool_results",
      results: [
        {
          callId: "call_1",
          name: "get_current_date",
          output: { ok: true },
        },
      ],
    };
    expect(
      parseVidurToolResultsMessage(Buffer.from(JSON.stringify(payload), "utf8"))
    ).toEqual([
      {
        callId: "call_1",
        name: "get_current_date",
        output: { ok: true },
        isError: false,
      },
    ]);
  });

  it("sets isError when true", () => {
    const payload = {
      type: "vidur_tool_results",
      results: [
        {
          name: "get_current_date",
          output: { message: "bad" },
          isError: true,
        },
      ],
    };
    expect(
      parseVidurToolResultsMessage(Buffer.from(JSON.stringify(payload), "utf8"))
    ).toEqual([
      {
        callId: undefined,
        name: "get_current_date",
        output: { message: "bad" },
        isError: true,
      },
    ]);
  });
});
