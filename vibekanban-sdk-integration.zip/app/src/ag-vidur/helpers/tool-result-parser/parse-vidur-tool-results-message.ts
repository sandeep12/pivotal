import type { RealtimeToolResult } from "@util/realtime";

/**
 * If the client sends a UTF-8 JSON control frame (not raw PCM), parse tool results
 * (`type`: `"vidur_tool_results"`).
 *
 * @returns `null` when the buffer is not a valid tool-results message.
 */
export function parseVidurToolResultsMessage(
  data: Buffer
): RealtimeToolResult[] | null {
  if (data.length === 0 || data[0] !== 0x7b) {
    return null;
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(data.toString("utf8"));
  } catch {
    return null;
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    return null;
  }
  const o = parsed as Record<string, unknown>;
  if (o.type !== "vidur_tool_results") {
    return null;
  }
  if (!Array.isArray(o.results)) {
    return null;
  }
  const out: RealtimeToolResult[] = [];
  for (const raw of o.results) {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      continue;
    }
    const r = raw as Record<string, unknown>;
    if (typeof r.name !== "string" || r.name.length === 0) {
      continue;
    }
    const output = r.output;
    if (!output || typeof output !== "object" || Array.isArray(output)) {
      continue;
    }
    out.push({
      callId: typeof r.callId === "string" ? r.callId : undefined,
      name: r.name,
      output: output as Record<string, unknown>,
      isError: r.isError === true,
    });
  }
  return out;
}
