import type { Logger } from "@util/logger";
import type { Session } from "@util/websocket";

import { logSessionDisconnected } from "./session-bridge.js";

/**
 * Handle local echo mode with no upstream provider.
 */
export function handleEchoMode(session: Session, logger: Logger): void {
  session.onMessage((data) => {
    logger.info("[echo] received bytes", {
      sessionId: session.id,
      bytes: data.length,
    });
    session.send(data);
    logger.info("[echo] sent bytes", {
      sessionId: session.id,
      bytes: data.length,
    });
  });
  session.onClose(() => {
    logSessionDisconnected(session, logger);
  });
}
