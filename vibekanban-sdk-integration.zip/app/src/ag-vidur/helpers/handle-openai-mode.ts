import type { Logger } from "@util/logger";
import { createProviderAdapter } from "@util/realtime";
import type {
  AgentMode,
  OpenAIRealtimeAdapterConfig,
  ProviderAdapter,
} from "@util/realtime";
import { createClient } from "@util/websocket";
import type { Session } from "@util/websocket";

import type { VidurBridgeToolContext } from "../tools/vidur-bridge-tool-batch.js";
import { resolveVidurBridgeToolBatch } from "../tools/vidur-bridge-tool-batch.js";
import {
  createSessionPcmBridge,
  logSessionDisconnected,
  sendSessionErrorAndClose,
  toErrorMessage,
} from "./session-bridge.js";
import { parseVidurToolResultsMessage } from "./tool-result-parser/parse-vidur-tool-results-message.js";

/**
 * Handle openai mode by wiring upstream realtime websocket adapter.
 */
export function handleOpenAiMode(
  session: Session,
  logger: Logger,
  mode: Exclude<AgentMode, "echo">,
  openaiConfig: OpenAIRealtimeAdapterConfig | null,
  toolCtx: VidurBridgeToolContext
): void {
  if (!openaiConfig) {
    sendSessionErrorAndClose(
      session,
      "OPENAI_API_KEY is required for openai mode"
    );
    return;
  }

  const providerMode = "openai";
  let upstream = null as ReturnType<typeof createClient> | null;
  let adapter: ProviderAdapter | null = null;
  const bridge = createSessionPcmBridge(session, mode);

  try {
    adapter = createProviderAdapter(providerMode, openaiConfig);
    upstream = createClient({
      url: adapter.url,
      ...(adapter.headers ? { headers: adapter.headers } : {}),
    });
  } catch (err: unknown) {
    sendSessionErrorAndClose(session, toErrorMessage(err));
    return;
  }

  const sendUpstreamAudio = (chunk: Uint8Array): void => {
    if (!adapter || !upstream || !upstream.isOpen() || chunk.length === 0)
      return;
    upstream.send(adapter.audioMessage(chunk));
  };

  const armAudioIdle = (): void => {
    const audioStreamEndMessage = adapter?.audioStreamEndMessage?.();
    if (!audioStreamEndMessage || !upstream) return;
    bridge.scheduleAudioIdle(() => {
      if (!upstream || !upstream.isOpen() || !adapter) return;
      upstream.send(audioStreamEndMessage);
      for (const msg of adapter.stopMessages()) {
        upstream.send(msg);
      }
    });
  };

  upstream.onOpen(() => {
    if (!adapter || !upstream || !upstream.isOpen()) return;
    for (const msg of adapter.setupMessages()) {
      upstream.send(msg);
    }
  });

  upstream.onTextMessage((text: string) => {
    if (!adapter) return;
    const parsed = adapter.parseIncomingText(text);
    if (parsed.event && "setupComplete" in parsed.event) {
      bridge.markProviderReady(sendUpstreamAudio, armAudioIdle);
    }
    if (parsed.audio) {
      for (const pcm of parsed.audio) session.send(Buffer.from(pcm));
    }
    if (parsed.providerError) {
      bridge.sendControl({
        type: "error",
        message: parsed.providerError,
      });
    }
    if (parsed.toolCalls && parsed.toolCalls.length > 0) {
      bridge.sendControl({
        type: "tool_call",
        provider: "openai",
        calls: parsed.toolCalls,
      });
      void resolveVidurBridgeToolBatch(parsed.toolCalls, toolCtx).then(
        (sampleResults) => {
          if (sampleResults && upstream?.isOpen()) {
            for (const msg of adapter.toolResultMessages(sampleResults)) {
              upstream.send(msg);
            }
          }
        }
      );
    }
    if (parsed.event) {
      bridge.sendControl({
        type: "provider_event",
        payload: parsed.event,
      });
    }
  });

  upstream.onError((err: Error) => {
    bridge.sendControl({ type: "error", message: err.message });
  });
  upstream.onClose((code: number, reason: string) => {
    const suffix = reason ? ` (${code}: ${reason})` : ` (${code})`;
    bridge.sendControl({
      type: "error",
      message: `Provider connection closed${suffix}`,
    });
  });

  session.onMessage((data) => {
    const toolResults = parseVidurToolResultsMessage(data);
    if (toolResults !== null && adapter && upstream?.isOpen()) {
      for (const msg of adapter.toolResultMessages(toolResults)) {
        upstream.send(msg);
      }
      return;
    }
    bridge.onClientPcm(data, sendUpstreamAudio, armAudioIdle);
  });

  session.onClose(() => {
    bridge.dispose();
    if (adapter && upstream && upstream.isOpen()) {
      for (const msg of adapter.stopMessages()) {
        upstream.send(msg);
      }
    }
    if (upstream) {
      upstream.close();
    }
    logSessionDisconnected(session, logger);
  });
}
