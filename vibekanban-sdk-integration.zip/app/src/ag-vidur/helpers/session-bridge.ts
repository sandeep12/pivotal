import type { Logger } from "@util/logger";
import type { AgentMode } from "@util/realtime";
import type { Session } from "@util/websocket";

/**
 * Normalize unknown errors to a serializable message.
 */
export const toErrorMessage = (err: unknown): string =>
  err instanceof Error ? err.message : String(err);

/**
 * Send an error control message and close the websocket session.
 */
export const sendSessionErrorAndClose = (
  session: Session,
  message: string
): void => {
  session.send(JSON.stringify({ type: "error", message }));
  session.close();
};

/**
 * Emit a consistent disconnection log for vidur bridge sessions.
 */
export const logSessionDisconnected = (
  session: Session,
  logger: Logger
): void => {
  logger.info("Vidur bridge session disconnected", {
    sessionId: session.id,
  });
};

const PENDING_MAX = 32;
const AUDIO_IDLE_MS = 700;
const STATS_INTERVAL_MS = 2000;

export interface SessionPcmBridge {
  sendControl(event: Record<string, unknown>): void;
  markProviderReady(
    sendToProvider: (chunk: Buffer) => void,
    armAudioIdle?: () => void
  ): void;
  onClientPcm(
    data: Uint8Array,
    sendToProvider: (chunk: Buffer) => void,
    armAudioIdle?: () => void
  ): void;
  scheduleAudioIdle(onFire: () => void): void;
  dispose(): void;
}

export function createSessionPcmBridge(
  session: Session,
  provider: Exclude<AgentMode, "echo">
): SessionPcmBridge {
  let ready = false;
  const pending: Buffer[] = [];
  let audioIdleTimer: ReturnType<typeof setTimeout> | null = null;
  let statsTimer: ReturnType<typeof setInterval> | null = null;
  let forwardedChunks = 0;

  const sendControl = (event: Record<string, unknown>): void => {
    session.send(JSON.stringify({ ...event, provider }));
  };

  const clearAudioIdleTimer = (): void => {
    if (!audioIdleTimer) return;
    clearTimeout(audioIdleTimer);
    audioIdleTimer = null;
  };

  const clearStatsTimer = (): void => {
    if (!statsTimer) return;
    clearInterval(statsTimer);
    statsTimer = null;
  };

  const scheduleAudioIdle = (onFire: () => void): void => {
    clearAudioIdleTimer();
    audioIdleTimer = setTimeout(() => {
      onFire();
      audioIdleTimer = null;
    }, AUDIO_IDLE_MS);
  };

  const deliver = (
    chunk: Buffer,
    sendToProvider: (c: Buffer) => void,
    armAudioIdle?: () => void
  ): void => {
    sendToProvider(chunk);
    forwardedChunks += 1;
    armAudioIdle?.();
  };

  const startStatsTicker = (): void => {
    clearStatsTimer();
    statsTimer = setInterval(() => {
      sendControl({
        type: "bridge_stats",
        forwardedAudioChunks: forwardedChunks,
        bufferedAudioChunks: pending.length,
      });
    }, STATS_INTERVAL_MS);
  };

  const markProviderReady = (
    sendToProvider: (chunk: Buffer) => void,
    armAudioIdle?: () => void
  ): void => {
    if (ready) return;
    ready = true;
    sendControl({ type: "provider_ready" });
    startStatsTicker();
    while (pending.length > 0) {
      const buffered = pending.shift();
      if (!buffered) continue;
      deliver(Buffer.from(buffered), sendToProvider, armAudioIdle);
    }
  };

  const onClientPcm = (
    data: Buffer,
    sendToProvider: (chunk: Buffer) => void,
    armAudioIdle?: () => void
  ): void => {
    try {
      if (!data || data.length === 0) return;
      if (!ready) {
        pending.push(data);
        if (pending.length > PENDING_MAX) {
          pending.shift();
        }
        return;
      }
      deliver(data, sendToProvider, armAudioIdle);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      sendControl({ type: "error", message: msg });
    }
  };

  const dispose = (): void => {
    clearAudioIdleTimer();
    clearStatsTimer();
    pending.length = 0;
  };

  return {
    sendControl,
    markProviderReady,
    onClientPcm,
    scheduleAudioIdle,
    dispose,
  };
}
