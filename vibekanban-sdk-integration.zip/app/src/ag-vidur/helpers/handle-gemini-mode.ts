import type { Logger } from "@util/logger";
import { createGeminiLiveSdkConnector } from "@util/realtime";
import type {
  GeminiLiveSdkConfig,
  GeminiLiveSdkConnectorEvent,
} from "@util/realtime";
import type { Session } from "@util/websocket";

import type { VidurBridgeToolContext } from "../tools/vidur-bridge-tool-batch.js";
import { resolveVidurBridgeToolBatch } from "../tools/vidur-bridge-tool-batch.js";
import {
  createSessionPcmBridge,
  logSessionDisconnected,
  sendSessionErrorAndClose,
  toErrorMessage,
} from "./session-bridge.js";
import { parseVidurToolResultsMessage } from "./tool-result-parser/parse-vidur-tool-results-message.js";

const GEMINI_FORCE_COMMIT_MS = 4000;

/**
 * Handle gemini-sdk mode by bridging client PCM and Gemini events.
 */
export function handleGeminiMode(
  session: Session,
  logger: Logger,
  geminiConfig: GeminiLiveSdkConfig | null,
  toolCtx: VidurBridgeToolContext
): void {
  if (!geminiConfig) {
    sendSessionErrorAndClose(
      session,
      "GEMINI_API_KEY or GOOGLE_API_KEY is required for gemini-sdk mode"
    );
    return;
  }

  logger.info("Gemini Live SDK voice config", {
    sessionId: session.id,
    voiceName: geminiConfig.voiceName ?? null,
  });

  const bridge = createSessionPcmBridge(session, "gemini");
  const connector = createGeminiLiveSdkConnector(geminiConfig);
  const sendToProvider = (chunk: Uint8Array): void =>
    connector.sendAudioChunk(chunk);
  let forcedCommitTimer: ReturnType<typeof setTimeout> | null = null;
  let forceCommitArmed = false;

  const armAudioIdle = (): void => {
    bridge.scheduleAudioIdle(() => {
      connector.endAudioStream();
      forceCommitArmed = false;
    });
  };

  const clearForcedCommitTimer = (): void => {
    if (!forcedCommitTimer) return;
    clearTimeout(forcedCommitTimer);
    forcedCommitTimer = null;
  };

  const scheduleForcedCommit = (): void => {
    if (forceCommitArmed) return;
    forceCommitArmed = true;
    clearForcedCommitTimer();
    forcedCommitTimer = setTimeout(() => {
      connector.endAudioStream();
      forceCommitArmed = false;
      forcedCommitTimer = null;
    }, GEMINI_FORCE_COMMIT_MS);
  };

  connector.onEvent((event: GeminiLiveSdkConnectorEvent) => {
    if (event.type === "ready") {
      bridge.markProviderReady(sendToProvider, armAudioIdle);
      return;
    }
    if (event.type === "audio") {
      for (const pcm of event.chunks) {
        session.send(Buffer.from(pcm));
      }
      return;
    }
    if (event.type === "transcript") {
      const speaker = event.transcript.role === "user" ? "User" : "Gemini";
      console.log(`${speaker}: ${event.transcript.text}`);
      logger.info("Gemini transcript received", {
        sessionId: session.id,
        role: event.transcript.role,
        textLength: event.transcript.text.length,
      });
      bridge.sendControl({
        type: "transcript",
        role: event.transcript.role,
        text: event.transcript.text,
      });
      return;
    }
    if (event.type === "tool_call") {
      bridge.sendControl({
        type: "tool_call",
        provider: "gemini",
        calls: event.calls,
      });
      void resolveVidurBridgeToolBatch(event.calls, toolCtx).then(
        (sampleResults) => {
          if (sampleResults) {
            connector.sendToolResults(sampleResults);
          }
        }
      );
      return;
    }
    if (event.type === "tool_call_cancel") {
      bridge.sendControl({
        type: "tool_call_cancel",
        provider: "gemini",
        ids: event.ids,
      });
      return;
    }
    if (event.type === "provider_event") {
      bridge.sendControl({
        type: "provider_event",
        payload: event.payload,
      });
      return;
    }
    if (event.type === "interrupted") {
      bridge.sendControl({ type: "interrupted" });
      return;
    }
    if (event.type === "error") {
      bridge.sendControl({ type: "error", message: event.message });
      return;
    }
    if (event.type === "closed") {
      const reason = event.details.reason ? `: ${event.details.reason}` : "";
      bridge.sendControl({
        type: "error",
        message: `Gemini Live SDK closed${reason}`,
      });
    }
  });

  void connector.connect().catch((err: unknown) => {
    const message = toErrorMessage(err);
    bridge.sendControl({ type: "error", message });
    session.close();
  });

  session.onMessage((data) => {
    const toolResults = parseVidurToolResultsMessage(data);
    if (toolResults !== null) {
      connector.sendToolResults(toolResults);
      return;
    }
    bridge.onClientPcm(data, sendToProvider, armAudioIdle);
    scheduleForcedCommit();
  });

  session.onClose(() => {
    clearForcedCommitTimer();
    connector.endAudioStream();
    bridge.dispose();
    connector.close();
    logSessionDisconnected(session, logger);
  });
}
