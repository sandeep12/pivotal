import type { Logger } from "@util/logger";
import type { Session } from "@util/websocket";

interface AgVidurServicePort {
  registerVidurBridgeSession: (session: Session, logger: Logger) => void;
}

export type { AgVidurServicePort };
