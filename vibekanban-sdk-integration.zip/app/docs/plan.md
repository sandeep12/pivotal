# App Design Plan

## Problem Definition

The Nexus app is the main API server that bootstraps shared infrastructure (logger, secrets, database) and exposes HTTP endpoints organized by domain modules following DDD + Hexagonal architecture. Each module encapsulates entities, ports, services, and schemas, while channels (HTTP routes) and infrastructure (DB, external SDKs) live in separate layers.

## Requirements

1. Clean bootstrap — initialize logger, secrets, and database before accepting traffic.
2. Graceful shutdown — close DB, secrets, and logger on SIGTERM/SIGINT with error logging.
3. Input validation — all route handlers validate input with Zod before passing to services.
4. Port/implementation alignment — service ports must match their implementation signatures.
5. Infrastructure isolation — DB driver types (`ObjectId`, `MongoClient`) stay in the infrastructure layer, not in services.
6. Testability — no top-level `await` in shared modules so Jest can import them without ESM issues.

## Folder Structure (DDD + Hexagonal)

```
app/src/
├── <module>/              # Bounded context (e.g. user, order)
│   ├── entities/          # Core types; no framework
│   ├── domain/            # Events, invariants, errors (optional)
│   ├── ports/             # Outbound interfaces (e.g. UserServicePort)
│   ├── schemas/           # Zod schemas for DB/API (optional)
│   ├── service/           # Application services, use cases
│   └── index.ts
├── channels/http/         # HTTP routes (user.routes.ts, order.routes.ts)
├── infrastructure/        # DB pool, HTTP clients, external SDKs, ObjectId helper
├── shared/                # Logger, secrets, shared utilities
└── index.ts
```

**Dependency rule:** `channels → service → entities, ports`; `service → infrastructure`. No framework imports in entities or ports.

| Need                | Add to               |
| ------------------- | -------------------- |
| New entity          | `<module>/entities/` |
| Domain event        | `<module>/domain/`   |
| Service port        | `<module>/ports/`    |
| Use case            | `<module>/service/`  |
| Zod schema (DB/API) | `<module>/schemas/`  |
| HTTP endpoint       | `channels/http/`     |
| DB / external       | `infrastructure/`    |
| Cross-module        | `shared/`            |

## Bootstrap Flow

1. Load env via `dotenv` in `index.ts`.
2. Initialize shared `logger` (`@util/logger`) and `secrets` (`@util/secret-manager-aws`) via `initLogger()` / `initSecrets()`.
3. Create `ApiServer` with config, logger, `onAppStart`, `onAppStop`, and `routes`.
4. In `onAppStart`: call `connectDb()` (if `MONGODB_URI` or `DB_SECRET_ID`), then `connectRedis()`.
5. In `onAppStop`: call `getDb().close()`, `getRedis().close()` (with error logging), then `secrets.close()`.
6. `await server.start()`.

## Phases

### Phase 1 — Skeleton (complete)

- Bootstrap flow with logger, secrets, database
- User module: entity, port, service, schema, routes
- Infrastructure: `connectDb`, `getDb`, `toObjectId` helper

### Phase 2 — Hardening (complete)

- Route handler input validation with Zod (`parseInput` helper)
- `UserServicePort` return type aligned with implementation
- `connectDb()` logs warning when no DB configured
- `onAppStop` logs DB close errors instead of swallowing
- `ObjectId` dependency moved from `UserService` to `infrastructure/object-id.ts`
- Shared modules (`logger.ts`, `secret.ts`) use lazy init for Jest compatibility

### Phase 3 — Testing (complete)

- `toObjectId` unit tests (4 tests)
- `UserService.getById` integration tests with real MongoDB (3 tests)

### Phase 4 — Auth (complete)

- `@util/jwt-tokens` package: JWT sign/verify, password hashing, token rotation, `requireRoles` middleware
- Auth endpoints: POST /auth/login, POST /auth/refresh, POST /auth/logout, POST /auth/logout-all, GET /auth/me
- Redis-backed session: allowlist (`user:{sub}:refresh:{jti}`), revoked blacklist (`revoked:{jti}`)
- `util-api-server` RouteDefinition extended with optional `middleware`
- User entity extended with `authMethods` for future OAuth (Google/Microsoft/GitHub)
- `UserService.getByEmail` for login lookup

### Phase 5 — Integration Tests (complete)

- Route-level HTTP integration tests spinning up `ApiServer` with real DB + Redis when available (skip-if-not-ready pattern) — `src/channels/http/http-routes.test.ts`
- Auth endpoint integration tests: login, refresh, logout, me, register, duplicate email, 401 unauthenticated

### Phase 6 — Future

- Additional domain modules (order, product, etc.)
- Error mapping middleware tests
- OAuth provider integration (`@util/auth-orchestrator`)
- Unit tests for `createRequireRolesMiddleware` — done (`require-roles.middleware.test.ts`)
- Atomic refresh token rotation (Redis GETDEL or Lua script to prevent concurrent refresh race)
- **Vibe Kanban** — see [Vibe Kanban (vk-remote-sdk) integration](#vibe-kanban-vk-remote-sdk-integration) below

## Vibe Kanban (vk-remote-sdk) integration

Workspace package: `@util/vk-remote-sdk` (`packages/util-vk-remote-sdk/`). SDK may evolve outside Nexus; Nexus keeps a **thin adapter boundary** so churn is localized.

### Problem definition

**Problem:** Nexus must call the Vibe Kanban remote HTTP API and accept verified workflow webhooks without spreading SDK types or `VkRemoteClient` across the codebase.

**User:** Operators and internal automation (and optionally other bounded contexts) that need board/issue data or reactions to `issue.status_changed` (and related) events.

**Success:** All SDK usage sits behind ports; HTTP boundaries validate input; env is read only at bootstrap; bumping the SDK primarily touches `infrastructure/*` under this module.

### Requirements

**Functional**

- Outbound: list/query organizations, projects, workspaces, issues (subset driven by product needs, not “wrap entire SDK”).
- Inbound: HTTP route(s) that verify webhook signatures, parse payloads, and dispatch to application logic.

**Non-functional**

- **Security:** Secrets (tokens, webhook signing material) only from bootstrap / `shared/secrets` pattern already used by the app; no new `dotenv` reads inside adapters.
- **Testability:** Ports allow unit tests with fakes; webhook handler tests use captured fixtures or SDK verify helpers with known keys.
- **Isolation:** No imports of `@util/vk-remote-sdk` outside `vibe-kanban/infrastructure/` (single choke point).

### Architecture — where application code calls it (DDD + existing layout)

Add one bounded context folder (name is fixed here for clarity; rename only if product language prefers e.g. `work-tracking`).

**Module root:** `app/src/vibe-kanban/`

| Layer              | Path                                                       | Calls SDK?                             | Responsibility                                                                                                                                                                            |
| ------------------ | ---------------------------------------------------------- | -------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Ports**          | `vibe-kanban/ports/interfaces.ts`                          | No                                     | `VibeKanbanOutboundPort` (issue/org operations you need), `VibeKanbanWebhookPort` or a single application facade — **Nexus-shaped** methods, not re-exported SDK types unless unavoidable |
| **Application**    | `vibe-kanban/service/*.ts`                                 | No                                     | Orchestration, mapping between domain-friendly DTOs and SDK responses; idempotency keys for webhooks if required                                                                          |
| **Infrastructure** | `vibe-kanban/infrastructure/vk-remote-outbound.adapter.ts` | **Yes** (`VkRemoteClient`)             | Implements outbound port                                                                                                                                                                  |
| **Infrastructure** | `vibe-kanban/infrastructure/vk-webhook.verifier.ts`        | **Yes** (`parseVerifiedWebhook`, etc.) | Signature + raw body handling isolated from Express                                                                                                                                       |
| **Schemas**        | `vibe-kanban/schemas/*.ts` (optional)                      | No                                     | Zod for webhook subsets or query params; align with existing `parseInput` in routes                                                                                                       |
| **Barrel**         | `vibe-kanban/index.ts`                                     | No                                     | Export factory `createVibeKanbanModule(config)` and/or a wired singleton — **same composition pattern as `user/index.ts`**                                                                |

**HTTP channel (not inside the module tree for consistency with the repo):**

| Layer      | Path                                          | Responsibility                                                                                                                                                          |
| ---------- | --------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Routes** | `channels/http/vibe-kanban-webhook.routes.ts` | `RouteDefinition[]`: read raw body / headers as required by the verifier, call `vibeKanbanService.handleWebhook(...)` (or dedicated handler), map errors to HTTP status |

**Bootstrap (`index.ts`):**

1. After `initSecrets` / logger (existing flow), build VK config from `process.env` (e.g. `VK_*` — document in [Env Reference](#env-reference) when implemented).
2. Instantiate `VkRemoteClient` **only inside** the infrastructure adapter constructor or factory.
3. Pass the constructed service (or `RouteDefinition` factory that closes over the service) into `ApiServer` `routes: [...userRoutes, ...authRoutes, ...vibeKanbanRoutes]`.

**Dependency rule (unchanged from repo norms):**

```text
channels/http/vibe-kanban-*.routes.ts
  → vibe-kanban/service
    → vibe-kanban/ports (types)
      ← vibe-kanban/infrastructure (implements ports; imports @util/vk-remote-sdk)
```

Other bounded contexts (e.g. future `order`, or `ag-vidur`) must depend on **`VibeKanbanOutboundPort`** (or application service interface) only — **never** import `@util/vk-remote-sdk` directly.

### Phases (VK)

| Phase    | Scope                                                          | Done when                                                                                                                                             |
| -------- | -------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| **VK-1** | Ports + outbound adapter + service skeleton + bootstrap wiring | **Done** — `vibe-kanban/*`, disabled outbound when `VK_REMOTE_BASE_URL` unset                                                                         |
| **VK-2** | Webhook route(s) + verifier + Zod where needed                 | **Done** — `POST /api/v1/vibe-kanban/webhooks/issue-status` when `VK_WEBHOOK_SECRET` set; `onJsonBodyVerify` on `@util/api-server` for raw HMAC bytes |
| **VK-3** | Concrete outbound use cases + cross-module calls               | Features that need Kanban data call the port only                                                                                                     |
| **VK-4** | Tests + env docs                                               | **Partial** — unit tests for service + verifier; env table updated; HTTP integration test optional                                                    |

### Test plan (VK)

| Area                       | Target                                                                         |
| -------------------------- | ------------------------------------------------------------------------------ |
| Outbound adapter           | Contract tests or thin integration test against mock HTTP (optional if costly) |
| Webhook verifier + service | **Done** — `vk-webhook.verifier.test.ts`, `vibe-kanban.service.test.ts`        |
| HTTP route                 | Follow `http-routes.test.ts` pattern when infra/env available (optional)       |

### Decision log (VK)

| #    | Decision                                   | Rationale                                                             |
| ---- | ------------------------------------------ | --------------------------------------------------------------------- |
| VK-1 | Single bounded context `vibe-kanban/`      | One place for Kanban language, ports, and SDK mapping                 |
| VK-2 | Webhook routes under `channels/http/`      | Matches `user.routes.ts`, `auth.routes.ts`; keeps Express at the edge |
| VK-3 | SDK only in `vibe-kanban/infrastructure/`  | SDK changes outside repo touch minimal files                          |
| VK-4 | Config from bootstrap, not inside packages | Matches project-context “Env from app”                                |

## Test Plan

| Area                     | Covered | Notes                                                                                  |
| ------------------------ | ------- | -------------------------------------------------------------------------------------- |
| `toObjectId` helper      | Yes     | Valid/invalid/label tests                                                              |
| `UserService.getById`    | Yes     | Valid ID, invalid ID (ValidationError), not found (NotFoundError)                      |
| `UserService.getByEmail` | Yes     | Existing email, non-existent email                                                     |
| Auth schemas             | Yes     | Login, Refresh, Logout input validation                                                |
| Route handler HTTP       | Yes     | `http-routes.test.ts` — login, refresh, logout, me, register, 401 when infra available |
| `AuthService` unit       | Partial | Only weak-password test; login/refresh/logout paths not covered                        |
| `requireRoles` unit      | No      | Only covered via HTTP integration tests                                                |
| Bootstrap flow           | No      | Tested manually; could add lifecycle test                                              |

## Env Reference

| Variable                     | Purpose                                                                                         |
| ---------------------------- | ----------------------------------------------------------------------------------------------- |
| `PORT`                       | HTTP server port (default 3001)                                                                 |
| `MONGODB_URI`                | MongoDB connection string (optional)                                                            |
| `MONGODB_DATABASE`           | Database name (default `app`)                                                                   |
| `DB_SECRET_ID`               | If set, MongoDB URI is read from AWS Secrets Manager                                            |
| `REDIS_URL`                  | Redis connection string (default `redis://localhost:6379`)                                      |
| `JWT_SECRET` / `AUTH_SECRET` | HS256 JWT signing secret (min 32 chars)                                                         |
| `VK_REMOTE_BASE_URL`         | Vibe Kanban remote or desktop origin (no `/v1` suffix); omit to disable outbound                |
| `VK_REMOTE_ACCESS_TOKEN`     | Bearer token when `VK_REMOTE_TRANSPORT` is `remote` (empty for `localDesktop`)                  |
| `VK_REMOTE_TRANSPORT`        | `remote` (default) or `localDesktop` — see `@util/vk-remote-sdk` README                         |
| `VK_WEBHOOK_SECRET`          | HMAC secret for `X-VK-Signature`; when set, mounts `POST .../vibe-kanban/webhooks/issue-status` |

## Decision Log

| #   | Decision                                                    | Rationale                                                                  |
| --- | ----------------------------------------------------------- | -------------------------------------------------------------------------- |
| 1   | Zod validation in route handlers (`parseInput`)             | Prevents unsafe `as` casts; returns clean 400 errors at the boundary       |
| 2   | `UserServicePort` returns `Promise<User>` (not `undefined`) | Implementation throws `NotFoundError`; port should reflect that contract   |
| 3   | `toObjectId()` in `infrastructure/`                         | Keeps `mongodb` driver dependency out of services; reusable across modules |
| 4   | Lazy init for logger/secrets (no top-level `await`)         | Enables Jest to import app modules without ESM compatibility issues        |
| 5   | `connectDb()` warns on missing URI                          | Silent no-op made debugging hard; explicit warning surfaces misconfig      |
