# Review — app

Last reviewed: 2026-04-06

## Open Issues

- [ ] [high] `secrets` in `src/shared/secrets/secret.ts` is declared with `let` and is uninitialized before `initSecrets()` is called; if any module imports `secrets` before `await initSecrets()` completes (e.g. via circular dependency or early import evaluation), it will be `undefined` at runtime — `src/shared/secrets/secret.ts:27` — [logic]
- [ ] [high] `logger` in `src/shared/logger/logger.ts` is similarly declared with `let` without initialization; accessing `logger.info(...)` before `await initLogger()` resolves causes a runtime crash — `src/shared/logger/logger.ts:3` — [logic]
- [ ] [med] `sseRedisHistoryStore.appendEvent` does not set a TTL on the Redis stream (`xAdd` with no MAXLEN or expiry); SSE event history streams grow unboundedly and are never pruned — `src/infrastructure/sse-redis-history-store.ts:29` — [resource]
- [ ] [med] `sseRedisHistoryStore.getEventsAfter` passes raw `afterEventId` directly to `xRange` as the range start (`(${afterEventId}`); if `afterEventId` contains special characters it could produce a malformed Redis range key — `src/infrastructure/sse-redis-history-store.ts:60` — [security]
- [ ] [med] `UserService.create` inserts the document and then immediately queries it back with `findOne`; there is a window where a soft-delete or another write between the two operations could cause the second read to return `null`, triggering the "User created but not found" error even on success — `src/user/service/user.service.ts:122-129` — [logic]
- [ ] [med] `app/src/index.ts` mounts SSE routes via `server.expressApp.use("/api", router)` after `ApiServer.create()` but before `server.start()`; routes mounted after `create()` but before `mountRouterAndErrorHandlers` is called inside `start()` are registered before the 404/error handler, which is correct, but this ordering is fragile and undocumented — `src/index.ts:51-53` — [design]
- [ ] [med] `auth.routes.ts` returns a hardcoded `expiresIn: 900` value (seconds) in the register and login responses; this is inconsistent with `ACCESS_EXPIRES_IN = "15m"` and should be derived from the config — `src/channels/http/auth.routes.ts:43`, `src/channels/http/auth.routes.ts:56`, `src/channels/http/auth.routes.ts:71` — [logic]
- [ ] [med] `UserService` directly calls `getDb()` in every method; `getDb()` throws if MongoDB was never connected (e.g. when `DB_SECRET_ID` or `MONGODB_URI` is unset and `connectDb()` skipped it) — callers receive an unguarded singleton error instead of a clear service-layer error — `src/user/service/user.service.ts:82` — [invariant]
- [ ] [low] No tests for `sseRedisHistoryStore` — neither `appendEvent` nor `getEventsAfter` unit/integration tests exist — `src/infrastructure/sse-redis-history-store.ts` — [test-coverage]
- [ ] [low] `app/docs/future-roadmap.md` is missing — all packages have this file but the `app/` package does not — `app/docs/` — [docs]
- [ ] [low] `app/src/ag-reviewer/` directory contains files (`entities/index.ts`, `helpers/build-session-keys.util.ts`, `schemas/auth.schema.test.ts`, `schemas/auth.schema.ts`) that are not imported by any other module — dead code — `src/ag-reviewer/` — [design]
- [ ] [low] `REDIS_URL` is read directly from `process.env` inside `src/infrastructure/redis.ts` rather than being passed from the secrets layer; this bypasses the AWS Secrets Manager pattern used for the database URI — `src/infrastructure/redis.ts:5` — [invariant]
- [ ] [low] `user.routes.ts` defines `GetUserInput` schema inline at module level rather than in a dedicated schema file, inconsistent with auth routes which use `src/auth/schemas/` — `src/channels/http/user.routes.ts:14` — [style]
- [ ] [low] `require-roles.middleware.ts` reads `req.cookies?.accessToken` as a token fallback; `cookie-parser` is not confirmed to be mounted in the app, so `req.cookies` could be `undefined` at runtime — `src/shared/auth/require-roles.middleware.ts:17` — [logic]

## Completed

- [x] [high] Route handler now validates input with Zod (`parseInput` + `GetUserInput` schema) instead of unsafe `as` cast — `src/channels/http/user.routes.ts`
- [x] [med] `UserServicePort.getById` return type aligned to `Promise<User>` (was `Promise<User | undefined>`) — `src/user/ports/user-service.port.ts`
- [x] [med] `connectDb()` logs warning when no `MONGODB_URI` or `DB_SECRET_ID` is configured — `src/infrastructure/database.ts`
- [x] [med] `onAppStop` now logs DB close errors instead of silently swallowing — `src/index.ts`
- [x] [med] `ObjectId` dependency moved from `UserService` to `infrastructure/object-id.ts` (`toObjectId` helper) — `src/infrastructure/object-id.ts`
- [x] [med] Tests added: `toObjectId` unit tests (4), `UserService.getById` integration tests (3) — 7 total — `src/infrastructure/object-id.test.ts`, `src/user/service/user.service.test.ts`
- [x] [med] Shared modules (`logger.ts`, `secret.ts`) refactored from top-level `await` to lazy `initLogger()` / `initSecrets()` for Jest compatibility — `src/shared/logger/logger.ts`, `src/shared/secrets/secret.ts`
- [x] [low] `docs/plan.md` updated — old `@utils/*` references replaced with `@util/*`, added Problem Definition, Requirements, Phases, Test Plan, Decision Log — `docs/plan.md`
- [x] [low] `@util/*` imports confirmed correct across all source files — false positive in original review — all files
- [x] [low] Extracted `UserService.getById` mapping into `mapUserDocToDomain()` helper to reduce mixed responsibilities — `src/user/service/user.service.ts` — resolved 2026-03-23
- [x] [med] Auth module added: login, refresh, logout, logout-all, me endpoints; Redis session; requireRoles middleware in app — `src/auth/`, `src/channels/http/auth.routes.ts`, `src/shared/auth/` — resolved 2026-03-23
- [x] [high] JWT_SECRET/AUTH_SECRET empty string — getJwtSecret() throws if unset or <32 chars — `src/auth/config.ts` — resolved 2026-03-23
- [x] [med] Non-null assertion removed — getJwtSecret() used throughout — resolved 2026-03-23
- [x] [med] refresh() atomic: set new allowlist before revoke — resolved 2026-03-23
- [x] [med] logout() uses ACCESS_TTL_MS for revoked key — resolved 2026-03-23
- [x] [med] Hardcoded secret/expiry extracted to config — resolved 2026-03-23
- [x] [low] connectRedis handles failure — try/catch, log and rethrow — resolved 2026-03-23
- [x] [low] LogoutInputSchema rejection for empty refreshToken test — resolved 2026-03-23
- [x] [low] RequireRolesOptions exported — resolved 2026-03-23
- [x] [low] AuthRequest type extracted — resolved 2026-03-23
- [x] [low] Auth service and helper function comments — resolved 2026-03-23
- [x] [low] Route-level HTTP integration tests added — spins up ApiServer with real DB/Redis when available; skips when not — `src/channels/http/http-routes.test.ts` — resolved 2026-03-23
- [x] [low] Auth endpoint tests added — login, refresh, logout, me (requireRoles), invalid credentials — `src/channels/http/http-routes.test.ts` — resolved 2026-03-23
- [x] [high] logout() catch only wraps JWT verify; Redis errors propagate — `src/auth/service/auth.service.ts` — resolved 2026-03-23
- [x] [med] REFRESH_TTL_MS/ACCESS_TTL_MS moved to shared/auth-config.ts — single source of truth — resolved 2026-03-23
- [x] [med] logoutAll() uses buildUserKeyPrefix helper — `src/auth/service/auth.service.ts` — resolved 2026-03-23
- [x] [med] TokenPair defined in auth/entities; port uses auth layer type — resolved 2026-03-23
- [x] [med] createRequireRolesMiddleware unit tests — no-token, invalid-token, wrong-role, correct-role, cookie — `src/shared/auth/require-roles.middleware.test.ts` — resolved 2026-03-23
- [x] [med] parseInput extracted to shared/http/parse-input.util.ts — both routes use it — resolved 2026-03-23
- [x] [low] auth/entities defines TokenPair locally; no library re-export — resolved 2026-03-23
- [x] [low] user.service CreateUserParams top-level import — resolved 2026-03-23
- [x] [low] docs/plan.md Phase 5/6 aligned — resolved 2026-03-23
- [x] [low] RequireRolesOptions exported in consolidated block — resolved 2026-03-23
- [x] [low] getJwtSecret has JSDoc in auth-config — resolved 2026-03-23
- [x] [med] auth.service.test.ts expanded — logout invalid/empty token tests; integration paths covered by http-routes.test — resolved 2026-03-23
- [x] [med] Race condition in `refresh()` fixed with atomic token consumption (`RecordStore.consumeRecord` / Redis GETDEL), and concurrent refresh test now asserts only one request succeeds — `src/auth/service/auth.service.ts`, `src/channels/http/auth.routes.test.ts` — resolved 2026-03-24
- [x] [med] `register()` no longer calls `this.login()`; it now issues tokens directly for the newly created user to avoid duplicate DB lookup and password verify — `src/auth/service/auth.service.ts` — resolved 2026-03-24
